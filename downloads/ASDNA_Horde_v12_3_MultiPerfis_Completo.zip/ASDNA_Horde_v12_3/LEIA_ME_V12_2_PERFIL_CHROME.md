# ASDNA v12.2 — sessões autenticadas do Chrome

## Por que o Instagram abria sem login?

O Chrome podia abrir com o diretório `Default`, mas o Playwright MCP
continuava ligado ao perfil persistente próprio dele, que possui outras
sessões e cookies. Assim, abrir `chrome.exe` não conectava a automação à
aba existente; o Playwright via uma tela de login.

## O que mudou

- Quando um pedido de automação na web especifica `perfil Default`, `perfil
  Profile 4` ou o nome de um perfil que possa ser identificado no Chrome,
  o ASDNA configura o Playwright para **modo extensão** com aquele diretório.
- Esta configuração é guardada em `mcp-servers.json` e a sessão MCP é
  reiniciada para aplicar a troca. Nenhuma senha ou cookie é copiado.
- Reinstalações do Playwright via `/mcp instalar playwright` e instalação
  automática preservam `--extension` e `--profile-dir-name`.
- Se o Playwright não conectar ao perfil pedido, a tarefa é parada sem
  abrir um segundo navegador vazio. Se o Instagram devolver uma tela de
  login, o agente é interrompido sem tentar enviar a mensagem.
- Continuam disponíveis as ferramentas Windows e os outros MCPs para as
  atividades que não exijam sessão web autenticada.

## Instalação da extensão — necessária uma única vez por perfil

1. Abra seu Chrome normal e selecione o perfil já conectado no serviço.
2. Instale e habilite **Playwright Extension** conforme instruções oficiais:
   https://playwright.dev/mcp/configuration/browser-extension
3. Caso a extensão solicite pareamento ou token, faça a conexão no próprio
   Chrome. Não compartilhe o token com a IA nem cole credenciais no chat.
4. No ASDNA use `/navegador conectar Default` (ou o diretório correto
   encontrado com `/perfis`) e `/navegador status`.
5. Faça o pedido normalmente. Agora ele também reconhece `perfil Default`
   durante a tarefa. Para conferir ferramentas: `/mcp ferramentas playwright`.

**Importante**: o diretório `Default` pode ser exibido no Chrome com um
nome diferente (por exemplo, "Eduardo"). Verifique no Chrome a conta do
**Instagram**, pois nome de perfil Chrome/conta Google não prova identidade
no Instagram. Se o login estiver ausente ou expirado, você precisa entrar
na conta manualmente; o agente não deve pedir ou exportar senhas.

## Testes

`go test ./...` executa testes de reconhecimento de perfil, montagem dos
argumentos de extensão e parada diante de autenticação ausente.
Compilação Windows amd64 foi realizada fora de um Windows real; não houve
validação de login em Chrome ou envio de mensagem no Instagram.
