package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/ui"
)

// Context is local metadata, not a transcript, file contents or API credentials.
// Explicit paths are more reliable than asking a language model to remember a directory.
type rememberedContext struct {
	Directory string    `json:"directory,omitempty"`
	App       string    `json:"app,omitempty"`
	Updated   time.Time `json:"updated"`
}

func (a *App) rememberContext() {
	if a == nil {
		return
	}
	record := rememberedContext{Directory: strings.TrimSpace(a.recentPath), App: strings.TrimSpace(a.recentApp), Updated: time.Now()}
	path, err := storage.File("contexto_projetos.json")
	if err != nil {
		return
	}
	b, err := json.MarshalIndent(record, "", "  ")
	if err != nil {
		return
	}
	temp, err := os.CreateTemp(filepath.Dir(path), "asdna-context-*")
	if err != nil {
		return
	}
	defer os.Remove(temp.Name())
	_ = temp.Chmod(0600)
	if _, err = temp.Write(b); err != nil {
		temp.Close()
		return
	}
	if err = temp.Close(); err != nil {
		return
	}
	// Windows rename will not overwrite existing file; remove after safe temp write.
	// A failed rename preserves the old context and never fails the user's action.
	_ = os.Remove(path)
	_ = os.Rename(temp.Name(), path)
}

func (a *App) restoreContext() {
	path, err := storage.File("contexto_projetos.json")
	if err != nil {
		return
	}
	b, err := os.ReadFile(path)
	if err != nil || len(b) > 8192 {
		return
	}
	var v rememberedContext
	if json.Unmarshal(b, &v) != nil {
		return
	}
	if len(v.Directory) < 1024 {
		a.recentPath = v.Directory
	}
	if len(v.App) < 256 {
		a.recentApp = v.App
	}
}

func (a *App) memoryCommand(parts []string) {
	if len(parts) > 1 && (parts[1] == "limpar" || parts[1] == "apagar") {
		a.recentApp = ""
		a.recentPath = ""
		a.recentTool = ""
		a.recentRequest = ""
		a.recentResult = ""
		path, err := storage.File("contexto_projetos.json")
		if err == nil {
			err = os.Remove(path)
		}
		if err != nil && !errors.Is(err, os.ErrNotExist) {
			ui.Warnf("Nao foi possivel limpar: %v", err)
			return
		}
		ui.OK("Contexto local de projetos limpo. Historico de conversas mantido.")
		return
	}
	if len(parts) > 1 {
		ui.Warn("Use /memoria ou /memoria limpar")
		return
	}
	ui.Infof("Pasta lembrada: %s | Aplicativo: %s", a.recentPath, a.recentApp)
	ui.Info("Memoria local guarda apenas ultimo diretorio/projeto e aplicativo. /memoria limpar apaga esses metadados.")
}
