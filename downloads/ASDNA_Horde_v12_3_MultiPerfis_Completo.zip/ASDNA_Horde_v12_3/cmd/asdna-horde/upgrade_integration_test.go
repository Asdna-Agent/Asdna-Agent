package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
)

func TestCreatesTwoLinkedFilesAndRemembersFolder(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var request struct {
			Messages []horde.Message `json:"messages"`
		}
		_ = json.NewDecoder(r.Body).Decode(&request)
		content := `<!doctype html><html><head><title>Agro</title></head><body><button>Veja</button><p>Agricultura</p></body></html>`
		for _, msg := range request.Messages {
			if msg.Role == "user" && strings.Contains(msg.Content, "CONTEUDO de documents/sitesteste/style.css") {
				content = "body { color: navy; background: white; }"
			}
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": content}}}})
	}))
	defer server.Close()
	api := horde.New(horde.AnonymousKey)
	api.Endpoint = server.URL
	a := &App{api: api, pc: &pcactions.Agent{Base: filepath.Join(home, "Downloads", "ASDNA_Horde"), Confirm: func(string) bool { return true }}, config: storage.Config{SelectedModel: "fake", MaxTokens: 2048}}
	prompt := `faz um site sobre agricultura, crie e escreva "index.html", "style.css", conecte os 2 arquivos e crie os em documents/sitesteste/index e style, use azul e branco`
	if !a.tryArtifactWorkflow(prompt) {
		t.Fatal("multi-artifact not handled")
	}
	root := filepath.Join(home, "Documents", "sitesteste")
	html, err := os.ReadFile(filepath.Join(root, "index.html"))
	if err != nil || !strings.Contains(string(html), `href="style.css"`) {
		t.Fatalf("HTML missing CSS link: %v %q", err, html)
	}
	css, err := os.ReadFile(filepath.Join(root, "style.css"))
	if err != nil || !strings.Contains(string(css), "background: white") {
		t.Fatalf("CSS missing: %v %q", err, css)
	}
	if a.recentPath != "documents/sitesteste" {
		t.Fatal(a.recentPath)
	}
	b := &App{}
	b.restoreContext()
	if b.recentPath != a.recentPath {
		t.Fatalf("persistent context lost %q != %q", b.recentPath, a.recentPath)
	}
}
