package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/ui"
)

var projectPathRE = regexp.MustCompile(`(?i)(?:\b(?:em|dentro de|na pasta|no diretorio|para)\s+)((?:documents|documentos|desktop|downloads|onedrive|c:[/\\]|d:[/\\])[/\\]?[\pL\pN_.-]+(?:[/\\][\pL\pN_.-]+)*)`)

func projectDirectory(request string, recent string) string {
	n := pcactions.NormalizeIntent(request)
	if (strings.Contains(n, "mesma pasta") || strings.Contains(n, "nessa pasta") || strings.Contains(n, "naquela pasta") || strings.Contains(n, "mesmo diretorio")) && strings.TrimSpace(recent) != "" {
		return recent
	}
	// The user may write "em Documents/Projeto/index e style" as shorthand.
	// Remove accidental file-like suffix after a named directory.
	if m := projectPathRE.FindStringSubmatch(request); len(m) > 1 {
		dir := strings.Trim(strings.ReplaceAll(m[1], `\`, `/`), `/`)
		if filepath.Ext(dir) != "" || (len(requestedFiles(request)) >= 2 && (strings.EqualFold(filepath.Base(dir), "index") || strings.EqualFold(filepath.Base(dir), "style"))) {
			dir = filepath.Dir(dir)
		}
		if dir != "." {
			return dir
		}
	}
	quoted := artifactQuoted.FindAllStringSubmatch(request, -1)
	for _, m := range quoted {
		if len(m) > 1 && strings.ContainsAny(m[1], `/\`) && filepath.Ext(m[1]) == "" {
			return strings.ReplaceAll(strings.Trim(m[1], `/\`), `\`, `/`)
		}
	}
	return ""
}

func (a *App) tryMultipleArtifactWorkflow(request string) bool {
	n := pcactions.NormalizeIntent(request)
	if !pcactions.IsPCRequest(request) || !artifactVerb.MatchString(n) {
		return false
	}
	candidates := []string{}
	for _, f := range requestedFiles(request) {
		if isEditableArtifact(f) {
			candidates = append(candidates, f)
		}
	}
	if len(candidates) < 2 {
		return false
	}
	dir := projectDirectory(request, a.recentPath)
	if dir == "" {
		// Only create files when the user supplied a sufficiently clear path.
		return false
	}
	ui.User(request)
	var output []string
	created := []string{}
	for _, f := range candidates {
		name := baseNamePortable(f)
		path := strings.TrimSuffix(dir, "/") + "/" + name
		prompt := request + "\nPROJETO: " + dir + "\nARQUIVOS_SOLICITADOS: " + strings.Join(candidates, ", ") + "\nGere apenas o conteudo de " + name + "."
		if strings.EqualFold(filepath.Ext(name), ".html") {
			for _, sibling := range candidates {
				if strings.EqualFold(filepath.Ext(sibling), ".css") {
					prompt += "\nO HTML PRECISA conter <link rel=\"stylesheet\" href=\"" + baseNamePortable(sibling) + "\"> em <head>."
				}
			}
		}
		body, err := a.generateFileText(prompt, path)
		if err != nil {
			a.artifactFailure(request, fmt.Errorf("%s: %w", name, err))
			return true
		}
		if strings.EqualFold(filepath.Ext(name), ".html") {
			for _, sibling := range candidates {
				if strings.EqualFold(filepath.Ext(sibling), ".css") {
					target := baseNamePortable(sibling)
					if !strings.Contains(strings.ToLower(body), strings.ToLower("href=\""+target+"\"")) && strings.Contains(strings.ToLower(body), "</head>") {
						i := strings.Index(strings.ToLower(body), "</head>")
						body = body[:i] + "<link rel=\"stylesheet\" href=\"" + target + "\">\n" + body[i:]
					}
				}
			}
		}
		action := pcactions.Action{Tool: "write_file", Path: path, Content: body}
		res, err := a.pc.Execute(action)
		if err != nil {
			a.artifactFailure(request, fmt.Errorf("%s: %w", name, err))
			return true
		}
		full, _, err := a.pc.ResolvedPath(path)
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		info, err := os.Stat(full)
		if err != nil || info.IsDir() || info.Size() == 0 {
			a.artifactFailure(request, fmt.Errorf("verificacao falhou para %s: %v", path, err))
			return true
		}
		created = append(created, path)
		output = append(output, res)
		ui.OK(res)
		a.updateAgentContext(request, action, res)
	}
	output = append(output, "Arquivos verificados: "+strings.Join(created, ", "))
	if pcactions.IsZipRequest(request) {
		zipName := strings.TrimSuffix(dir, "/") + ".zip"
		res, err := a.pc.Execute(pcactions.Action{Tool: "zip_dir", Path: dir, Destination: zipName})
		if err != nil {
			a.artifactFailure(request, fmt.Errorf("arquivos criados; ZIP falhou: %w", err))
			return true
		}
		output = append(output, res)
		ui.OK(res)
	}
	summary := strings.Join(output, "\n")
	ui.Assistant(a.config.SelectedModel, summary)
	a.recordLocal(request, summary)
	return true
}
