package main

import (
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/mcp"
)

func TestProjectFolderAndRequestedFiles(t *testing.T) {
	request := `faz um site bonito sobre agricultura, crie e escreva "index.html", "style.css", conecte os 2 arquivos e crie os em documents/sitesteste/index e style`
	if d := projectDirectory(request, ""); d != "documents/sitesteste" {
		t.Fatalf("directory mismatch: %q", d)
	}
	files := requestedFiles(request)
	if len(files) != 2 || files[0] != "index.html" || files[1] != "style.css" {
		t.Fatalf("files %v", files)
	}
}
func TestFollowupSameDirectory(t *testing.T) {
	if d := projectDirectory("agora nessa mesma pasta crie o style.css", "Documents/sitesteste"); d != "Documents/sitesteste" {
		t.Fatal(d)
	}
}
func TestSequentialSchemaAndMissingMultiFiles(t *testing.T) {
	const request = `crie index.html e style.css em Documents/sitesteste`
	missing := missingRequestedFiles(request, map[string]bool{"index.html": true})
	if len(missing) != 1 || !strings.EqualFold(missing[0], "style.css") {
		t.Fatal(missing)
	}
	schema := chosenToolSchemas("sequential-thinking", []mcp.Tool{{Name: "sequentialthinking"}}, 900)
	if !strings.Contains(schema, "sequentialthinking") {
		t.Fatal(schema)
	}
}
func TestSequentialRegistered(t *testing.T) {
	reg := mcp.DefaultRegistry(t.TempDir(), t.TempDir())
	if _, ok := reg.Servers["sequential-thinking"]; !ok {
		t.Fatal("Sequential Thinking ausente")
	}
}

func TestProjectDirectoryRestoresAcrossAppRestart(t *testing.T) {
	// Metadata is held independently from a particular model/provider.
	a := &App{recentPath: "Documents/SiteTeste", recentApp: ""}
	dir := projectDirectory("nessa mesma pasta crie o arquivo style.css", a.recentPath)
	if dir != "Documents/SiteTeste" {
		t.Fatal(dir)
	}
}
