package main

import (
	"context"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/pcactions"
)

// Complex requests are offered a planning tool; the remote AI remains responsible
// for deciding how to solve the task and for creating actual file contents.
func complexAgentRequest(request string) bool {
	if len(requestedFiles(request)) >= 2 {
		return true
	}
	n := pcactions.NormalizeIntent(request)
	count := 0
	for _, s := range []string{"crie", "escreva", "conecte", "verifique", "corrija", "analise", "teste", "execute", "pesquise", "instale", "configure", "criar", "desenvolva"} {
		if strings.Contains(n, s) {
			count++
		}
	}
	return count >= 3 || len([]rune(request)) > 280
}

func missingRequestedFiles(request string, completed map[string]bool) []string {
	if !complexAgentRequest(request) {
		return nil
	}
	missing := []string{}
	for _, f := range requestedFiles(request) {
		if !isEditableArtifact(f) {
			continue
		}
		if !completed[strings.ToLower(baseNamePortable(f))] {
			missing = append(missing, f)
		}
	}
	return missing
}

func (a *App) sequentialTaskGuidance() string {
	const server = "sequential-thinking"
	if a.mcp == nil {
		return ""
	}
	cfg, ok := a.mcp.Config(server)
	if !ok || !cfg.Enabled {
		return ""
	}
	// Do not auto-install a package merely because a prompt is lengthy.
	if shouldInstallMCP(server, cfg) {
		return "\nPlanejamento em etapas recomendado. Sequential Thinking MCP opcional: para ativar, /mcp instalar sequential-thinking. Continue normalmente sem ele.\n"
	}
	if err := a.approveMCPStart(server); err != nil {
		return ""
	}
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
	defer cancel()
	tools, err := a.mcp.ListTools(ctx, server)
	if err != nil {
		return ""
	}
	desc := chosenToolSchemas(server, tools, 3500)
	if desc == "" {
		return ""
	}
	return "\nPLANEJAMENTO MCP DISPONIVEL: para pedidos complexos, considere chamar mcp_call com server=sequential-thinking antes da primeira acao real. A ferramenta ajuda a revisar o PLANO, mas nao cria arquivos nem comprova execucao. Depois execute as etapas com ferramentas REAIS. Use apenas o schema:\n" + desc
}

// Static compile-time reference ensures MCP tooling changes remain compatible.
var _ = mcp.Tool{}
