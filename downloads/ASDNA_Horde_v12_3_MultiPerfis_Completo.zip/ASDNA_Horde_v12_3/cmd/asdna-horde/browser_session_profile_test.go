package main

import (
	"reflect"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/mcp"
)

func TestChromeProfileRequestedFromNaturalLanguage(t *testing.T) {
	cases := []struct{ request, profile string }{
		{`entre no google chrome, no perfil default ou seja zelpyrndev, abra o instagram e envie uma mensagem`, "default"},
		{`entre no Chrome no perfil Profile 4, depois pesquise no Instagram`, "Profile 4"},
		{`abra o Chrome no perfil zelpyrndev, pesquise por projetos`, "zelpyrndev"},
		{`abra instagram no perfil Trabalho Escolar e procure o grupo`, "Trabalho Escolar"},
		{`use Chrome perfil "Minha Conta Pessoal" e abra o Instagram`, "Minha Conta Pessoal"},
		{`use Chrome no perfil 'Equipe de Vendas', acesse o portal`, "Equipe de Vendas"},
		{`entre no Chrome com o perfil Akajajaj e envie um recado`, "Akajajaj"},
		{`abra o site com o perfil Profile 8, depois clique no menu`, "Profile 8"},
		{`acesse o e-mail no perfil Eduardo`, "Eduardo"},
		{`abra o instagram`, ""},
	}
	for _, c := range cases {
		if got := chromeProfileRequested(c.request); got != c.profile {
			t.Errorf("%q: got %q, want %q", c.request, got, c.profile)
		}
	}
}

func TestExtensionArgsReplaceOtherSessionModes(t *testing.T) {
	old := []string{`C:\mcp\cli.js`, "--browser", "chrome", "--user-data-dir", `C:\empty`, "--isolated", "--cdp-endpoint=http://localhost:9222"}
	want := []string{`C:\mcp\cli.js`, "--extension", "--profile-dir-name=Default"}
	if got := setPlaywrightExtensionArgs(old, "Default"); !reflect.DeepEqual(got, want) {
		t.Fatalf("args = %v, want %v", got, want)
	}
	cfg := mcp.Config{Args: want}
	if configuredPlaywrightProfile(cfg) != "Default" {
		t.Fatalf("profile not retained")
	}
	if got := setPlaywrightExtensionArgs(want, "Profile 8"); strings.Count(strings.Join(got, " "), "--extension") != 1 {
		t.Fatalf("duplicate flag: %v", got)
	}
}

func TestStopOnRealLoginGateButNotCasualMention(t *testing.T) {
	req := `abra o Instagram no perfil Default e envie mensagem de teste`
	if !browserLoginRequired(req, `Page URL: https://www.instagram.com/accounts/login/?next=direct/inbox`) {
		t.Fatal("login redirect not detected")
	}
	if !browserLoginRequired(req, `- generic: Entrar no Instagram\n- textbox "Senha"`) {
		t.Fatal("login form not detected")
	}
	if browserLoginRequired(req, "blog sobre login sem formularios") {
		t.Fatal("false positive")
	}
}
