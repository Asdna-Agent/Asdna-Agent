package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/ui"
)

// A Playwright extension is required to reuse a logged-in Chrome profile.
// We never copy cookies, passwords or the live user-data directory.
// Accept a Chrome profile directory or a human-friendly display name, including
// multi-word/quoted names. Never assume that an unspecified profile is Default.
var profileReference = regexp.MustCompile(`(?i)\b(?:perfil|profile)\s+(?:do\s+chrome\s+)?`)
var profileClauseEnd = regexp.MustCompile(`(?i)\s+(?:ou\s+seja|isto\s+[eé]|depois|ent[aã]o|para\s+(?:abrir|acessar|entrar|pesquisar|buscar|procurar|enviar|fazer)|e\s+(?:abra|abre|abrir|acesse|acessar|entre|entrar|pesquise|buscar|busque|procure|envie|enviar|mande|fazer|fa[cç]a|clique|veja))\b`)
var profileDirectoryExact = regexp.MustCompile(`(?i)^(default|profile[ -]\d+)$`)

func chromeProfileRequested(request string) string {
	match := profileReference.FindStringIndex(request)
	if len(match) == 0 {
		return ""
	}
	tail := strings.TrimSpace(request[match[1]:])
	if tail == "" {
		return ""
	}
	// Quoted display names may contain spaces and ordinary conjunctions.
	if strings.HasPrefix(tail, `"`) || strings.HasPrefix(tail, `“`) || strings.HasPrefix(tail, `'`) {
		var closing string
		switch tail[0] {
		case '\'':
			closing = "'"
		case '"':
			closing = `"`
		default:
			closing = "”"
		}
		openerLen := 1
		if strings.HasPrefix(tail, "“") {
			openerLen = len("“")
		}
		remaining := tail[openerLen:]
		if pos := strings.Index(remaining, closing); pos >= 0 {
			return strings.TrimSpace(remaining[:pos])
		}
	}
	// Chrome's directory name is always Default or Profile N, even if the
	// visible label (which may contain spaces) is completely different.
	if m := regexp.MustCompile(`(?i)^(?:default|profile[ -]\d+)\b`).FindString(tail); m != "" {
		return strings.TrimSpace(m)
	}
	end := len(tail)
	for _, c := range []string{",", ";", ".", "?", "!", "\n"} {
		if pos := strings.Index(tail, c); pos >= 0 && pos < end {
			end = pos
		}
	}
	if pos := profileClauseEnd.FindStringIndex(tail); len(pos) > 0 && pos[0] < end {
		end = pos[0]
	}
	return strings.TrimSpace(strings.Trim(tail[:end], ` \"'“”`))
}

func configuredPlaywrightProfile(cfg mcp.Config) string {
	ext := false
	name := ""
	for i, arg := range cfg.Args {
		if arg == "--extension" {
			ext = true
		}
		if strings.HasPrefix(arg, "--profile-dir-name=") {
			name = strings.TrimPrefix(arg, "--profile-dir-name=")
		}
		if arg == "--profile-dir-name" && i+1 < len(cfg.Args) {
			name = cfg.Args[i+1]
		}
	}
	if ext {
		return name
	}
	return ""
}

func (a *App) playwrightProfileMatches(requested string) bool {
	if a.mcp == nil {
		return false
	}
	cfg, ok := a.mcp.Config("playwright")
	if !ok {
		return false
	}
	running := configuredPlaywrightProfile(cfg)
	if running == "" {
		return false
	}
	// Local State can resolve a display name such as zelpyrndev to Default.
	directory := requested
	if !profileDirectoryExact.MatchString(requested) && a.pc != nil {
		resolved, err := a.pc.ResolveChromeProfile(requested)
		if err != nil {
			return false
		}
		directory = resolved
	}
	return strings.EqualFold(strings.ReplaceAll(running, "-", " "), strings.ReplaceAll(directory, "-", " "))
}

// Set extension mode without changing the installed Node binary or its package.
func setPlaywrightExtensionArgs(args []string, profile string) []string {
	out := make([]string, 0, len(args)+2)
	skip := false
	for _, arg := range args {
		if skip {
			skip = false
			continue
		}
		if arg == "--extension" || arg == "--isolated" || strings.HasPrefix(arg, "--profile-dir-name=") || strings.HasPrefix(arg, "--cdp-endpoint=") || strings.HasPrefix(arg, "--storage-state=") {
			continue
		}
		if arg == "--profile-dir-name" || arg == "--cdp-endpoint" || arg == "--user-data-dir" || arg == "--storage-state" || arg == "--browser" {
			skip = true
			continue
		}
		if strings.HasPrefix(arg, "--browser=") || strings.HasPrefix(arg, "--user-data-dir=") {
			continue
		}
		out = append(out, arg)
	}
	if profile != "" {
		out = append(out, "--extension", "--profile-dir-name="+profile)
	}
	return out
}

// prepareChromeBrowserSession resolves an explicitly requested profile and
// connects the Playwright MCP to that user's existing Chrome session. Opening
// chrome.exe with --profile-directory does NOT attach a Playwright browser.
// For explicitly authenticated workflows we fail closed if this connection
// cannot be prepared; silently launching a new browser is unsafe and useless.
func (a *App) prepareChromeBrowserSession(request string) (bool, error) {
	if preferredMCP(request) != "playwright" {
		return false, nil
	}
	requested := chromeProfileRequested(request)
	if requested == "" {
		return false, nil
	}
	if a.pc == nil || a.mcp == nil {
		return true, errors.New("Chrome/Playwright nao configurado")
	}
	profile := requested
	if profileDirectoryExact.MatchString(requested) {
		if strings.EqualFold(requested, "default") {
			profile = "Default"
		}
		// A direct directory name must still exist in Local State.
		if resolved, err := a.pc.ResolveChromeProfile(profile); err != nil || !strings.EqualFold(resolved, profile) {
			return true, fmt.Errorf("o diretorio Chrome %q nao pode ser confirmado; execute /perfis para conferir", profile)
		}
	} else {
		resolved, err := a.pc.ResolveChromeProfile(requested)
		if err != nil {
			return true, fmt.Errorf("perfil Chrome %q nao identificado: %w", requested, err)
		}
		profile = resolved
	}
	if a.playwrightProfileMatches(profile) {
		return true, nil
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return true, err
	}
	registry, err := mcp.Load(a.mcpConfigPath, mcp.DefaultRegistry(home, filepath.Join(home, "Downloads", "ASDNA_Horde")))
	if err != nil {
		return true, err
	}
	cfg, ok := registry.Servers["playwright"]
	if !ok || !cfg.Enabled {
		return true, errors.New("Playwright MCP nao configurado ou desativado")
	}
	cfg.Args = setPlaywrightExtensionArgs(cfg.Args, profile)
	registry.Servers["playwright"] = cfg
	if err := mcp.SaveRegistry(a.mcpConfigPath, registry); err != nil {
		return true, err
	}
	a.mcp.Close()
	a.mcp = mcp.New(registry)
	delete(a.mcpApproved, "playwright")
	a.browserTaskApproved = false
	ui.Infof("Perfil Chrome solicitado: %s. Playwright usara a extensao no navegador ja conectado (nao uma sessao separada).", profile)
	return true, nil
}

func browserLoginRequired(request, toolResult string) bool {
	if !webAutomationIntent(request) {
		return false
	}
	// Only stop on unmistakable evidence of an authentication gate; a text
	// mention of 'login' elsewhere in a page must not stop normal browsing.
	r := strings.ToLower(toolResult)
	return strings.Contains(r, "/accounts/login/") ||
		(strings.Contains(r, "entrar no instagram") && strings.Contains(r, `textbox "senha"`)) ||
		(strings.Contains(r, "log in to instagram") && strings.Contains(r, `textbox "password"`))
}

func (a *App) browserConfigCommand(parts []string) {
	if a.mcp == nil {
		ui.Warn("MCP nao configurado.")
		return
	}
	cfg, exists := a.mcp.Config("playwright")
	if !exists {
		ui.Warn("Playwright nao configurado.")
		return
	}
	if len(parts) == 1 || strings.EqualFold(parts[1], "status") {
		if name := configuredPlaywrightProfile(cfg); name != "" {
			ui.Infof("Playwright configurado para o perfil Chrome: %s. A conexao real depende da extensao instalada e autorizada nesse perfil.", name)
		} else {
			ui.Info("Playwright usa um navegador separado. Para reutilizar uma sessao existente, use /perfis e /navegador conectar <nome do perfil>.")
		}
		ui.Info("Extensao oficial: https://playwright.dev/mcp/configuration/browser-extension")
		return
	}
	if len(parts) < 2 {
		return
	}
	command := strings.ToLower(parts[1])
	profile := ""
	switch command {
	case "conectar":
		if len(parts) < 3 {
			ui.Warn("Uso: /navegador conectar <nome ou diretorio do perfil>. Consulte /perfis.")
			return
		}
		profile = strings.Join(parts[2:], " ")
		if !profileDirectoryExact.MatchString(profile) {
			// Resolve user-friendly profile labels rather than guessing.
			dir, err := a.pc.ResolveChromeProfile(profile)
			if err != nil {
				ui.Warnf("Nao identifiquei perfil Chrome: %v. Execute /perfis e use o diretorio real.", err)
				return
			}
			profile = dir
		}
		if strings.EqualFold(profile, "default") {
			profile = "Default"
		}
	case "separado":
		// Optional isolated Playwright-managed profile; does NOT attach to Chrome.
	default:
		ui.Warn("Uso: /navegador status | /navegador conectar <perfil> | /navegador separado")
		return
	}
	home, err := os.UserHomeDir()
	if err != nil {
		ui.Warnf("Perfil: %v", err)
		return
	}
	workspace := filepath.Join(home, "Downloads", "ASDNA_Horde")
	registry, err := mcp.Load(a.mcpConfigPath, mcp.DefaultRegistry(home, workspace))
	if err != nil {
		ui.Warnf("Config MCP: %v", err)
		return
	}
	current := registry.Servers["playwright"]
	current.Args = setPlaywrightExtensionArgs(current.Args, profile)
	registry.Servers["playwright"] = current
	if err := mcp.SaveRegistry(a.mcpConfigPath, registry); err != nil {
		ui.Warnf("Salvar Playwright: %v", err)
		return
	}
	a.mcp.Close()
	a.mcp = mcp.New(registry)
	if a.mcpApproved != nil {
		delete(a.mcpApproved, "playwright")
	}
	a.browserTaskApproved = false
	if profile == "" {
		ui.OK("Playwright voltou ao navegador separado. Sessao Chrome existente nao sera reutilizada.")
	} else {
		ui.OKf("Perfil configurado: %s. Instale/ative a extensao oficial Playwright MCP neste perfil do Chrome e aprove a conexao quando ela solicitar.", profile)
		ui.Info("Instrucoes oficiais: https://playwright.dev/mcp/configuration/browser-extension")
		ui.Info("Teste: /mcp ferramentas playwright")
	}
}

func isRoutineBrowserTool(name string) bool {
	switch name {
	case "browser_navigate", "browser_snapshot", "browser_type", "browser_click", "browser_press_key", "browser_wait_for", "browser_tabs", "browser_hover", "browser_select_option", "browser_take_screenshot":
		return true
	default:
		return false
	}
}

// One meaningful consent covers the specified browser job. We don't switch
// focus back to the terminal between clicks, and browser MCP accesses the DOM.
// Unknown/high-risk MCP tools still require individual approval.
func (a *App) approveBrowserJob(request string) error {
	if a.browserTaskApproved {
		return nil
	}
	message := "Autorizar Playwright a executar ESTE pedido no navegador?\n" + trimString(request, 850) +
		"\nEle podera ler conteudo da pagina e enviar trechos ao modelo remoto, clicar, digitar e realizar os envios explicitamente pedidos. Confirme somente se reconhecer a conta e a acao. Esta autorizacao vale apenas para esta tarefa."
	if !a.confirmPC(message) {
		return errors.New("automacao web nao autorizada")
	}
	a.browserTaskApproved = true
	return nil
}

func isBrowserSessionAction(action pcactions.Action) bool {
	return strings.EqualFold(action.Tool, "mcp_call") && strings.EqualFold(action.Server, "playwright") && isRoutineBrowserTool(action.Name)
}

// Guard against the model switching from DOM automation to unrelated MCPs.
func restrictBrowserTaskMCP(request string, action pcactions.Action) error {
	if preferredMCP(request) != "playwright" {
		return nil
	}
	if action.Tool != "mcp_call" {
		return nil
	}
	if !strings.EqualFold(action.Server, "playwright") {
		return fmt.Errorf("tarefa web deve usar MCP playwright, nao %s", action.Server)
	}
	if !isRoutineBrowserTool(action.Name) {
		return fmt.Errorf("ferramenta %s exige autorizacao separada; para este fluxo use snapshot/navigate/type/click/press_key", action.Name)
	}
	return nil
}
