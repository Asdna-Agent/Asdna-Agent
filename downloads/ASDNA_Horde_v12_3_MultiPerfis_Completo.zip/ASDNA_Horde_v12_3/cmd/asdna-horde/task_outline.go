package main

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/horde"
)

type operationalPlan struct {
	Steps  []string `json:"steps"`
	Checks []string `json:"checks"`
}

// The SELECTED model designs the high-level task outline. The app never treats
// its text as authorization, a file write, or proof of success.
// It asks for short deliverables/verification, not private chain of thought.
func (a *App) modelTaskOutline(request string) string {
	if a.api == nil || !complexAgentRequest(request) || a.config.SelectedModel == "" {
		return ""
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	messages := []horde.Message{
		{Role: "system", Content: `Voce e o planejador do ASDNA. Produza somente JSON valido: {"steps":["entrega concreta",...],"checks":["como verificar",...]}. 2 a 6 passos objetivos. Nao exponha pensamentos privados ou raciocinio detalhado. Nao execute acoes, nao invente arquivos salvos. Considere todos os arquivos e caminhos citados, especialmente quando o usuario pede varios arquivos. Nunca altere o destino informado pelo usuario.`},
		{Role: "user", Content: "Pedido: " + request + "\nDiretorio do projeto anterior (se houver): " + a.recentPath},
	}
	raw, err := a.api.Chat(ctx, a.config.SelectedModel, messages, 420)
	if err != nil {
		return ""
	}
	raw = strings.TrimSpace(raw)
	if strings.HasPrefix(raw, "```") {
		raw = strings.TrimPrefix(raw, "```json")
		raw = strings.TrimPrefix(raw, "```")
		raw = strings.TrimSuffix(raw, "```")
	}
	start, end := strings.Index(raw, "{"), strings.LastIndex(raw, "}")
	if start < 0 || end < start {
		return ""
	}
	var p operationalPlan
	if json.Unmarshal([]byte(raw[start:end+1]), &p) != nil || len(p.Steps) == 0 {
		return ""
	}
	if len(p.Steps) > 6 {
		p.Steps = p.Steps[:6]
	}
	if len(p.Checks) > 3 {
		p.Checks = p.Checks[:3]
	}
	items := []string{}
	for i, s := range p.Steps {
		if s = strings.TrimSpace(s); s != "" {
			items = append(items, "etapa "+strconv.Itoa(i+1)+": "+trimString(s, 180))
		}
	}
	for _, s := range p.Checks {
		if s = strings.TrimSpace(s); s != "" {
			items = append(items, "verificar: "+trimString(s, 180))
		}
	}
	return strings.Join(items, "\n")
}
