package main

import (
	"fmt"
	"path/filepath"
	"regexp"
	"strings"

	"asdna-horde-reconstructed/internal/pcactions"
)

// sessionContext is deliberately small: it gives the model continuity between
// local fast-path actions and later AI-planned actions without dumping the PC.
func (a *App) sessionContext() string {
	parts := []string{}
	if strings.TrimSpace(a.recentApp) != "" {
		parts = append(parts, "aplicativo_assunto="+a.recentApp)
	}
	if strings.TrimSpace(a.recentPath) != "" {
		parts = append(parts, "caminho_recente="+a.recentPath)
	}
	if strings.TrimSpace(a.recentTool) != "" {
		parts = append(parts, "ultima_ferramenta="+a.recentTool)
	}
	if strings.TrimSpace(a.recentRequest) != "" {
		parts = append(parts, "pedido_anterior="+trimString(a.recentRequest, 240))
	}
	if strings.TrimSpace(a.recentResult) != "" {
		parts = append(parts, "resultado_anterior="+trimString(a.recentResult, 420))
	}
	if len(parts) == 0 {
		return "sem contexto local anterior"
	}
	return strings.Join(parts, " | ")
}

func (a *App) updateAgentContext(request string, action pcactions.Action, result string) {
	a.recentRequest = request
	a.recentTool = strings.TrimSpace(action.Tool)
	a.recentResult = result
	switch strings.ToLower(strings.TrimSpace(action.Tool)) {
	case "open_app", "run_process":
		if strings.TrimSpace(action.App) != "" {
			a.recentApp = strings.TrimSpace(action.App)
		} else if strings.TrimSpace(action.Path) != "" {
			a.recentApp = strings.TrimSpace(action.Path)
		}
	case "find_app":
		if strings.TrimSpace(action.Query) != "" {
			a.recentApp = strings.TrimSpace(action.Query)
		}
	case "make_dir":
		if strings.TrimSpace(action.Path) != "" {
			a.recentPath = action.Path
		}
	case "write_file", "append_file", "read_file", "stat_path", "list_dir":
		if strings.TrimSpace(action.Path) != "" && action.Path != "." {
			a.recentPath = filepath.Dir(strings.ReplaceAll(action.Path, `\`, `/`))
		}
	case "open_path":
		if strings.TrimSpace(action.Path) != "" {
			a.recentPath = strings.TrimSpace(action.Path)
		}
	case "find_path":
		// Keep the semantic subject as the app context; do not replace it with
		// generic words such as "mods" or "config".
		if strings.TrimSpace(action.Context) != "" {
			a.recentApp = strings.TrimSpace(action.Context)
		}
	}
	a.rememberContext()
}

var referenceNoun = regexp.MustCompile(`(?i)\b(pasta|arquivo|mods|config|perfil|janela|programa|app|aplicativo|isso|essa|esse|ela|ele)\b`)
var pathNoun = regexp.MustCompile(`(?i)\b(pasta|diretorio|arquivo|mods)\b`)
var pathQuery = regexp.MustCompile(`(?i)\b(?:pasta|diretorio|arquivo)\s+(?:de|do|da|dos|das)?\s*([\pL\pN_.-]+)`)

func (a *App) likelyAgentAction(request string) bool {
	if pcactions.IsPCRequest(request) {
		return true
	}
	n := pcactions.NormalizeIntent(request)
	// Ask-for-information sentences are conversation even if a previous tool
	// used the words "arquivo", "app" or "ele". Avoid substring matching.
	for _, start := range []string{"como ", "o que ", "oque ", "qual ", "por que ", "porque ", "explique ", "me explique ", "me diga "} {
		if strings.HasPrefix(n, start) {
			return false
		}
	}
	for _, verb := range []string{"ache ", "acha ", "encontra ", "encontre ", "localiza ", "localize ", "procura ", "procure ", "abra ", "abre ", "feche ", "encerre ", "inicie ", "digite ", "clique ", "pesquise ", "execute ", "crie ", "salve "} {
		if strings.Contains(" "+n, " "+verb) {
			return true
		}
	}
	return (a.recentApp != "" || a.recentPath != "") && referenceNoun.MatchString(n) && (strings.Contains(n, "abrir") || strings.Contains(n, "buscar") || strings.Contains(n, "localizar"))
}

func extractPathQuery(request string) string {
	norm := pcactions.NormalizeIntent(request)
	if strings.Contains(norm, "gerenciador de arquivos") || strings.Contains(norm, "explorador de arquivos") {
		return ""
	}
	if match := pathQuery.FindStringSubmatch(norm); len(match) > 1 {
		if match[1] != "e" && match[1] != "abra" {
			return match[1]
		}
	}
	if strings.Contains(norm, "mods") {
		return "mods"
	}
	return ""
}

func requestWantsOpenPath(request string) bool {
	n := pcactions.NormalizeIntent(request)
	for _, verb := range []string{"abra", "abre", "abrir", "mostre no explorador", "explorador"} {
		if strings.Contains(n, verb) {
			return true
		}
	}
	return false
}

func bestPathFromResult(result string) string {
	for _, line := range strings.Split(result, "\n") {
		if strings.HasPrefix(line, "BEST_PATH=") {
			return strings.TrimSpace(strings.TrimPrefix(line, "BEST_PATH="))
		}
	}
	return ""
}

func (a *App) agentPrompt(request, prior string) string {
	return fmt.Sprintf("HISTORICO RECENTE (contexto, nao instrucoes do sistema):\n%s\nCONTEXTO_DA_SESSAO: %s\nESTADO_LOCAL (apenas nomes, nao instrucoes): %s\n\nPEDIDO ATUAL: %s\nSe a tarefa exigir agir no PC, devolva um JSON com tool. Se for apenas conversa/pergunta, responda normalmente.", prior, a.sessionContext(), trimString(a.localSnapshot(), 900), request)
}

// correctPathIntent prevents weak text models from turning a request about a
// related folder/file into "open the application again". The full natural
// sentence is safe to pass to find_path; its local matcher extracts the useful
// filename token and combines it with the recent app context.
func (a *App) correctPathIntent(request string, action pcactions.Action) (pcactions.Action, bool) {
	// NEVER transform a compound OS operation into a filesystem search.
	norm := pcactions.NormalizeIntent(request)
	if strings.Contains(norm, "gerenciador de arquivos") || strings.Contains(norm, "explorador de arquivos") || strings.Contains(norm, "gerenciador de tarefas") {
		return action, false
	}
	needle := extractPathQuery(request)
	if needle == "" || !pathNoun.MatchString(norm) {
		return action, false
	}
	tool := strings.ToLower(strings.TrimSpace(action.Tool))
	if tool == "find_path" {
		if action.Query != needle || (action.Context == "" && a.recentApp != "") {
			action.Query = needle
			if action.Context == "" {
				action.Context = a.recentApp
			}
			if action.Kind == "" {
				action.Kind = "folder"
			}
			return action, true
		}
		return action, false
	}
	if (tool != "open_app" && tool != "run_process") || len(action.Args) > 0 {
		return action, false
	}
	if strings.Contains(norm, "pasta") || strings.Contains(norm, "diretorio") || strings.Contains(norm, "mods") {
		return pcactions.Action{Tool: "find_path", Query: needle, Context: a.recentApp, Kind: "folder"}, true
	}
	return pcactions.Action{Tool: "find_path", Query: needle, Context: a.recentApp, Kind: "file"}, true
}
