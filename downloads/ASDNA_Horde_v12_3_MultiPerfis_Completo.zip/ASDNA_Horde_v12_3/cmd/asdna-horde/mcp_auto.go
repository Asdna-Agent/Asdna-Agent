package main

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/ui"
)

func shouldInstallMCP(name string, cfg mcp.Config) bool {
	if name != "filesystem" && name != "playwright" && name != "windows" && name != "sequential-thinking" {
		return false
	}
	if name == "windows" {
		if cfg.Command == "Sbroenne.WindowsMcp.exe" {
			_, err := exec.LookPath(cfg.Command)
			return err != nil
		}
		if filepath.IsAbs(cfg.Command) {
			_, err := os.Stat(cfg.Command)
			return err != nil
		}
		return false
	}
	// These default npx wrappers can download packages implicitly on first start.
	// Replace them with the integrated isolated, explicit-check installer.
	if cfg.Command == "cmd" || cfg.Command == "npx" {
		return true
	}
	if filepath.IsAbs(cfg.Command) {
		if _, err := os.Stat(cfg.Command); err != nil {
			return true
		}
		if len(cfg.Args) > 0 && filepath.IsAbs(cfg.Args[0]) {
			if _, err := os.Stat(cfg.Args[0]); err != nil {
				return true
			}
		}
	}
	return false
}

func (a *App) ensureMCPServer(server string) error {
	cfg, ok := a.mcp.Config(server)
	if !ok || !cfg.Enabled {
		return fmt.Errorf("MCP %s indisponivel/desativado", server)
	}
	if !shouldInstallMCP(server, cfg) {
		return nil
	}
	if !a.config.AutoMCP() {
		return fmt.Errorf("dependencia de %s ausente. Use /mcp instalar %s ou /mcp auto on", server, server)
	}
	// Never loop through installers if a dependency cannot be downloaded.
	if a.autoInstallAttempt == nil {
		a.autoInstallAttempt = make(map[string]bool)
	}
	if a.autoInstallAttempt[server] {
		return fmt.Errorf("instalacao automatica de %s ja foi tentada nesta sessao", server)
	}
	a.autoInstallAttempt[server] = true
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	dir, err := storage.Dir()
	if err != nil {
		return err
	}
	ui.Infof("Preparando MCP %s sob demanda. Apenas fontes oficiais, sem direitos de administrador.", server)
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	installer := mcp.Installer{Root: filepath.Join(dir, "mcp-runtime"), ConfigPath: a.mcpConfigPath, Home: home,
		Workspace: filepath.Join(home, "Downloads", "ASDNA_Horde"), Progress: func(s string) { ui.Info(s) }}
	installed, err := installer.Install(ctx, []string{server})
	if err != nil {
		return fmt.Errorf("instalacao automatica MCP %s: %w", server, err)
	}
	if len(installed) != 1 {
		return fmt.Errorf("instalacao MCP %s nao confirmou instalacao", server)
	}
	registry, err := mcp.Load(a.mcpConfigPath, mcp.DefaultRegistry(home, installer.Workspace))
	if err != nil {
		return err
	}
	a.mcp.Close()
	a.mcp = mcp.New(registry)
	ui.OKf("Dependencia MCP %s instalada e ativada.", server)
	return nil
}

func (a *App) mcpAutoCommand(args []string) {
	if len(args) < 3 {
		state := "ligado"
		if !a.config.AutoMCP() {
			state = "desligado"
		}
		ui.Infof("Download de MCPs sob demanda: %s. Use /mcp auto on|off", state)
		return
	}
	arg := strings.ToLower(args[2])
	var on bool
	switch arg {
	case "on", "ligar", "ativar":
		on = true
	case "off", "desligar", "desativar":
		on = false
	default:
		ui.Warn("Use /mcp auto on ou /mcp auto off")
		return
	}
	a.config.SetAutoMCP(on)
	if err := storage.SaveConfig(a.config); err != nil {
		ui.Errf("Nao salvou: %v", err)
		return
	}
	if on {
		ui.OK("Instalacao automatica sob demanda ATIVA para os MCPs conhecidos (apos autorizar iniciar o servidor).")
	} else {
		ui.OK("Instalacao automatica de MCP DESATIVADA.")
	}
}
