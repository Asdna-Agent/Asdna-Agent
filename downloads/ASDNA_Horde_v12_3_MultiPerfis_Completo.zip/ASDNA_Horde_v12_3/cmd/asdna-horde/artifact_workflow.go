package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/ui"
)

var artifactQuoted = regexp.MustCompile(`(?:["“'])([^"”']+)(?:["”'])`)
var artifactFilename = regexp.MustCompile(`(?i)(?:[a-z]:[\\/])?(?:[\pL\pN_.-]+[\\/])*[\pL\pN_.-]+\.[a-z][a-z0-9]{0,8}`)
var artifactVerb = regexp.MustCompile(`\b(crie|cria|criar|gere|gera|gerar|faca|faz|fazer|monte|construa|escreva|salve|produza|desenvolva)\b`)
var artifactZipVerb = regexp.MustCompile(`\b(compacte|compactar|compacta|zipar|zipe|empacote|empacotar)\b`)
var artifactFolderVerb = regexp.MustCompile(`\b(pasta|diretorio)\b`)
var htmlTagRe = regexp.MustCompile(`(?s)<[^>]*>`)

// Explicit paths are extracted from the user's request, never invented by a
// model. Quoted filename paths take priority over unquoted standalone names.
func requestedFiles(request string) []string {
	items := []string{}
	seen := map[string]bool{}
	add := func(s string) {
		s = strings.TrimSpace(strings.Trim(s, `"'“”.,;:!?`))
		if s == "" || len(s) > 500 || !artifactFilename.MatchString(s) {
			return
		}
		// Quoted segments must be paths or exact filenames, not paragraphs.
		if strings.ContainsAny(s, "\r\n") {
			return
		}
		if !seen[strings.ToLower(s)] {
			items = append(items, s)
			seen[strings.ToLower(s)] = true
		}
	}
	for _, m := range artifactQuoted.FindAllStringSubmatch(request, -1) {
		if len(m) > 1 && artifactFilename.MatchString(m[1]) && artifactFilename.FindString(m[1]) == m[1] {
			add(m[1])
		}
	}
	for _, m := range artifactFilename.FindAllString(request, -1) {
		add(m)
	}
	return items
}

// Complete a bare filename with an explicitly named Windows destination.
// Other named locations are left to the tool planner to discover instead of
// silently writing a different directory inside Downloads/ASDNA_Horde.
func creationFileDestination(request, filename string) (string, bool) {
	if strings.ContainsAny(filename, `/\`) {
		return filename, true
	}
	// A separately specified unquoted folder must be preserved too:
	// "Crie a pasta Documents/Projeto e um arquivo index.html".
	// Parse only the folder phrase, never infer a destination from unrelated prose.
	folderRe := regexp.MustCompile(`(?i)\b(?:pasta|diretorio)\s+(?:chamad[ao]\s+|de\s+nome\s+)?([\pL\pN_.-]+(?:[\\/][\pL\pN_.-]+)+)`)
	if m := folderRe.FindStringSubmatch(request); len(m) > 1 {
		folder := strings.TrimRight(strings.TrimSpace(m[1]), `/\`)
		if folder != "" {
			return folder + "/" + filename, true
		}
	}
	// Quoted folder locations can be supplied independently of the filename.
	// Example: crie index.html em "Documents/Wiki Aleatoria".
	for _, m := range artifactQuoted.FindAllStringSubmatch(request, -1) {
		if len(m) < 2 {
			continue
		}
		folder := strings.TrimSpace(m[1])
		if strings.ContainsAny(folder, `/\`) && filepath.Ext(strings.ReplaceAll(folder, `\`, `/`)) == "" {
			return strings.TrimRight(folder, `/\`) + "/" + filename, true
		}
	}
	norm := pcactions.NormalizeIntent(request)
	for _, alias := range []struct {
		names  []string
		folder string
	}{
		{[]string{"area de trabalho", "desktop"}, "Desktop"},
		{[]string{"meus documentos", "documentos", "documents"}, "Documents"},
		{[]string{"downloads", "download"}, "Downloads"},
		{[]string{"minhas imagens", "imagens", "pictures"}, "Pictures"},
		{[]string{"onedrive"}, "OneDrive"},
		{[]string{"appdata", "roaming"}, "AppData"},
	} {
		for _, name := range alias.names {
			if strings.Contains(norm, "na "+name) || strings.Contains(norm, "no "+name) || strings.Contains(norm, "em "+name) || strings.Contains(norm, "para "+name) || strings.Contains(norm, "pasta "+name) {
				return alias.folder + "/" + filename, true
			}
		}
	}
	// If user specified a folder separately, don't assume the ASDNA workspace.
	if strings.Contains(norm, "na pasta ") || strings.Contains(norm, "no diretorio ") || strings.Contains(norm, "naquele diretorio ") || strings.Contains(norm, "dentro de ") {
		return filename, false
	}
	return filename, true
}

func fileForCreation(request string) string {
	n := pcactions.NormalizeIntent(request)
	if !pcactions.IsPCRequest(request) || !artifactVerb.MatchString(n) {
		return ""
	}
	for _, name := range requestedFiles(request) {
		if strings.EqualFold(filepath.Ext(name), ".zip") || strings.EqualFold(filepath.Ext(name), ".exe") || strings.EqualFold(filepath.Ext(name), ".dll") {
			continue
		}
		if path, confident := creationFileDestination(request, name); confident {
			return path
		}
		// Leave ambiguous named folders to find_path + planner.
		return ""
	}
	return ""
}

func folderForCreation(request string) string {
	n := pcactions.NormalizeIntent(request)
	if !pcactions.IsPCRequest(request) || !artifactVerb.MatchString(n) || !artifactFolderVerb.MatchString(n) || len(requestedFiles(request)) > 0 {
		return ""
	}
	// Dedicated folder creation; a vague command without a destination is left to the agent.
	for _, m := range artifactQuoted.FindAllStringSubmatch(request, -1) {
		if len(m) > 1 && !strings.Contains(m[1], ".") && !strings.ContainsAny(m[1], "\r\n") {
			return strings.TrimSpace(m[1])
		}
	}
	re := regexp.MustCompile(`(?i)\b(?:pasta|diretorio)\s+(?:chamada?\s+|nomeada?\s+|de\s+nome\s+|em\s+)?([\pL\pN_.\\/-]+)`)
	if m := re.FindStringSubmatch(request); len(m) > 1 {
		candidate := m[1]
		if candidate != "de" && candidate != "do" && candidate != "da" && candidate != "para" && candidate != "no" {
			return candidate
		}
	}
	return ""
}

// Extract a source and optional destination for deterministic ZIP operations.
// "em"/"para" separates target if both paths are present.
func zipRequestPaths(request string) (string, string, bool) {
	n := pcactions.NormalizeIntent(request)
	if !pcactions.IsZipRequest(request) || !artifactZipVerb.MatchString(n) && !strings.Contains(n, ".zip") {
		return "", "", false
	}
	files := requestedFiles(request)
	dest := ""
	for _, item := range files {
		if strings.EqualFold(filepath.Ext(item), ".zip") {
			dest = item
			break
		}
	}
	// If a path is explicitly quoted, prefer it as the source.
	quoted := artifactQuoted.FindAllStringSubmatch(request, -1)
	source := ""
	for _, m := range quoted {
		if len(m) > 1 && m[1] != dest && !strings.HasSuffix(strings.ToLower(m[1]), ".zip") && !strings.ContainsAny(m[1], "\r\n") {
			source = m[1]
			break
		}
	}
	if source == "" {
		for _, f := range files {
			if f != dest {
				source = f
				break
			}
		}
	}
	// The source might be a folder without an extension.
	if source == "" {
		re := regexp.MustCompile(`(?i)\b(?:pasta|diretorio|arquivo)\s+(?:de\s+|do\s+|da\s+)?(?:["“']?)([\pL\pN_.\\/-]+)`)
		if m := re.FindStringSubmatch(request); len(m) > 1 {
			source = m[1]
		}
	}
	if source == "" {
		return "", "", false
	}
	if dest == "" {
		name := strings.TrimSuffix(source, filepath.Ext(source))
		if name == "" {
			return "", "", false
		}
		dest = name + ".zip"
	}
	return source, dest, true
}

func cleanGeneratedText(raw, ext string) string {
	value := strings.TrimSpace(raw)
	if code, lang, ok := pcactions.ExtractCode(value); ok && (lang == "txt" || ext == "."+lang || strings.EqualFold(lang, "html") && ext == ".htm") {
		return code
	}
	return value + "\n"
}

func validateGeneratedText(request, ext, body string) error {
	if !utf8.ValidString(body) || strings.ContainsRune(body, 0) || strings.TrimSpace(body) == "" {
		return fmt.Errorf("o modelo nao forneceu texto valido")
	}
	if len(body) > 64*1024 {
		return fmt.Errorf("conteudo excede limite de 64 KB")
	}
	if ext == ".html" || ext == ".htm" {
		low := strings.ToLower(body)
		if !strings.Contains(low, "<html") || !strings.Contains(low, "</html>") {
			return fmt.Errorf("HTML incompleto: faltam abertura/fechamento de html")
		}
		n := pcactions.NormalizeIntent(request)
		if strings.Contains(n, "botao") && !strings.Contains(low, "<button") {
			return fmt.Errorf("faltou o botao solicitado")
		}
		if strings.Contains(n, "3 linhas") || strings.Contains(n, "tres linhas") {
			// Verify >=3 meaningful lines/sentences of visible prose, excluding markup.
			stripped := htmlTagRe.ReplaceAllString(body, "\n")
			count := 0
			for _, line := range strings.Split(stripped, "\n") {
				if len([]rune(strings.TrimSpace(line))) >= 22 {
					count++
				}
			}
			if count < 3 {
				return fmt.Errorf("faltaram tres linhas de texto explicativo (encontradas %d)", count)
			}
		}
	}
	return nil
}

func (a *App) generateFileText(request, path string) (string, error) {
	if a.config.SelectedModel == "" {
		return "", fmt.Errorf("selecione um modelo Horde antes de criar conteudo")
	}
	ext := strings.ToLower(filepath.Ext(path))
	system := `Voce gera o CONTEUDO DE UM UNICO ARQUIVO. Retorne SOMENTE o texto completo e pronto para gravar, sem introducao, sem explicacao, sem bloco de markdown e sem JSON de ferramentas. Cumpra todos os requisitos do pedido. Para HTML escreva <!DOCTYPE html>, html/head/body completos, estilo se couber, e fechamento </html>. Nao afirme que salvou; o aplicativo local fara isso.`
	msgs := []horde.Message{{Role: "system", Content: system}, {Role: "user", Content: fmt.Sprintf("Crie o CONTEUDO de %s de acordo com este pedido (NAO mude o destino):\n%s\nTexto UTF-8, arquivo completo. Se houver minimo de linhas ou botao, cumpra-o de verdade.", path, request)}}
	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		stop := ui.Thinking(a.config.SelectedModel)
		ctx, cancel := context.WithTimeout(context.Background(), 135*time.Second)
		tokens := a.config.MaxTokens
		if tokens < 1200 {
			tokens = 1200
		}
		if tokens > 4096 {
			tokens = 4096
		}
		raw, err := a.api.Chat(ctx, a.config.SelectedModel, msgs, tokens)
		cancel()
		stop()
		if err != nil {
			return "", fmt.Errorf("geracao pela Horde: %w", err)
		}
		content := cleanGeneratedText(raw, ext)
		if err = validateGeneratedText(request, ext, content); err == nil {
			return content, nil
		}
		lastErr = err
		// Ask for a complete rewrite; do not send untrusted file content to another system.
		msgs = append(msgs, horde.Message{Role: "user", Content: "Seu conteudo anterior NAO pode ser salvo: " + err.Error() + ". Reescreva o arquivo COMPLETO e valido atendendo a todos os requisitos. Responda so com o conteudo do arquivo."})
	}
	return "", fmt.Errorf("conteudo rejeitado apos 3 tentativas: %w", lastErr)
}

// Handle explicit create/zip operations before the general-purpose tool planner.
// The planner still handles all other tasks unchanged.
func (a *App) tryArtifactWorkflow(request string) bool {
	if a.tryMultipleArtifactWorkflow(request) {
		return true
	}
	path := fileForCreation(request)
	// Resolve references such as "nessa mesma pasta" using verified local
	// project state, not the default Downloads directory.
	if folder := projectDirectory(request, a.recentPath); folder != "" {
		for _, requested := range requestedFiles(request) {
			if isEditableArtifact(requested) {
				path = strings.TrimSuffix(folder, "/") + "/" + baseNamePortable(requested)
				break
			}
		}
	}
	if path != "" {
		ui.User(request)
		text, err := a.generateFileText(request, path)
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		result, err := a.pc.Execute(pcactions.Action{Tool: "write_file", Path: path, Content: text})
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		ui.OK(result)
		a.updateAgentContext(request, pcactions.Action{Tool: "write_file", Path: path}, result)
		summary := result
		if pcactions.IsZipRequest(request) {
			destination := ""
			for _, item := range requestedFiles(request) {
				if strings.EqualFold(filepath.Ext(item), ".zip") {
					destination = item
					break
				}
			}
			if destination == "" {
				destination = strings.TrimSuffix(path, filepath.Ext(path)) + ".zip"
			}
			tool := "zip_file"
			source := path
			if strings.Contains(pcactions.NormalizeIntent(request), "compacte a pasta") || strings.Contains(pcactions.NormalizeIntent(request), "compactar a pasta") || strings.EqualFold(strings.TrimSuffix(filepath.Base(destination), ".zip"), filepath.Base(filepath.Dir(path))) {
				tool = "zip_dir"
				source = filepath.Dir(path)
			}
			zipResult, zipErr := a.pc.Execute(pcactions.Action{Tool: tool, Path: source, Destination: destination})
			if zipErr != nil {
				ui.Warnf("Arquivo salvo, mas compactacao falhou: %v", zipErr)
				summary += " | ZIP nao criado: " + zipErr.Error()
			} else {
				ui.OK(zipResult)
				summary += " | " + zipResult
			}
		}
		ui.Assistant(a.config.SelectedModel, summary)
		a.recordLocal(request, summary)
		return true
	}
	if folder := folderForCreation(request); folder != "" {
		ui.User(request)
		result, err := a.pc.Execute(pcactions.Action{Tool: "make_dir", Path: folder})
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		ui.OK(result)
		a.updateAgentContext(request, pcactions.Action{Tool: "make_dir", Path: folder}, result)
		ui.Assistant(a.config.SelectedModel, result)
		a.recordLocal(request, result)
		return true
	}
	if source, destination, ok := zipRequestPaths(request); ok {
		ui.User(request)
		// Resolve and check type without the model guessing whether it is a folder.
		full, _, err := a.pc.ResolvedPath(source)
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		info, err := os.Stat(full)
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		tool := "zip_file"
		if info.IsDir() {
			tool = "zip_dir"
		}
		result, err := a.pc.Execute(pcactions.Action{Tool: tool, Path: source, Destination: destination})
		if err != nil {
			a.artifactFailure(request, err)
			return true
		}
		ui.OK(result)
		a.updateAgentContext(request, pcactions.Action{Tool: tool, Path: source, Destination: destination}, result)
		ui.Assistant(a.config.SelectedModel, result)
		a.recordLocal(request, result)
		return true
	}
	return false
}

func (a *App) artifactFailure(request string, err error) {
	ui.Warnf("Nao foi possivel criar/compactar: %v", err)
	a.recordLocal(request, "Criacao/compactacao nao concluida: "+err.Error())
}

// Named source files only. Prevent executing or forging binaries from text.
func isEditableArtifact(name string) bool {
	lower := strings.ToLower(strings.ReplaceAll(name, `\`, `/`))
	switch filepath.Ext(lower) {
	case ".exe", ".dll", ".zip", ".msi", ".jar", ".png", ".jpg", ".jpeg", ".pdf", ".7z":
		return false
	}
	return filepath.Ext(lower) != ""
}

func baseNamePortable(s string) string {
	return filepath.Base(strings.ReplaceAll(s, `\`, `/`))
}
