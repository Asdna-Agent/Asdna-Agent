// Package mcp connects local, opt-in MCP servers over JSON-RPC/stdio.
// It does not download software or send the PC's contents to a server by itself.
package mcp

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

type Config struct {
	Command string   `json:"command"`
	Args    []string `json:"args"`
	Enabled bool     `json:"enabled"`
}
type Registry struct {
	Servers map[string]Config `json:"mcpServers"`
}
type Tool struct {
	Name        string          `json:"name"`
	Description string          `json:"description,omitempty"`
	InputSchema json.RawMessage `json:"inputSchema,omitempty"`
}
type ToolInfo struct {
	Server string
	Tool   Tool
}
type Manager struct {
	mu       sync.Mutex
	entries  map[string]*connection
	registry Registry
}
type connection struct {
	mu     sync.Mutex
	cmd    *exec.Cmd
	in     io.WriteCloser
	out    *bufio.Reader
	stderr bytes.Buffer
	nextID int
}

func sequentialArgs() []string {
	if runtime.GOOS == "windows" {
		return []string{"/c", "npx", "-y", "@modelcontextprotocol/server-sequential-thinking@2.0.0"}
	}
	return []string{"-y", "@modelcontextprotocol/server-sequential-thinking@2.0.0"}
}
func DefaultRegistry(home, base string) Registry {
	// Never silently grant a full system drive to a filesystem server.
	dirs := []string{base}
	// Only expose existing user directories. Windows installations may redirect
	// Documents/Desktop to OneDrive; avoid starting filesystem with invalid roots.
	for _, candidate := range []string{filepath.Join(home, "Documents"), filepath.Join(home, "Desktop"), filepath.Join(home, "Downloads"), filepath.Join(home, "OneDrive", "Documents"), filepath.Join(home, "OneDrive", "Desktop")} {
		if st, err := os.Stat(candidate); err == nil && st.IsDir() {
			dirs = append(dirs, candidate)
		}
	}
	args := []string{"/c", "npx", "-y", "@modelcontextprotocol/server-filesystem"}
	if runtime.GOOS != "windows" {
		args = []string{"-y", "@modelcontextprotocol/server-filesystem"}
	}
	args = append(args, dirs...)
	filesystemCommand := "cmd"
	playwrightCommand := "cmd"
	playwrightArgs := []string{"/c", "npx", "-y", "@playwright/mcp@latest"}
	if runtime.GOOS != "windows" {
		filesystemCommand = "npx"
		playwrightCommand = "npx"
		playwrightArgs = []string{"-y", "@playwright/mcp@latest"}
	}
	return Registry{Servers: map[string]Config{
		"filesystem":          {Command: filesystemCommand, Args: args, Enabled: true},
		"playwright":          {Command: playwrightCommand, Args: playwrightArgs, Enabled: true},
		"sequential-thinking": {Command: playwrightCommand, Args: sequentialArgs(), Enabled: true},
		// Windows MCP is a separate free executable (self-contained .NET release).
		// Its path is discovered from the configured name/PATH or mcp/windows beside the ASDNA executable.
		"windows": {Command: "Sbroenne.WindowsMcp.exe", Args: []string{}, Enabled: true},
	}}
}
func Load(path string, defaults Registry) (Registry, error) {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			return Registry{}, err
		}
		b, err = json.MarshalIndent(defaults, "", "  ")
		if err != nil {
			return Registry{}, err
		}
		if err = os.WriteFile(path, b, 0600); err != nil {
			return Registry{}, err
		}
		return defaults, nil
	}
	if err != nil {
		return Registry{}, err
	}
	var c Registry
	if err = json.Unmarshal(b, &c); err != nil {
		return Registry{}, fmt.Errorf("configuracao MCP invalida: %w", err)
	}
	if c.Servers == nil {
		return Registry{}, errors.New("mcpServers deve conter um objeto")
	}
	// Add new built-in integrations to older configurations without changing
	// any existing server, its permissions or its user-supplied command.
	for name, builtIn := range defaults.Servers {
		if name == "sequential-thinking" {
			if _, exists := c.Servers[name]; !exists {
				c.Servers[name] = builtIn
			}
		}
	}
	return c, nil
}
func New(reg Registry) *Manager { return &Manager{registry: reg, entries: map[string]*connection{}} }
func (m *Manager) Names() []string {
	if m == nil {
		return nil
	}
	out := []string{}
	for n := range m.registry.Servers {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}
func (m *Manager) Config(name string) (Config, bool) {
	if m == nil {
		return Config{}, false
	}
	v, ok := m.registry.Servers[name]
	return v, ok
}
func (m *Manager) Status() []string {
	rows := []string{}
	for _, name := range m.Names() {
		cfg, _ := m.Config(name)
		state := "desativado"
		if cfg.Enabled {
			state = "pronto para conectar"
			if _, err := findCommand(cfg.Command); err != nil {
				state = "dependencia ausente: " + err.Error()
			} else if strings.Contains(strings.Join(cfg.Args, " "), "npx") {
				if _, err := exec.LookPath("npx"); err != nil {
					state = "Node.js/npx ausente (instalacao opcional)"
				} else {
					state = "npx disponivel; pacote pode precisar de instalacao"
				}
			}
		}
		rows = append(rows, fmt.Sprintf("%s: %s (%s)", name, state, cfg.Command))
	}
	return rows
}
func findCommand(program string) (string, error) {
	if program == "" {
		return "", errors.New("comando vazio")
	}
	if path, err := exec.LookPath(program); err == nil {
		return path, nil
	}
	binary, err := os.Executable()
	if err != nil {
		return "", fmt.Errorf("%s nao instalado", program)
	}
	for _, prefix := range []string{filepath.Dir(binary), filepath.Join(filepath.Dir(binary), "mcp", "windows"), filepath.Join(filepath.Dir(binary), "mcp")} {
		p := filepath.Join(prefix, program)
		if info, err := os.Stat(p); err == nil && !info.IsDir() {
			return p, nil
		}
	}
	return "", fmt.Errorf("%s nao encontrado no PATH ou junto ao ASDNA", program)
}
func (m *Manager) connect(ctx context.Context, name string) (*connection, error) {
	if m == nil {
		return nil, errors.New("MCP nao configurado")
	}
	cfg, ok := m.registry.Servers[name]
	if !ok {
		return nil, fmt.Errorf("servidor MCP desconhecido: %s", name)
	}
	if !cfg.Enabled {
		return nil, fmt.Errorf("servidor MCP %s desativado", name)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if c := m.entries[name]; c != nil {
		return c, nil
	}
	executable, err := findCommand(cfg.Command)
	if err != nil {
		return nil, fmt.Errorf("MCP %s: %w", name, err)
	}
	cmd := exec.Command(executable, cfg.Args...)
	cmd.Env = os.Environ()
	c := &connection{cmd: cmd}
	cmd.Stderr = &c.stderr
	c.in, err = cmd.StdinPipe()
	if err != nil {
		return nil, err
	}
	pipe, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	c.out = bufio.NewReaderSize(pipe, 1<<16)
	if err = cmd.Start(); err != nil {
		return nil, fmt.Errorf("iniciando MCP %s: %w", name, err)
	}
	if err = c.init(ctx); err != nil {
		c.close()
		return nil, fmt.Errorf("MCP %s nao iniciou: %w (%s)", name, err, clip(c.stderr.String(), 500))
	}
	m.entries[name] = c
	return c, nil
}
func (c *connection) close() {
	_ = c.in.Close()
	if c.cmd.Process != nil {
		_ = c.cmd.Process.Kill()
		_ = c.cmd.Wait()
	}
}
func (m *Manager) discard(name string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if c := m.entries[name]; c != nil {
		c.close()
		delete(m.entries, name)
	}
}
func (m *Manager) Close() {
	if m == nil {
		return
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	for n, c := range m.entries {
		c.close()
		delete(m.entries, n)
	}
}

type rpcResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  json.RawMessage `json:"result"`
	Error   *struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func (c *connection) rpc(ctx context.Context, method string, params any) (json.RawMessage, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.nextID++
	id := c.nextID
	req := map[string]any{"jsonrpc": "2.0", "id": id, "method": method}
	if params != nil {
		req["params"] = params
	}
	b, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	if _, err = c.in.Write(append(b, '\n')); err != nil {
		return nil, err
	}
	result := make(chan struct {
		b   json.RawMessage
		err error
	}, 1)
	go func() {
		for i := 0; i < 50; i++ {
			line, err := c.out.ReadBytes('\n')
			if err != nil {
				result <- struct {
					b   json.RawMessage
					err error
				}{nil, err}
				return
			}
			if len(line) > 8<<20 {
				result <- struct {
					b   json.RawMessage
					err error
				}{nil, errors.New("resposta MCP excessiva")}
				return
			}
			var res rpcResponse
			if json.Unmarshal(line, &res) != nil || len(res.ID) == 0 {
				continue
			} // notifications do not complete the RPC
			if string(res.ID) != fmt.Sprint(id) {
				continue
			}
			if res.Error != nil {
				result <- struct {
					b   json.RawMessage
					err error
				}{nil, fmt.Errorf("MCP %d: %s", res.Error.Code, res.Error.Message)}
				return
			}
			result <- struct {
				b   json.RawMessage
				err error
			}{res.Result, nil}
			return
		}
		result <- struct {
			b   json.RawMessage
			err error
		}{nil, errors.New("muitas notificacoes MCP")}
	}()
	select {
	case v := <-result:
		return v.b, v.err
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}
func (c *connection) init(ctx context.Context) error {
	initParams := map[string]any{"protocolVersion": "2025-06-18", "capabilities": map[string]any{}, "clientInfo": map[string]string{"name": "ASDNA", "version": "10.0"}}
	if _, err := c.rpc(ctx, "initialize", initParams); err != nil {
		return err
	}
	msg := []byte(`{"jsonrpc":"2.0","method":"notifications/initialized"}` + "\n")
	_, err := c.in.Write(msg)
	return err
}
func (m *Manager) ListTools(ctx context.Context, name string) ([]Tool, error) {
	c, err := m.connect(ctx, name)
	if err != nil {
		return nil, err
	}
	tools := []Tool{}
	cursor := ""
	for page := 0; page < 8; page++ {
		var params any = map[string]any{}
		if cursor != "" {
			params = map[string]any{"cursor": cursor}
		}
		res, err := c.rpc(ctx, "tools/list", params)
		if err != nil {
			m.discard(name)
			return nil, err
		}
		var data struct {
			Tools []Tool `json:"tools"`
			Next  string `json:"nextCursor"`
		}
		if err = json.Unmarshal(res, &data); err != nil {
			return nil, err
		}
		tools = append(tools, data.Tools...)
		cursor = data.Next
		if cursor == "" {
			break
		}
	}
	return tools, nil
}
func (m *Manager) CallTool(ctx context.Context, name, tool string, arguments json.RawMessage) (string, error) {
	if tool == "" {
		return "", errors.New("nome de ferramenta MCP vazio")
	}
	if len(arguments) == 0 {
		arguments = []byte(`{}`)
	}
	var args map[string]any
	if json.Unmarshal(arguments, &args) != nil {
		return "", errors.New("arguments MCP exige objeto JSON")
	}
	defs, err := m.ListTools(ctx, name)
	if err != nil {
		return "", err
	}
	found := false
	for _, d := range defs {
		if d.Name == tool {
			found = true
			break
		}
	}
	if !found {
		return "", fmt.Errorf("ferramenta %q nao oferecida por %s", tool, name)
	}
	c, err := m.connect(ctx, name)
	if err != nil {
		return "", err
	}
	res, err := c.rpc(ctx, "tools/call", map[string]any{"name": tool, "arguments": args})
	if err != nil {
		m.discard(name)
		return "", err
	}
	var output struct {
		Content []struct {
			Type string `json:"type"`
			Text string `json:"text"`
		} `json:"content"`
		IsError    bool `json:"isError"`
		Structured any  `json:"structuredContent"`
	}
	if json.Unmarshal(res, &output) != nil {
		return "", errors.New("resultado MCP nao e JSON valido")
	}
	parts := []string{}
	for _, p := range output.Content {
		if p.Type == "text" && p.Text != "" {
			parts = append(parts, p.Text)
		}
	}
	if output.Structured != nil {
		if b, e := json.Marshal(output.Structured); e == nil {
			parts = append(parts, string(b))
		}
	}
	value := clip(strings.Join(parts, "\n"), 12000)
	if output.IsError {
		return "", fmt.Errorf("MCP %s/%s: %s", name, tool, value)
	}
	return value, nil
}
func clip(s string, n int) string {
	if len(s) > n {
		return s[:n] + " [truncado]"
	}
	return s
}
func WithTimeout(parent context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(parent, 45*time.Second)
}
