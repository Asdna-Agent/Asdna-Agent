package pcactions

import (
	"strings"
	"testing"
)

func TestBackgroundAutomationDoesNotRequireFocus(t *testing.T) {
	cases := []Action{
		{Window: "Bloco de Notas", Operation: "inspect"},
		{Window: "Bloco de Notas", Operation: "read", Target: "editor"},
		{Window: "Bloco de Notas", Operation: "set_text", Target: "editor", Content: "Teste"},
		{Window: "Aplicativo", Operation: "invoke", Target: "Salvar"},
		{Window: "Aplicativo", Operation: "select", Target: "Item"},
		{Window: "Aplicativo", Operation: "toggle", Target: "Opção"},
		{Window: "Aplicativo", Operation: "click", Target: "Salvar"},
		{Window: "Aplicativo", Operation: "type", Target: "Editor", Content: "exemplo"},
	}
	for _, c := range cases {
		script, err := buildDesktopScript(c)
		if err != nil {
			t.Fatalf("%s failed: %v", c.Operation, err)
		}
		if !strings.Contains(script, "UIAutomationClient") || strings.Contains(script, "AppActivate") || strings.Contains(script, "SendKeys") || strings.Contains(script, "SetCursorPos") {
			t.Errorf("%s not background-only: %s", c.Operation, script)
		}
	}
}

func TestBackgroundControlRequiresNamedTarget(t *testing.T) {
	for _, op := range []string{"read", "set_text", "invoke", "select", "toggle"} {
		_, err := buildDesktopScript(Action{Window: "Chrome", Operation: op, Content: "x"})
		if err == nil {
			t.Fatalf("%s without target was allowed", op)
		}
	}
	_, err := buildDesktopScript(Action{Window: "Editor", Operation: "set_text", Target: "editor", Content: ""})
	if err == nil {
		t.Fatal("empty background text was allowed")
	}
}
func TestBackgroundQuotesUserContent(t *testing.T) {
	script, err := buildDesktopScript(Action{Window: "O'Brien", Operation: "set_text", Target: "área'de texto", Content: "mundo'; whoami; '"})
	if err != nil || !strings.Contains(script, "O''Brien") || !strings.Contains(script, "mundo''; whoami; ''") {
		t.Fatalf("unsafe literal quoting: %v %s", err, script)
	}
	if !strings.Contains(script, "ValuePattern") {
		t.Fatal("not using accessibility pattern")
	}
}
func TestForegroundMatchByPartialWindowTitle(t *testing.T) {
	script, err := buildDesktopScript(Action{Window: "Instagram", Operation: "hotkey", Keys: "ctrl+l"})
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(script, "MainWindowTitle.IndexOf") || !strings.Contains(script, "AppActivate([int]$matches[0].Id)") {
		t.Fatal("window matching must be based on process title then pid")
	}
}
