package pcactions

import (
	"errors"
	"fmt"
	"strings"
)

// buildBackgroundDesktopScript uses Windows UI Automation control patterns.
// Unlike SendKeys it does not activate a window, move the mouse or depend on
// which application owns the keyboard focus. Applications without accessible
// controls may require an MCP/browser DOM implementation instead.
func buildBackgroundDesktopScript(action Action) (string, error) {
	win := strings.TrimSpace(action.Window)
	if len(win) < 2 || len(win) > 240 || strings.ContainsAny(win, "\r\n") {
		return "", errors.New("a janela precisa de um titulo valido")
	}
	if action.Admin {
		return "", errors.New("desktop_control nao suporta elevacao")
	}
	operation := strings.ToLower(strings.TrimSpace(action.Operation))
	switch operation {
	case "inspect", "read", "invoke", "set_text", "select", "toggle":
	default:
		return "", errors.New("operacao de segundo plano desconhecida")
	}
	target := strings.TrimSpace(action.Target)
	if operation != "inspect" && (len(target) < 2 || len(target) > 240 || strings.ContainsAny(target, "\r\n")) {
		return "", errors.New("informe target (nome ou AutomationId do controle encontrado com inspect)")
	}
	if operation == "set_text" && (action.Content == "" || len(action.Content) > 8192) {
		return "", errors.New("set_text exige texto com ate 8 KB")
	}
	// Everything from the model is quoted using PowerShell's literal syntax.
	script := `$ErrorActionPreference='Stop'; Add-Type -AssemblyName UIAutomationClient; Add-Type -AssemblyName UIAutomationTypes;
$windowName=` + psLiteral(win) + `;
$matches=@(Get-Process | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero -and $_.MainWindowTitle -and $_.MainWindowTitle.IndexOf($windowName,[System.StringComparison]::OrdinalIgnoreCase) -ge 0 });
if($matches.Count -eq 0){throw 'Janela nao encontrada: '+$windowName};
if($matches.Count -gt 1){$exact=@($matches | Where-Object {$_.MainWindowTitle -eq $windowName}); if($exact.Count -eq 1){$matches=$exact}else{throw 'Multiplas janelas correspondem. Use list_windows e um titulo mais especifico: '+(($matches | Select-Object -First 8 -ExpandProperty MainWindowTitle) -join '; ')}};
$root=[System.Windows.Automation.AutomationElement]::FromHandle($matches[0].MainWindowHandle);
if($null -eq $root){throw 'Janela sem arvore acessivel. Tente Windows MCP ou Playwright para sites.'};
$nodes=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition);
`
	if operation == "inspect" {
		return script + `
$items=New-Object System.Collections.Generic.List[object];
$limit=[Math]::Min($nodes.Count,1800);
for($i=0; $i -lt $limit; $i++){
  $el=$nodes.Item($i);
  try { $cur=$el.Current; $name=$cur.Name; $id=$cur.AutomationId; if(-not $name -and -not $id){continue};
    if($items.Count -ge 100){break};
    $items.Add([pscustomobject]@{name=$name; id=$id; kind=$cur.LocalizedControlType; enabled=$cur.IsEnabled})
  } catch {}
};
Write-Output ('JANELA='+$matches[0].MainWindowTitle);
Write-Output ('CONTROLES='+($items|ConvertTo-Json -Compress -Depth 4));
Write-Output 'Use target por nome ou id (prefira ID exato). Conteudo de campos nao e coletado em inspect.'`, nil
	}
	script += `
$wanted=` + psLiteral(target) + `;
$exact=New-Object System.Collections.Generic.List[System.Windows.Automation.AutomationElement];
$partial=New-Object System.Collections.Generic.List[System.Windows.Automation.AutomationElement];
$limit=[Math]::Min($nodes.Count,3500);
for($i=0; $i -lt $limit; $i++){
 $el=$nodes.Item($i);
 try { $cur=$el.Current; if($cur.AutomationId -eq $wanted -or $cur.Name -eq $wanted){$exact.Add($el)}
 else {if(($cur.AutomationId -and $cur.AutomationId.IndexOf($wanted,[System.StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($cur.Name -and $cur.Name.IndexOf($wanted,[System.StringComparison]::OrdinalIgnoreCase) -ge 0)){$partial.Add($el)}} } catch {}
};
$found=$exact; if($found.Count -eq 0){$found=$partial};
if($found.Count -eq 0){throw 'Controle nao encontrado: '+$wanted+'. Primeiro use desktop_control inspect.'};
if($found.Count -gt 1){throw 'Controle ambiguo: '+$wanted+'. Especifique o AutomationId exato com inspect.'};
$node=$found[0];
if(-not $node.Current.IsEnabled){throw 'Controle desativado: '+$wanted};
$obj=$null;
`
	switch operation {
	case "read":
		// Do not read password input fields or send secrets to remote models.
		return script + `if($node.Current.IsPassword){throw 'Campo de senha protegido'};
if($node.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern,[ref]$obj)){Write-Output ('VALOR='+$obj.Current.Value)}
elseif($node.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern,[ref]$obj)){Write-Output ('TEXTO='+$obj.DocumentRange.GetText(4000))}
else{Write-Output ('CONTROLE='+$node.Current.Name+' (sem valor acessivel)')}`, nil
	case "set_text":
		return script + `if($node.Current.IsPassword){throw 'Nao preenche senhas com automacao em segundo plano'};
if(-not $node.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern,[ref]$obj)){throw 'Controle nao oferece ValuePattern. Use a ferramenta MCP apropriada; nao enviar teclas globais.'};
if($obj.Current.IsReadOnly){throw 'Campo e somente leitura'};
$obj.SetValue(` + psLiteral(action.Content) + `);
Write-Output ('Texto definido no controle '+$wanted+' sem ativar a janela')`, nil
	case "invoke":
		return script + `if(-not $node.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$obj)){throw 'Controle nao oferece InvokePattern; tente select ou Windows MCP.'};
$obj.Invoke(); Write-Output ('Controle acionado em segundo plano: '+$wanted)`, nil
	case "select":
		return script + `if(-not $node.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern,[ref]$obj)){throw 'Controle nao oferece SelectionItemPattern'};
$obj.Select(); Write-Output ('Controle selecionado: '+$wanted)`, nil
	case "toggle":
		return script + `if(-not $node.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$obj)){throw 'Controle nao oferece TogglePattern'};
$obj.Toggle(); Write-Output ('Controle alternado: '+$wanted)`, nil
	}
	return "", fmt.Errorf("operacao nao suportada: %s", operation)
}
