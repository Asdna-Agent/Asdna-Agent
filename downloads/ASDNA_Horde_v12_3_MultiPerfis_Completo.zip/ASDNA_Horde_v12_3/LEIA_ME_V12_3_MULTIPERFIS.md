# ASDNA v12.3 — seleção automática de qualquer perfil Chrome

## O que foi corrigido

- O agente não tem um perfil Chrome fixo. A cada pedido de automação web com perfil explícito, identifica o perfil pelo nome mostrado no Chrome ou por `Default`, `Profile 1`, `Profile 8` etc.
- Suporta nomes compostos entre aspas, por exemplo `perfil "Trabalho Escolar"`, e nomes simples sem aspas como `perfil Eduardo`.
- Reconfigura o Playwright MCP para a extensão vinculada ao perfil solicitado, reiniciando a conexão quando necessário.
- Impede a troca silenciosa para um navegador isolado sem login quando você especificou um perfil.
- Não copia cookies, senhas nem pastas de sessão.
- Se a extensão não estiver conectada ou a conta do site não estiver autenticada, interrompe a tarefa em vez de prosseguir com o perfil errado.

## Exemplos (sem configurar perfil manualmente a cada pedido)

- `Abra o Instagram no perfil Eduardo e procure por minha empresa.`
- `Abra o Gmail no perfil Akajajaj e leia a última mensagem.`
- `No Chrome, perfil "Trabalho Escolar", entre no site da escola.`
- `Use o perfil Profile 8 para abrir o Instagram.`

O modelo decide as ações; o programa resolve o perfil e prepara as ferramentas.

## Configuração inicial

1. Abra o perfil desejado no Chrome normal, já conectado ao site relevante.
2. Instale/ative a extensão oficial Playwright Extension nesse perfil. Repita uma única vez por perfil que for usar.
   https://playwright.dev/mcp/configuration/browser-extension
3. Autorize ou faça o pareamento da extensão com o Playwright MCP quando solicitado.
4. Use `/perfis` para ver nomes e diretórios conhecidos do Chrome e `/navegador status` para verificar qual perfil está **configurado** (não equivale a conexão validada).
5. Faça o pedido com o nome do perfil. O ASDNA troca a configuração automaticamente.

Quando o nome for ambíguo, o agente deve rejeitar a seleção em vez de operar na conta errada. O estado de login no site é independente do nome do perfil Chrome.

## Comandos opcionais

`/perfis` — consulta perfis locais.
`/navegador conectar <nome ou diretorio>` — configura explicitamente um perfil para pedidos posteriores.
`/navegador status` — mostra a configuração atual.
`/navegador separado` — volta à sessão isolada do Playwright, que pode não possuir login.

## Limitações e testes

O código passou em `go test ./...` e `go vet ./...`, compilado para Windows amd64 com Go 1.23.2. O acesso real a um Chrome instalado e ao Instagram não foi testado neste ambiente. O envio de mensagens e outras ações externas dependem das ferramentas, de autorização e de uma sessão válida.
