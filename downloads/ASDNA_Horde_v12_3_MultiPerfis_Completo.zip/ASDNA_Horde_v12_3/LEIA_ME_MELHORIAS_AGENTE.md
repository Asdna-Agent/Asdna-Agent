# ASDNA Agente — melhorias de planejamento e memoria

Esta versão é baseada **na v11 MultiAPI enviada**, mantendo os provedores e as 3 integrações MCP existentes. Não altera nem inclui chaves de API.

## O que mudou

1. **Sequential Thinking MCP** (implementação oficial `@modelcontextprotocol/server-sequential-thinking@2.0.0`). Quarto MCP opcional, suportado pelo instalador integrado. Ajuda os modelos em pedidos complexos a organizar, revisar e refinar planos. O MCP não pensa sozinho: é o modelo que escolhe e invoca sua ferramenta. O primeiro uso exige autorização do usuário.
2. **Planejamento pelo próprio modelo** em solicitações complexas que usam o agente geral. O modelo selecionado gera um plano curto e uma lista de verificações antes das ferramentas. Isso consome uma chamada extra de API e pode estar indisponível sob quotas; nesse caso o agente segue o fluxo anterior.
3. **Memória local de projeto** em `%APPDATA%/ASDNA_Code_Horde_v1/contexto_projetos.json`. Salva o último diretório e aplicativo, inclusive entre reinicializações. Não salva conteúdo de arquivos nem senhas.
4. **Criação de vários arquivos em uma solicitação**: por exemplo `index.html` e `style.css` em `Documents/sitesteste`. O modelo escolhido gera cada arquivo, o aplicativo vincula a folha de estilo e confirma a existência dos dois.
5. **Contexto de arquivos**: a continuação `nessa mesma pasta crie style.css` usa o diretório recente em vez de salvar em Downloads por engano.
6. **Histórico de contexto** ampliado para as oito mensagens anteriores no agente, com limite por mensagem para preservar quotas.
7. **Verificação da lista de arquivos solicitados** no modo de ferramentas; não reporta uma tarefa com vários arquivos como concluída se faltar arquivo.
8. **Rótulo da IA** na saída foi tornado neutro, sem afirmar "Horde" quando o provedor é Gemini, Blockrun etc.

## Ativar Sequential Thinking

No Windows, dentro do ASDNA:

```
/mcp instalar sequential-thinking
/mcp ferramentas sequential-thinking
```

Ou instale junto dos outros:

```
/mcp instalar todos
```

Requer Node.js 24 ou posterior; o instalador tem suporte à instalação portátil sob autorização. Instalação feita **sob demanda**, não incluída no EXE nem executada automaticamente na abertura. Sem conexão/instalação, as demais funcionalidades funcionam normalmente. O pacote oficial pode atualizar-se no futuro; esta implementação usa versão 2.0.0.

## Memória

```
/memoria
/memoria limpar
```

A memória é apenas de contexto de projeto. A limpeza desse contexto não remove histórico de chat.

## Exemplo de teste

```
Crie index.html e style.css em Documents/sitesteste para um site azul e branco sobre agricultura com imagem, botão e 10 linhas de texto. Conecte o CSS ao HTML.
Nessa mesma pasta, crie README.md explicando como abrir o site.
/memoria
/mcp ferramentas sequential-thinking
```

## Compilação

```
go test ./...
set GOOS=windows
set GOARCH=amd64
go build -trimpath -o ASDNA_Horde_Agentes_Memoria_Thinking.exe ./cmd/asdna-horde
```

O binário entregue foi compilado para Windows x64, mas a execução real no PC do usuário e chamadas de API/MCP de terceiros **não foram testadas neste ambiente**. Testes automatizados locais e validação da compilação estão detalhados no pacote.

Use apenas servidores MCP confiáveis. Ações sensíveis mantêm as autorizações existentes; autorizar envio de conteúdos para provedores remotos pode expor dados pessoais.
