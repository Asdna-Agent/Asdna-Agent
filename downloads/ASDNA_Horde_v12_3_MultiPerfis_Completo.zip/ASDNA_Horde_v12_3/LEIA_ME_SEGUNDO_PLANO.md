# ASDNA v12.1 — controle de janelas em segundo plano

Esta revisão preserva os provedores, a memória e os MCPs da v12. A IA **continua escolhendo as ferramentas**. Não existe uma regra obrigando Playwright em todas as tarefas web.

## Problema corrigido

O `desktop_control` antigo ativava a janela com `AppActivate`, dependia de `SendKeys` e de foco e podia falhar depois de cada confirmação `SIM` no terminal. A busca de janela agora consulta os títulos reais e resolve o PID antes de ativar no modo legado, evitando falhas como buscar somente "Instagram" quando o título é "(1) Instagram - Google Chrome".

## Operações nativas de fundo

O modelo pode chamar as seguintes ações JSON, de acordo com os resultados observados:

- `{"tool":"desktop_control","window":"Bloco de Notas","operation":"inspect"}`: lista até 100 controles da árvore de acessibilidade, sem ativar a janela.
- `{"tool":"desktop_control","window":"Bloco de Notas","operation":"read","target":"Editor de texto"}`: lê um controle que exponha `ValuePattern` ou `TextPattern`, excluindo senhas.
- `{"tool":"desktop_control","window":"Bloco de Notas","operation":"set_text","target":"Editor de texto","content":"Olá"}`: preenche um controle com `ValuePattern`, sem depender do foco.
- `{"tool":"desktop_control","window":"Bloco de Notas","operation":"invoke","target":"Salvar"}`: executa `InvokePattern` no controle identificado.
- `select` e `toggle` são alternativas, conforme os padrões expostos pela interface.

Também é possível fornecer `target` com `type` ou `click`; eles usam respectivamente `set_text` e `invoke` **sem clique global**. Os nomes de controle acima são exemplos: o modelo precisa primeiro observar a árvore real com `inspect` e identificar um nome ou AutomationId único.

## Como o agente deve escolher

- Sites e formulários: Playwright MCP (DOM), quando disponível e conectado à sessão correta, pode operar uma aba mesmo sem foco de teclado.
- Aplicativos comuns do Windows: UI Automation nativa ou Windows MCP para controles de acessibilidade acessíveis em segundo plano.
- Arquivos/programas: ferramentas nativas de caminho, arquivo ou processo.
- Ações incompatíveis com acesso em segundo plano: reportar a limitação, não fingir que completou. `hotkey` e cliques por coordenadas ainda são recursos de primeiro plano com autorização; não foram transformados magicamente em interação invisível.

O terminal continua pedindo permissão para ações nativas potencialmente sensíveis, mas essas confirmações não tiram o foco do alvo nas operações por UI Automation, que não precisam do alvo em primeiro plano. O Playwright tem consentimento por tarefa. O sistema não permite acesso a campos de senha pela nova ferramenta de fundo.

## Verificação

- `go test ./...` passou no ambiente de desenvolvimento.
- EXE compilado para Windows amd64 com Go 1.23.2.
- Não houve teste real de UI Automation, Chrome, Playwright ou Instagram num Windows interativo nesta execução. Os recursos dependem de interfaces e permissões de cada aplicativo, e alguns controles não são expostos quando uma janela está minimizada.
