# ASDNA Agente de IA V10.1 — Instalação automática dos três MCPs

**Novo comando:** `/mcp instalar todos` baixa/configura Windows MCP, Playwright MCP e Filesystem MCP (todos gratuitos), com autorização explícita. O instalador usa Node 24 portátil se necessário, sem administrador, e configura os caminhos dos servidores no próprio aplicativo. Para instalar individualmente: `/mcp instalar windows`, `/mcp instalar playwright` ou `/mcp instalar filesystem`.

Ao terminar, verifique com `/mcp status` e `/mcp ferramentas windows` (ou `filesystem` / `playwright`). Os downloads não ocorrem ao abrir o aplicativo. Os modelos Horde, chat, planejador e ferramentas locais da V10 são mantidos.

**Leia `LEIA-ME_V10_1_INSTALADOR.txt` antes de utilizar.** A instalação foi validada com testes de código e arquivos simulados, mas os downloads e a execução dos servidores reais precisam ser testados no Windows do usuário.

---

# ASDNA Horde Desktop V10 — Agente com MCP e memória de tarefas

A V10 preserva os comandos e funcionalidades anteriores. A integração com os servidores externos gratuitos **Windows MCP**, **Playwright MCP** e **Filesystem MCP** foi adicionada ao código Go do agente; os servidores não estão empacotados no EXE e precisam ser instalados separadamente caso você queira ativá-los. Não há contratação de API paga nem instalação de navegador ou runtime sem autorização.

Leia primeiro **LEIA-ME_V10_MCP.txt** para instalação opcional, comandos, custos, limites e segurança. Os testes de protocolo usam servidor simulado: o funcionamento contra os servidores Windows reais depende do ambiente de destino.

---

# ASDNA Horde Desktop V9 — Criação de arquivos, caminhos e ZIP para Windows

Esta versão corrige os erros demonstrados no log da V7, preservando a API AI Horde, a seleção dos modelos, o histórico, a chave configurada e o modo agente. O aplicativo usa o modelo remoto para tarefas abertas; operações suficientemente objetivas podem ser planejadas localmente para evitar loops de modelos menores.

## Comportamentos testados no código

1. `bom dia` e perguntas como `O que um gato come?` seguem para o CHAT da AI Horde. Não recebem o prompt gigante de ferramentas e não acionam buscas locais.
2. `abra o gerenciador de tarefas do meu computador e encerre o gerenciador de arquivos` abre o Gerenciador de Tarefas, depois solicita autorização para encerrar **explorer.exe** (o processo do Windows Explorer). Este segundo passo pode fechar a barra de tarefas e a área de trabalho temporariamente; autorize somente se realmente desejar.
3. `abra o google chrome, no perfil zelp e pesquise por "Oque um gato come?"` gera uma pesquisa em UMA ação. A resolução do perfil considera também os **atalhos Chrome criados no Windows** (como `ZelpyrnDeveloper (Eduardo) - Chrome`, cujo destino é `--profile-directory="Default"`) além dos nomes internos.
4. `abra Minecraft` seguido de `ache a pasta de mods e abra` conserva o contexto e pesquisa a pasta `mods` existente. Abre automaticamente apenas quando há um caminho de alta confiança, para não abrir caches irrelevantes.
5. A detecção da expressão `gerenciador de arquivos` não redireciona mais todo o pedido para `find_path`.

## Como executar

Descompacte o ZIP completo e abra `ASDNA_Horde_Agentes.exe`. Não é necessário Go instalado para usar o EXE. Configurações de chave/modelo previamente salvas continuam no local de configuração usado pelas versões anteriores. O programa usa conexão com a Horde e a disponibilidade/qualidade das respostas depende do modelo selecionado.

Para compilar com Go 1.23+:

```powershell
go test ./...
go build -trimpath -o ASDNA_Horde_Agentes.exe ./cmd/asdna-horde
```

## Limites de verificação

Os testes automatizados executados neste ambiente Linux validam fluxo, planejamento, JSON, equivalência de atalhos, conversa normal e compilação para Windows x64. Não foi possível interagir de verdade com seu Chrome/perfis/processos locais sem executar o EXE em seu PC. O agente não possui leitura visual da tela e não substitui um controle de interface com captura visual.

O encerramento de processos é feito por `taskkill.exe` com nome exato, autorização e bloqueio de nomes críticos do Windows. Ações de administração, downloads, alterações externas ou teclas/mouse continuam com controles específicos.


## V9 — Novas ferramentas e roteamento

Leia `LEIA-ME_V9.txt` para exemplos. A criacao de arquivos agora usa o modelo para escrever o conteudo e o executor local para salvar/verificar. Diretores Windows conhecidos sao resolvidos por pastas reais, e novos subdiretorios sao criados automaticamente. O workflow pode compactar arquivos ou diretorios sem chamar um shell.

## V9.1 — Recuperacao de falhas temporarias da API

A V9.1 faz ate 3 tentativas de requisicoes que falham por EOF/queda de conexao
ou HTTP 502/503/504. Nao repete falhas de credenciais nem HTTP 429.
A criacao de arquivos so e executada depois que o conteudo da IA chega e passa
pela validacao. Veja `LEIA-ME_V9_1.txt`.
