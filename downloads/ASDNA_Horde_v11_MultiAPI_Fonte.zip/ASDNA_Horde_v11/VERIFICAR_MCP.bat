@echo off
chcp 65001 >nul
echo ASDNA - Verificacao local, nao instala nada.
echo.
where node 2>nul && node --version || echo Node.js nao encontrado (Filesystem/Playwright opcionais).
where npx 2>nul || echo npx nao encontrado (Filesystem/Playwright opcionais).
echo.
if exist "%~dp0mcp\windows\Sbroenne.WindowsMcp.exe" (
  echo Windows MCP: executavel detectado junto ao ASDNA
) else (
  echo Windows MCP: nao encontrado em mcp\windows
)
echo.
pause
