package providers

import "testing"

func TestPresets(t *testing.T) {
	for _, test := range []struct {
		name, endpoint string
		anon           bool
	}{
		{"horde", "https://oai.aihorde.net/v1", true},
		{"blockrun", "https://blockrun.ai/api/v1", true},
		{"llmfaucet", "https://api.llmfaucet.dev/v1", true},
		{"openai", "https://api.openai.com/v1", false},
		{"ollama", "http://127.0.0.1:11434/v1", true},
	} {
		p, err := Resolve(test.name, "")
		if err != nil || p.Endpoint != test.endpoint || p.Anonymous != test.anon {
			t.Fatalf("%s: %+v %v", test.name, p, err)
		}
	}
}
