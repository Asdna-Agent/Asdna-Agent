// Package providers contains presets for OpenAI-compatible chat API services.
// Presets are transport configuration, not an endorsement or promise of free access.
package providers

import (
	"fmt"
	"sort"
	"strings"
)

type Preset struct {
	Name        string
	Endpoint    string
	Anonymous   bool
	Description string
	// Fallback are documented selectors used only if the provider's /models
	// endpoint does not exist (not when authentication/network checks fail).
	Fallback []string
}

var presets = map[string]Preset{
	"horde":      {"horde", "https://oai.aihorde.net/v1", true, "Padrao; chave publica 0000000000", nil},
	"blockrun":   {"blockrun", "https://blockrun.ai/api/v1", true, "Modelos gratuitos sem chave; pagos requerem x402 fora deste aplicativo", nil},
	"llmfaucet":  {"llmfaucet", "https://api.llmfaucet.dev/v1", true, "Gateway experimental sem chave; /models pode nao estar implementado", []string{"auto:coding", "auto:smart", "auto:fast", "auto"}},
	"kilo":       {"kilo", "https://ai-gateway.kilo.ai/api/v1", true, "Gateway com modelos gratuitos; outros podem ser pagos", nil},
	"gemini":     {"gemini", "https://generativelanguage.googleapis.com/v1beta/openai", false, "Google Gemini via API OpenAI-compativel; exige chave Gemini", nil},
	"openai":     {"openai", "https://api.openai.com/v1", false, "API OpenAI; cobranca e quotas conforme sua conta", nil},
	"openrouter": {"openrouter", "https://openrouter.ai/api/v1", false, "Roteador OpenAI-compatible; quotas e custos variam", nil},
	"groq":       {"groq", "https://api.groq.com/openai/v1", false, "API Groq; limites e modelos segundo sua conta", nil},
	"deepseek":   {"deepseek", "https://api.deepseek.com/v1", false, "API DeepSeek; faturamento segundo sua conta", nil},
	"ollama":     {"ollama", "http://127.0.0.1:11434/v1", true, "Modelos locais do Ollama, sem pagamento externo", nil},
	"compativel": {"compativel", "", false, "Qualquer servidor que implemente /models e /chat/completions", nil},
}

func Lookup(name string) (Preset, bool) {
	normalized := strings.ToLower(strings.TrimSpace(name))
	if normalized == "custom" || normalized == "personalizado" || normalized == "customizado" {
		normalized = "compativel"
	}
	if normalized == "ai-horde" || normalized == "aihorde" {
		normalized = "horde"
	}
	p, ok := presets[normalized]
	return p, ok
}

func List() []Preset {
	keys := make([]string, 0, len(presets))
	for k := range presets {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := make([]Preset, 0, len(keys))
	for _, k := range keys {
		out = append(out, presets[k])
	}
	return out
}

func Resolve(provider, override string) (Preset, error) {
	p, ok := Lookup(provider)
	if !ok {
		return Preset{}, fmt.Errorf("provedor desconhecido: %s", provider)
	}
	if override != "" {
		p.Endpoint = override
	}
	if p.Endpoint == "" {
		return p, fmt.Errorf("configure /api-url para o provedor %s", p.Name)
	}
	return p, nil
}
