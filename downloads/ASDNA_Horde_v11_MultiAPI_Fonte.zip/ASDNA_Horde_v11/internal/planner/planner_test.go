package planner

import (
	"path/filepath"
	"testing"
)

func TestPlanDurability(t *testing.T) {
	p := Begin("abra um app, depois salve um arquivo e depois compacte a pasta")
	if len(p.Steps) != 3 {
		t.Fatalf("steps: %+v", p.Steps)
	}
	p.Record("write_file", "arquivo salvo", true, 2)
	if p.Steps[1].Status == "verificada" {
		t.Fatal("tool result must not imply verification")
	}
	if e := p.MarkVerified(2, "stat_path confirma arquivo"); e != nil {
		t.Fatal(e)
	}
	filename := filepath.Join(t.TempDir(), "nested", "task.json")
	if e := Save(filename, p); e != nil {
		t.Fatal(e)
	}
	q, e := Load(filename)
	if e != nil {
		t.Fatal(e)
	}
	if len(q.Events) != 1 || q.Steps[1].Status != "verificada" {
		t.Fatalf("reload: %+v", q)
	}
}
