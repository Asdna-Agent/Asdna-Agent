package planner

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// A task is a durable execution journal, not a claim that a model's plan succeeded.
type Step struct {
	Goal     string `json:"goal"`
	Status   string `json:"status"`
	Evidence string `json:"evidence,omitempty"`
}
type Event struct {
	At     time.Time `json:"at"`
	Tool   string    `json:"tool"`
	Result string    `json:"result"`
	Ok     bool      `json:"ok"`
}
type Task struct {
	Created  time.Time `json:"created"`
	Goal     string    `json:"goal"`
	Steps    []Step    `json:"steps"`
	Events   []Event   `json:"events"`
	Finished bool      `json:"finished"`
}

var splitter = regexp.MustCompile(`(?i)(?:\s*,?\s*\b(?:e\s+depois|depois\s+de|depois|em\s+seguida|por\s+fim|finalmente|na\s+sequencia)\b\s*[,;:]?\s*)`)

func Begin(goal string) *Task {
	parts := splitter.Split(goal, -1)
	steps := []Step{}
	for _, part := range parts {
		part = strings.Trim(strings.TrimSpace(part), ".,;:")
		if part != "" {
			steps = append(steps, Step{Goal: part, Status: "pendente"})
		}
	}
	if len(steps) == 0 {
		steps = []Step{{Goal: goal, Status: "pendente"}}
	}
	if len(steps) > 20 {
		steps = steps[:20]
	}
	return &Task{Created: time.Now(), Goal: goal, Steps: steps}
}
func (t *Task) Record(tool, result string, ok bool, step int) {
	if t == nil {
		return
	}
	if len(t.Events) >= 60 {
		t.Events = t.Events[1:]
	}
	if len(result) > 650 {
		result = result[:650]
	}
	t.Events = append(t.Events, Event{At: time.Now(), Tool: tool, Result: result, Ok: ok})
	if step >= 1 && step <= len(t.Steps) {
		s := &t.Steps[step-1]
		if ok {
			s.Status = "executada (verificar resultado)"
		} else {
			s.Status = "falha"
		}
		s.Evidence = fmt.Sprintf("%s: %s", tool, result)
	}
}
func (t *Task) MarkVerified(step int, evidence string) error {
	if t == nil || step < 1 || step > len(t.Steps) {
		return fmt.Errorf("etapa invalida")
	}
	if len(strings.TrimSpace(evidence)) < 4 {
		return fmt.Errorf("evidencia vazia")
	}
	t.Steps[step-1].Status = "verificada"
	t.Steps[step-1].Evidence = evidence
	all := true
	for _, s := range t.Steps {
		if s.Status != "verificada" {
			all = false
			break
		}
	}
	t.Finished = all
	return nil
}
func (t *Task) Prompt() string {
	if t == nil {
		return "sem plano ativo"
	}
	var b strings.Builder
	fmt.Fprintf(&b, "OBJETIVO: %s\nETAPAS (estado nao implica sucesso):\n", t.Goal)
	for i, s := range t.Steps {
		fmt.Fprintf(&b, "%d. [%s] %s\n", i+1, s.Status, s.Goal)
	}
	for _, e := range t.Events {
		if e.Ok {
			fmt.Fprintf(&b, "FERRAMENTA_OK %s: %s\n", e.Tool, e.Result)
		} else {
			fmt.Fprintf(&b, "FERRAMENTA_ERRO %s: %s\n", e.Tool, e.Result)
		}
	}
	return b.String()
}
func Save(path string, t *Task) error {
	if t == nil {
		return nil
	}
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		return e
	}
	b, e := json.MarshalIndent(t, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(path, b, 0600)
}
func Load(path string) (*Task, error) {
	b, e := os.ReadFile(path)
	if e != nil {
		return nil, e
	}
	var t Task
	if e = json.Unmarshal(b, &t); e != nil {
		return nil, e
	}
	return &t, nil
}
