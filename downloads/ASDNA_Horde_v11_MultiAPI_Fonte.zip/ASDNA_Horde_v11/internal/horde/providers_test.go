package horde

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestBlockrunShowsOnlyFreeModels(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "" {
			t.Errorf("anonymous request sent secret header")
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"data":[{"id":"openai/gpt-premium","billing_mode":"paid"},{"id":"nvidia/nemotron-3.5-lightning","billing_mode":"free"},{"id":"cohere/north-mini-code","billing_mode":"free"}]}`))
	}))
	defer srv.Close()
	c, err := NewCompatible("blockrun", srv.URL, "")
	if err != nil {
		t.Fatal(err)
	}
	m, err := c.Models(context.Background())
	if err != nil || len(m) != 2 {
		t.Fatalf("unexpected catalog %+v err %v", m, err)
	}
	for _, v := range m {
		if v.BillingMode != "free" {
			t.Fatalf("non free model %v", v)
		}
	}
}

func TestLLMFaucetCatalogNotImplemented(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Error(w, "not implemented", http.StatusNotFound) }))
	defer srv.Close()
	c, err := NewCompatible("llmfaucet", srv.URL, "")
	if err != nil {
		t.Fatal(err)
	}
	m, err := c.Models(context.Background())
	if err != nil || len(m) != 4 || m[0].ID != "auto:coding" {
		t.Fatalf("fallback %+v: %v", m, err)
	}
}

func TestNoFallbackOnAuthenticationFailure(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Error(w, "unauthorized", 401) }))
	defer srv.Close()
	c, _ := NewCompatible("llmfaucet", srv.URL, "")
	m, err := c.Models(context.Background())
	if err == nil || len(m) > 0 {
		t.Fatalf("unexpected catalog on 401: %+v %v", m, err)
	}
}

func TestNativeToolCallIsParsedNotExecuted(t *testing.T) {
	var requests atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		if !strings.HasSuffix(r.URL.Path, "/chat/completions") {
			http.Error(w, "bad URL", 404)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"choices":[{"message":{"tool_calls":[{"type":"function","function":{"name":"execute_asdna_tool","arguments":"{\"tool\":\"find_path\",\"query\":\"mods\",\"context\":\"Minecraft\"}"}}]}}]}`))
	}))
	defer srv.Close()
	c, _ := NewCompatible("openai", srv.URL, "test-key")
	result, err := c.ChatAgent(context.Background(), "test-model", []Message{{Role: "user", Content: "find mods"}}, 256)
	if err != nil || !strings.Contains(result, `"tool":"find_path"`) {
		t.Fatalf("native tools: %s error=%v", result, err)
	}
	if requests.Load() != 1 {
		t.Fatalf("unexpected requests %d", requests.Load())
	}
}

func TestCompatibleEndpointRejectsRemoteHTTP(t *testing.T) {
	if _, err := NewCompatible("compativel", "http://myapi.example.org/v1", "test"); err == nil {
		t.Fatal("accepted insecure endpoint")
	}
	if _, err := NewCompatible("compativel", "http://127.0.0.1:11434/v1", "test"); err != nil {
		t.Fatal(err)
	}
}

func TestAnonymousKiloFiltersPaidModels(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"data":[{"id":"openai/gpt-premium","pricing":{"prompt":"0.02","completion":"0.1"}},{"id":"kilo-auto/free"},{"id":"another:free"}]}`))
	}))
	defer srv.Close()
	c, _ := NewCompatible("kilo", srv.URL, "")
	ms, err := c.Models(context.Background())
	if err != nil || len(ms) != 2 {
		t.Fatalf("Kilo %+v %v", ms, err)
	}
	for _, m := range ms {
		if m.ID == "openai/gpt-premium" {
			t.Fatal("included paid model in anonymous catalog")
		}
	}
}
