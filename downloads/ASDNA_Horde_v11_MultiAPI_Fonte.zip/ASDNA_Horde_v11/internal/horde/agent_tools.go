package horde

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
)

// ChatAgent requests a single native function call when an OpenAI-compatible
// model supports tools; text-only providers still use the existing JSON protocol.
// A function call is returned as its JSON arguments to the existing validated
// pcactions.ParseFlexibleResponse, never executed directly from the API response.
func (c *Client) ChatAgent(ctx context.Context, model string, messages []Message, maxTokens int) (string, error) {
	if c.Provider == "horde" || c.Provider == "llmfaucet" || c.Provider == "ollama" {
		return c.Chat(ctx, model, messages, maxTokens)
	}
	properties := map[string]any{}
	for _, f := range []string{"tool", "path", "destination", "query", "context", "kind", "app", "profile", "window", "operation", "keys", "command", "url", "content", "server", "name"} {
		properties[f] = map[string]any{"type": "string"}
	}
	properties["admin"] = map[string]any{"type": "boolean"}
	properties["x"] = map[string]any{"type": "integer"}
	properties["y"] = map[string]any{"type": "integer"}
	properties["args"] = map[string]any{"type": "array", "items": map[string]any{"type": "string"}}
	properties["arguments"] = map[string]any{"type": "object", "additionalProperties": true}
	// The single dispatcher schema lets the app support MCP and native tools
	// without exposing arbitrary unregistered host-side functions.
	tool := map[string]any{
		"type": "function",
		"function": map[string]any{
			"name":        "execute_asdna_tool",
			"description": "Execute exatamente UMA ferramenta ASDNA real. Use campos descritos nas instrucoes; para MCP primeiro descubra o schema. Nunca alegue sucesso antes do resultado do host.",
			"parameters":  map[string]any{"type": "object", "properties": properties, "required": []string{"tool"}},
		},
	}
	payload := map[string]any{"model": model, "messages": messages, "max_tokens": maxTokens, "temperature": 0.35, "stream": false, "tools": []any{tool}, "tool_choice": "auto"}
	adjustChatPayload(c.Provider, model, payload)
	b, err := c.requestCompletion(ctx, payload)
	if err != nil {
		lower := strings.ToLower(err.Error())
		// Only fall back for capability errors; do not duplicate billed requests
		// after timeouts, quotas or authentication failures.
		if (strings.Contains(lower, "http 400") || strings.Contains(lower, "http 422")) &&
			(strings.Contains(lower, "tool") || strings.Contains(lower, "function")) {
			return c.Chat(ctx, model, messages, maxTokens)
		}
		return "", err
	}
	var wrapper struct {
		Choices []struct {
			Message struct {
				Content   string `json:"content"`
				ToolCalls []struct {
					Type     string `json:"type"`
					Function struct {
						Name      string `json:"name"`
						Arguments string `json:"arguments"`
					} `json:"function"`
				} `json:"tool_calls"`
			} `json:"message"`
		} `json:"choices"`
	}
	if err := json.Unmarshal(b, &wrapper); err != nil {
		return "", fmt.Errorf("resposta do agente invalida: %w", err)
	}
	if len(wrapper.Choices) == 0 {
		return "", fmt.Errorf("resposta do agente sem choices")
	}
	msg := wrapper.Choices[0].Message
	for _, call := range msg.ToolCalls {
		if call.Function.Name == "execute_asdna_tool" && json.Valid([]byte(call.Function.Arguments)) {
			return call.Function.Arguments, nil
		}
	}
	if strings.TrimSpace(msg.Content) == "" {
		return "", fmt.Errorf("modelo nao retornou conteudo nem chamada de ferramenta valida")
	}
	return strings.TrimSpace(msg.Content), nil
}
