package horde

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestAPIRequestAndModelListing(t *testing.T) {
	var sawAuth bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") == "Bearer key-for-test" {
			sawAuth = true
		}
		if r.URL.Path == "/models" {
			_, _ = w.Write([]byte(`{"data":[{"id":"basic"},{"id":"Qwen2.5-Coder-7B"}]}`))
		} else if r.URL.Path == "/chat/completions" {
			_, _ = w.Write([]byte(`{"choices":[{"message":{"content":"Ola, resposta simulada."}}]}`))
		} else {
			http.Error(w, "not found", 404)
		}
	}))
	defer srv.Close()
	c := New("key-for-test")
	c.Endpoint = srv.URL
	m, err := c.Models(context.Background())
	if err != nil || len(m) != 2 || m[0].ID != "Qwen2.5-Coder-7B" {
		t.Fatalf("models: %v %v", m, err)
	}
	reply, err := c.Chat(context.Background(), m[0].ID, []Message{{Role: "user", Content: "bom dia"}}, 128)
	if err != nil || reply != "Ola, resposta simulada." {
		t.Fatalf("chat: %q %v", reply, err)
	}
	if !sawAuth {
		t.Fatal("authorization header absent")
	}
}
func TestStatusHandling(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(403)
		_, _ = w.Write([]byte("not enough kudos"))
	}))
	defer srv.Close()
	c := New(AnonymousKey)
	c.Endpoint = srv.URL
	_, err := c.Chat(context.Background(), "test", []Message{{Role: "user", Content: "x"}}, 128)
	if err == nil || !strings.Contains(err.Error(), "HTTP 403") {
		t.Fatalf("expected 403; got %v", err)
	}
}
