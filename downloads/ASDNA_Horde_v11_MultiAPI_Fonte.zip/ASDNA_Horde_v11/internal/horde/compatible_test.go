package horde

import (
	"strings"
	"testing"
)

func TestCompatibleNoImplicitPaymentsOrKeyLeak(t *testing.T) {
	c, e := NewCompatible("ollama", "", "")
	if e != nil {
		t.Fatal(e)
	}
	if c.Key != "" || !strings.Contains(c.Endpoint, "127.0.0.1") {
		t.Fatalf("unexpected local config: %+v", c)
	}
	if _, e = NewCompatible("compativel", "http://example.org/v1", ""); e == nil {
		t.Fatal("remote HTTP accepted")
	}
	if _, e = NewCompatible("compativel", "", ""); e == nil {
		t.Fatal("empty provider URL accepted")
	}
}
