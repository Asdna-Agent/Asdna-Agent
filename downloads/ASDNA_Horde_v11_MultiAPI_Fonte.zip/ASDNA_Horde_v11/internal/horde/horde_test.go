package horde

import "testing"

func TestProgrammingRank(t *testing.T) {
	v := []Model{{ID: "basic-model"}, {ID: "koboldcpp/Qwen2.5-Coder-7B-Instruct"}, {ID: "koboldcpp/Qwen2.5-Coder-3B-Instruct"}}
	SortForProgramming(v)
	if v[0].ID != "koboldcpp/Qwen2.5-Coder-7B-Instruct" {
		t.Fatalf("unexpected model order: %#v", v)
	}
}
func TestCompact(t *testing.T) {
	v := CompactMessages([]Message{{Role: "user", Content: "Bom dia"}}, 160)
	if len(v) != 2 || v[1].Content != "Bom dia" {
		t.Fatalf("unexpected compact: %#v", v)
	}
}
