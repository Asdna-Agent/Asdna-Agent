// Package horde provides a small OpenAI-compatible client for AI Horde.
package horde

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"syscall"
	"time"
)

const DefaultEndpoint = "https://oai.aihorde.net/v1"
const AnonymousKey = "0000000000"

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}
type Model struct {
	ID          string          `json:"id"`
	Name        string          `json:"name,omitempty"`
	BillingMode string          `json:"billing_mode,omitempty"`
	Pricing     json.RawMessage `json:"pricing,omitempty"`
}

type Client struct {
	HTTP     *http.Client
	Key      string
	Endpoint string
	Provider string
}

func New(key string) *Client {
	if strings.TrimSpace(key) == "" {
		key = AnonymousKey
	}
	return &Client{HTTP: &http.Client{Timeout: 150 * time.Second}, Key: key, Endpoint: DefaultEndpoint, Provider: "horde"}
}

// Compatible endpoints are opt-in. No paid provider is selected automatically.
func NewCompatible(provider, endpoint, key string) (*Client, error) {
	provider = strings.ToLower(strings.TrimSpace(provider))
	if provider == "" || provider == "horde" {
		return New(key), nil
	}
	if provider == "ollama" && endpoint == "" {
		endpoint = "http://127.0.0.1:11434/v1"
	}
	if endpoint == "" {
		return nil, errors.New("informe a URL OpenAI-compatible do provedor")
	}
	u, e := url.Parse(endpoint)
	if e != nil || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return nil, errors.New("URL de API invalida")
	}
	if u.Scheme != "https" && (u.Scheme != "http" || !(u.Hostname() == "localhost" || u.Hostname() == "127.0.0.1" || u.Hostname() == "::1")) {
		return nil, errors.New("API remota exige HTTPS; HTTP apenas no computador local")
	}
	c := New(key)
	c.Key = key // Do not reuse Horde anonymous key with a different provider.
	c.Endpoint = strings.TrimRight(endpoint, "/")
	c.Provider = provider
	return c, nil
}

// request retries only network interruptions and temporary server failures.
// It rebuilds the request body on every attempt and obeys the caller's deadline.
// Requests which fail with a clear client error (400/401/403/429) are not retried.
func (c *Client) request(ctx context.Context, method, path string, payload any) ([]byte, error) {
	var payloadBytes []byte
	if payload != nil {
		data, err := json.Marshal(payload)
		if err != nil {
			return nil, err
		}
		payloadBytes = data
	}
	endpoint := strings.TrimRight(c.Endpoint, "/") + path
	const attempts = 3
	for attempt := 0; attempt < attempts; attempt++ {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		var reader io.Reader
		if payloadBytes != nil {
			reader = bytes.NewReader(payloadBytes)
		}
		req, err := http.NewRequestWithContext(ctx, method, endpoint, reader)
		if err != nil {
			return nil, err
		}
		if c.Key != "" {
			req.Header.Set("Authorization", "Bearer "+c.Key)
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("User-Agent", "ASDNA-Horde-Reconstruction/1.0")
		res, err := c.HTTP.Do(req)
		if err != nil {
			if attempt < attempts-1 && isTransientNetworkError(err) && ctx.Err() == nil {
				if err := retryDelay(ctx, attempt); err != nil {
					return nil, err
				}
				continue
			}
			if attempt > 0 && isTransientNetworkError(err) {
				return nil, fmt.Errorf("Horde nao respondeu apos %d tentativas (conexao instavel): %w", attempt+1, err)
			}
			return nil, err
		}
		b, readErr := io.ReadAll(io.LimitReader(res.Body, 5<<20))
		closeErr := res.Body.Close()
		if readErr != nil {
			if attempt < attempts-1 && isTransientNetworkError(readErr) && ctx.Err() == nil {
				if err := retryDelay(ctx, attempt); err != nil {
					return nil, err
				}
				continue
			}
			return nil, fmt.Errorf("resposta da Horde interrompida: %w", readErr)
		}
		if closeErr != nil && ctx.Err() != nil {
			return nil, ctx.Err()
		}
		if res.StatusCode < 200 || res.StatusCode >= 300 {
			if (res.StatusCode == 502 || res.StatusCode == 503 || res.StatusCode == 504) && attempt < attempts-1 && ctx.Err() == nil {
				if err := retryDelay(ctx, attempt); err != nil {
					return nil, err
				}
				continue
			}
			msg := strings.TrimSpace(string(b))
			if len(msg) > 650 {
				msg = msg[:650]
			}
			switch res.StatusCode {
			case 401:
				return nil, fmt.Errorf("chave recusada (HTTP 401): %s", msg)
			case 403:
				return nil, fmt.Errorf("pedido recusado (HTTP 403), possivelmente por restricao de Kudos/tokens: %s", msg)
			case 429:
				return nil, fmt.Errorf("limite de velocidade (HTTP 429), tente novamente mais tarde: %s", msg)
			default:
				return nil, fmt.Errorf("HTTP %d: %s", res.StatusCode, msg)
			}
		}
		return b, nil
	}
	return nil, errors.New("Horde indisponivel apos tentativas")
}

func isTransientNetworkError(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) ||
		errors.Is(err, syscall.ECONNRESET) || errors.Is(err, syscall.ECONNABORTED) ||
		errors.Is(err, syscall.EPIPE) {
		return true
	}
	var ne net.Error
	if errors.As(err, &ne) && (ne.Timeout() || ne.Temporary()) {
		return true
	}
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "connection reset") ||
		strings.Contains(msg, "broken pipe") ||
		strings.Contains(msg, "server closed idle connection")
}

func retryDelay(ctx context.Context, attempt int) error {
	delay := time.Duration(400*(1<<attempt)) * time.Millisecond
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-timer.C:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}
func (c *Client) Models(ctx context.Context) ([]Model, error) {
	b, err := c.request(ctx, http.MethodGet, "/models", nil)
	if err != nil {
		// llmfaucet documents /models as planned. Do not treat HTTP 401/403/429
		// or network failures as permission to fabricate a catalog.
		if c.Provider == "llmfaucet" && (strings.Contains(err.Error(), "HTTP 404") || strings.Contains(err.Error(), "HTTP 501") || strings.Contains(err.Error(), "HTTP 405")) {
			return []Model{{ID: "auto:coding"}, {ID: "auto:smart"}, {ID: "auto:fast"}, {ID: "auto"}}, nil
		}
		return nil, err
	}
	var wrapper struct {
		Data []Model `json:"data"`
	}
	if err := json.Unmarshal(b, &wrapper); err != nil {
		return nil, fmt.Errorf("lista de modelos invalida: %w", err)
	}
	seen := map[string]bool{}
	models := make([]Model, 0, len(wrapper.Data))
	for _, m := range wrapper.Data {
		if strings.TrimSpace(m.ID) == "" || seen[m.ID] {
			continue
		}
		// BlockRun's published /models contains paid and free models. The
		// gateway uses x402, unsupported here: never promote paid offerings as
		// if a bearer key would unlock them for free.
		if c.Provider == "blockrun" && strings.ToLower(m.BillingMode) != "free" {
			continue
		}
		if c.Provider == "kilo" && c.Key == "" && !isFreeKilo(m) {
			continue
		}
		models = append(models, m)
		seen[m.ID] = true
	}
	if c.Provider == "kilo" && c.Key == "" && len(models) == 0 {
		// A stable, published no-credit selector; it is not an invented model.
		models = append(models, Model{ID: "kilo-auto/free", BillingMode: "free"})
	}
	SortForProgramming(models)
	return models, nil
}

func isFreeKilo(m Model) bool {
	id := strings.ToLower(m.ID)
	if id == "kilo-auto/free" || strings.HasSuffix(id, ":free") || strings.ToLower(m.BillingMode) == "free" {
		return true
	}
	if len(m.Pricing) == 0 {
		return false
	}
	var pricing map[string]string
	if json.Unmarshal(m.Pricing, &pricing) != nil {
		return false
	}
	_, hasPrompt := pricing["prompt"]
	_, hasCompletion := pricing["completion"]
	if !hasPrompt || !hasCompletion {
		return false
	}
	return isZeroPrice(pricing["prompt"]) && isZeroPrice(pricing["completion"])
}
func isZeroPrice(s string) bool {
	s = strings.TrimSpace(s)
	if s == "0" {
		return true
	}
	if !strings.HasPrefix(s, "0.") {
		return false
	}
	for _, r := range s[2:] {
		if r != '0' {
			return false
		}
	}
	return len(s) > 2
}
func ScoreForProgramming(name string) int {
	s := strings.ToLower(name)
	score := 0
	for token, points := range map[string]int{"coder": 120, "devstral": 115, "codestral": 115, "qwen3": 80, "deepseek": 75, "qwen2.5": 55, "llama": 35, "mistral": 45, "gemma": 30, "instruct": 15, "32b": 32, "72b": 50, "70b": 40, "14b": 18, "7b": 7, "3b": 3} {
		if strings.Contains(s, token) {
			score += points
		}
	}
	return score
}
func SortForProgramming(ms []Model) {
	sort.SliceStable(ms, func(i, j int) bool {
		a, b := ScoreForProgramming(ms[i].ID), ScoreForProgramming(ms[j].ID)
		if a != b {
			return a > b
		}
		return strings.ToLower(ms[i].ID) < strings.ToLower(ms[j].ID)
	})
}
func (c *Client) Chat(ctx context.Context, model string, messages []Message, maxTokens int) (string, error) {
	if model == "" {
		return "", errors.New("nenhum modelo selecionado")
	}
	if maxTokens < 1 || maxTokens > 8192 {
		return "", errors.New("max_tokens fora do limite permitido (1-8192)")
	}
	payload := map[string]any{"model": model, "messages": messages, "max_tokens": maxTokens, "temperature": 0.35, "stream": false}
	adjustChatPayload(c.Provider, model, payload)
	b, err := c.requestCompletion(ctx, payload)
	if err != nil && c.Provider == "horde" && maxTokens > 512 {
		low := strings.ToLower(err.Error())
		if (strings.Contains(low, "http 400") || strings.Contains(low, "http 422")) && (strings.Contains(low, "token") || strings.Contains(low, "max")) {
			payload["max_tokens"] = 512
			b, err = c.requestCompletion(ctx, payload)
		}
	}
	if err != nil {
		return "", err
	}
	var wrapper struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
			Text string `json:"text"`
		} `json:"choices"`
		Error any `json:"error"`
	}
	if err := json.Unmarshal(b, &wrapper); err != nil {
		return "", fmt.Errorf("resposta JSON invalida: %w", err)
	}
	if len(wrapper.Choices) < 1 {
		return "", fmt.Errorf("resposta sem choices: %s", clip(string(b), 300))
	}
	reply := strings.TrimSpace(wrapper.Choices[0].Message.Content)
	if reply == "" {
		reply = strings.TrimSpace(wrapper.Choices[0].Text)
	}
	if reply == "" {
		return "", errors.New("modelo retornou texto vazio")
	}
	return reply, nil
}
func clip(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

// CompactMessages estimates the total request size to avoid large anonymous requests.
// This is approximate (not a tokenizer). It deliberately keeps only a short tail.
func CompactMessages(history []Message, maxTokens int) []Message {
	if maxTokens < 48 {
		maxTokens = 48
	}
	const system = "Voce e ASDNA Code, assistente e agente Windows. Responda em portugues claro e sem emojis. Nao invente testes, resultados nem arquivos. A IA Horde e o provedor padrao; para APIs opcionais o usuario tem /provedores, /provedor NOME, /api-chave, /api-url, /models e /modelo. BlockRun e llmfaucet podem funcionar sem chave, conforme disponibilidade; OpenAI, Gemini e outros exigem a chave do titular e podem cobrar. /models consulta a API selecionada, nunca invente uma lista de modelos. Para operacoes reais no PC, o nucleo do ASDNA oferece ferramentas nativas e MCP; se nao foi executado por ferramentas nao diga que executou."
	budget := 12000 - maxTokens
	if budget < 900 {
		budget = 900
	}
	used := (len(system) + 3) / 4
	selected := []Message{}
	for i := len(history) - 1; i >= 0; i-- {
		m := history[i]
		if m.Role != "user" && m.Role != "assistant" {
			continue
		}
		estimate := (len([]rune(m.Content))+3)/4 + 8
		if estimate > budget-used {
			if len(selected) == 0 { // always retain latest user prompt in abridged form
				maxchars := (budget - used - 8) * 3
				if maxchars < 60 {
					maxchars = 60
				}
				chars := []rune(m.Content)
				if len(chars) > maxchars {
					m.Content = string(chars[:maxchars]) + "\n[texto abreviado]"
				}
				selected = append(selected, m)
			}
			break
		}
		selected = append(selected, m)
		used += estimate
	}
	out := []Message{{Role: "system", Content: system}}
	for i := len(selected) - 1; i >= 0; i-- {
		out = append(out, selected[i])
	}
	return out
}
