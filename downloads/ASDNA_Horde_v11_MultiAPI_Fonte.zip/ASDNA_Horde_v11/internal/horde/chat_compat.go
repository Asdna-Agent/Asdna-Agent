package horde

import (
	"context"
	"net/http"
	"strings"
)

// Recent OpenAI reasoning models reject legacy max_tokens/temperature fields.
// Keep compatibility across older non-reasoning models and clone providers.
func adjustChatPayload(provider, model string, payload map[string]any) {
	if provider != "openai" {
		return
	}
	m := strings.ToLower(model)
	if strings.HasPrefix(m, "o1") || strings.HasPrefix(m, "o3") || strings.HasPrefix(m, "o4") || strings.HasPrefix(m, "gpt-5") || strings.HasPrefix(m, "gpt-6") {
		if v, ok := payload["max_tokens"]; ok {
			delete(payload, "max_tokens")
			payload["max_completion_tokens"] = v
		}
		delete(payload, "temperature")
	}
}

func (c *Client) requestCompletion(ctx context.Context, payload map[string]any) ([]byte, error) {
	b, err := c.request(ctx, http.MethodPost, "/chat/completions", payload)
	if err == nil {
		return b, nil
	}
	lower := strings.ToLower(err.Error())
	if !strings.Contains(lower, "http 400") && !strings.Contains(lower, "http 422") {
		return nil, err
	}
	switch {
	case strings.Contains(lower, "max_completion_tokens") && strings.Contains(lower, "max_tokens"):
		if v, ok := payload["max_tokens"]; ok {
			delete(payload, "max_tokens")
			payload["max_completion_tokens"] = v
		} else if v, ok := payload["max_completion_tokens"]; ok {
			delete(payload, "max_completion_tokens")
			payload["max_tokens"] = v
		}
	case strings.Contains(lower, "temperature"):
		if _, ok := payload["temperature"]; !ok {
			return nil, err
		}
		delete(payload, "temperature")
	default:
		return nil, err
	}
	return c.request(ctx, http.MethodPost, "/chat/completions", payload)
}
