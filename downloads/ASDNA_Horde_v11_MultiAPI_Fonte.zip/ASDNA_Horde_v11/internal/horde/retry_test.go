package horde

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestRetryEOFReplaysChatPostBody(t *testing.T) {
	var called int32
	var first, second string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		data, _ := io.ReadAll(r.Body)
		if atomic.AddInt32(&called, 1) == 1 {
			first = string(data)
			conn, _, err := w.(http.Hijacker).Hijack()
			if err != nil {
				t.Error(err)
				return
			}
			_ = conn.Close() // Causes EOF before any HTTP response
			return
		}
		second = string(data)
		_, _ = w.Write([]byte(`{"choices":[{"message":{"content":"<!DOCTYPE html><html>ok</html>"}}]}`))
	}))
	defer srv.Close()
	client := New(AnonymousKey)
	client.Endpoint = srv.URL
	resp, err := client.Chat(context.Background(), "test", []Message{{Role: "user", Content: "crie index.html"}}, 300)
	if err != nil || !strings.Contains(resp, "<html>") {
		t.Fatalf("should recover after EOF: %q %v", resp, err)
	}
	if n := atomic.LoadInt32(&called); n != 2 {
		t.Fatalf("wanted two attempts, got %d", n)
	}
	if first != second || !strings.Contains(first, "crie index.html") {
		t.Fatalf("retry lost or changed payload")
	}
}

func TestRetryTemporary502503(t *testing.T) {
	var called int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch atomic.AddInt32(&called, 1) {
		case 1:
			w.WriteHeader(502)
		case 2:
			w.WriteHeader(503)
		default:
			_, _ = w.Write([]byte(`{"choices":[{"message":{"content":"ok"}}]}`))
		}
	}))
	defer srv.Close()
	client := New(AnonymousKey)
	client.Endpoint = srv.URL
	resp, err := client.Chat(context.Background(), "test", []Message{{Role: "user", Content: "oi"}}, 50)
	if err != nil || resp != "ok" || called != 3 {
		t.Fatalf("resp %q err %v attempts %d", resp, err, called)
	}
}

func TestNoRetryForCredentialsOrRateLimit(t *testing.T) {
	for _, code := range []int{400, 401, 403, 429} {
		t.Run(http.StatusText(code), func(t *testing.T) {
			var called int
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { called++; w.WriteHeader(code) }))
			defer srv.Close()
			client := New(AnonymousKey)
			client.Endpoint = srv.URL
			_, err := client.Chat(context.Background(), "test", []Message{{Role: "user", Content: "oi"}}, 50)
			if err == nil || called != 1 {
				t.Fatalf("err %v attempts %d", err, called)
			}
		})
	}
}

func TestCancelledRequestSkipsRetry(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	var called int
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		called++
		cancel()
		w.WriteHeader(503)
	}))
	defer srv.Close()
	client := New(AnonymousKey)
	client.Endpoint = srv.URL
	started := time.Now()
	_, err := client.Chat(ctx, "test", []Message{{Role: "user", Content: "oi"}}, 50)
	if err == nil || called != 1 || time.Since(started) > time.Second {
		t.Fatalf("err %v attempts %d", err, called)
	}
}
