package pcactions

import (
	"context"
	"errors"
	"fmt"
	"os/exec"
	"regexp"
	"runtime"
	"strings"
	"time"
)

var processName = regexp.MustCompile(`(?i)^[a-z0-9_.-]{2,100}\.exe$`)

// Deliberately accepts exact image names, never wildcards or arbitrary shell.
// Stopping the Windows shell (explorer.exe) is reversible but disruptive, so
// consent is required independently of the language model.
func (a *Agent) terminateProcess(executable string) (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("encerrar processo exige Windows")
	}
	name := strings.ToLower(strings.TrimSpace(executable))
	if !processName.MatchString(name) {
		return "", errors.New("nome do processo deve ser um executavel exato, ex: explorer.exe")
	}
	for _, critical := range []string{"csrss.exe", "wininit.exe", "winlogon.exe", "lsass.exe", "services.exe", "smss.exe", "system.exe"} {
		if name == critical {
			return "", errors.New("processo critico do Windows nao sera encerrado pelo agente")
		}
	}
	message := fmt.Sprintf("A IA solicita ENCERRAR o processo %s. Aplicacoes ou a interface do Windows podem fechar e dados nao salvos podem ser perdidos. Autorizar?", name)
	if !a.approved(message) {
		return "", errors.New("encerramento de processo recusado pelo usuario")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	output, err := exec.CommandContext(ctx, "taskkill.exe", "/IM", name, "/F").CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("nao foi possivel encerrar %s: %w; %s", name, err, previewText(string(output), 550))
	}
	return "Windows confirmou pedido de encerramento de " + name + ": " + strings.TrimSpace(string(output)), nil
}
