package pcactions

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestProfileAliasFromWindowsShortcut(t *testing.T) {
	temp := t.TempDir()
	t.Setenv("LOCALAPPDATA", temp)
	dir := filepath.Join(temp, "Google", "Chrome", "User Data")
	if err := os.MkdirAll(dir, 0755); err != nil {
		t.Fatal(err)
	}
	state := []byte(`{"profile":{"info_cache":{"Default":{"name":"Eduardo"},"Profile 8":{"name":"Akajajaj"}}}}`)
	if err := os.WriteFile(filepath.Join(dir, "Local State"), state, 0600); err != nil {
		t.Fatal(err)
	}
	a := &Agent{Base: t.TempDir(), appsAt: time.Now(), apps: []AppCandidate{{Name: "ZelpyrnDeveloper (Eduardo) - Chrome", Kind: "shortcut", Target: "C:/Users/Test/Desktop/Zelp Chrome.lnk", Source: `Atalho Windows -> C:\Program Files\Google\Chrome\Application\chrome.exe --profile-directory="Default"`}}}
	if got, err := a.resolveChromeProfile("zelp"); err != nil || got != "Default" {
		t.Fatalf("profile mismatch: %s %v", got, err)
	}
	if got, err := a.resolveChromeProfile("akaj"); err != nil || got != "Profile 8" {
		t.Fatalf("other profile mismatch: %s %v", got, err)
	}
}
func TestTerminateProcessRequiresWindows(t *testing.T) {
	if _, e := (&Agent{Base: t.TempDir()}).terminateProcess("*.exe"); e == nil {
		t.Fatal("invalid")
	}
}
