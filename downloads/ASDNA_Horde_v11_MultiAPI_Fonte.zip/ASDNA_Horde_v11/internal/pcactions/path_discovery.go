package pcactions

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type pathSearchRoot struct {
	Path  string
	Depth int
}

type pathHit struct {
	Path  string
	Kind  string
	Score int
}

func cleanPathKind(kind string) (string, error) {
	kind = strings.ToLower(strings.TrimSpace(kind))
	switch kind {
	case "", "any", "qualquer":
		return "any", nil
	case "folder", "dir", "directory", "pasta", "diretorio":
		return "folder", nil
	case "file", "arquivo":
		return "file", nil
	default:
		return "", fmt.Errorf("kind invalido %q; use folder, file ou any", kind)
	}
}

// Keep exact multiword names intact. The V9.1 implementation kept only the
// final word, so "Asdna Injector[v0.1]" became "1" and matched random caches.
func pathNeedle(query, context string) string {
 q := searchName(query)
 if q == "" { return "" }
 stop := map[string]bool{
  "a":true,"o":true,"as":true,"os":true,"de":true,"da":true,"do":true,"das":true,"dos":true,
  "uma":true,"um":true,"pasta":true,"arquivo":true,"diretorio":true,
  "ache":true,"acha":true,"achar":true,"encontre":true,"encontrar":true,"localize":true,"localizar":true,
  "procure":true,"procurar":true,"abra":true,"abrir":true,"abre":true,"e":true,"depois":true,
  "na":true,"no":true,"area":true,"trabalho":true,"desktop":true,"meu":true,"minha":true,
 }
 ctxWords := map[string]bool{}
 for _, w := range strings.Fields(searchName(context)) { ctxWords[w]=true }
 var keep []string
 for _, w := range strings.Fields(q) {
  if stop[w] || ctxWords[w] { continue }
  keep=append(keep,w)
 }
 if len(keep)==0 { return "" }
 // Ignore isolated version digits for similarity, but retain them for exact
 // matches against names containing the same version.
 return strings.Join(keep, " ")
}

// Require meaningful multiword matches: a single shared version digit must
// never count as a matching folder name. Exact names get priority.
func pathMatchScore(needle, name string) int {
 q, n := searchName(needle), searchName(name)
 if q=="" || n=="" { return 0 }
 if q==n { return 115 }
 if strings.ReplaceAll(q," ","")==strings.ReplaceAll(n," ","") { return 112 }
 qs:=strings.Fields(q)
 ns:=strings.Fields(n)
 if len(qs)==1 { return nameScore(q,n) }
 meaningful:=0
 found:=0
 for _,w:=range qs {
  if len(w)<3 { continue }
  meaningful++
  for _,x:=range ns { if x==w || (len(w)>=4 && strings.HasPrefix(x,w)) { found++;break } }
 }
 if meaningful==0 || found!=meaningful { return 0 }
 score:=78+min(found*5,15)
 if strings.Contains(n,q) { score+=8 }
 return score
}

func appendRoot(roots []pathSearchRoot, seen map[string]bool, path string, depth int) []pathSearchRoot {
	path = strings.TrimSpace(path)
	if path == "" {
		return roots
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return roots
	}
	key := strings.ToLower(filepath.Clean(abs))
	if seen[key] {
		return roots
	}
	st, err := os.Stat(abs)
	if err != nil || !st.IsDir() {
		return roots
	}
	seen[key] = true
	return append(roots, pathSearchRoot{Path: abs, Depth: depth})
}

func defaultPathRoots(base string) []pathSearchRoot {
	seen := map[string]bool{}
	roots := []pathSearchRoot{}
	for _, item := range []struct {
		Env   string
		Depth int
	}{
		{"APPDATA", 6}, {"LOCALAPPDATA", 5}, {"USERPROFILE", 3}, {"PROGRAMDATA", 4},
	} {
		roots = appendRoot(roots, seen, os.Getenv(item.Env), item.Depth)
	}
	home := os.Getenv("USERPROFILE")
	if home == "" {
		home, _ = os.UserHomeDir()
	}
	for _, kind := range []string{"documents", "downloads", "desktop", "pictures", "music", "videos", "onedrive", "public"} {
		roots = appendRoot(roots, seen, userFolder(kind), 5)
	}
	// Keep the home root at a shallow depth to find custom folders without
	// crawling every application cache on the computer.
	roots = appendRoot(roots, seen, home, 3)
	roots = appendRoot(roots, seen, base, 6)
	return roots
}

func contextKnownPaths(context string) []string {
	ctx := searchName(context)
	var out []string
	appdata := os.Getenv("APPDATA")
	local := os.Getenv("LOCALAPPDATA")
	home := os.Getenv("USERPROFILE")
	if home == "" {
		home, _ = os.UserHomeDir()
	}
	if strings.Contains(ctx, "minecraft") {
		out = append(out,
			filepath.Join(appdata, ".minecraft", "mods"),
			filepath.Join(appdata, ".minecraft"),
			filepath.Join(home, "curseforge", "minecraft", "Instances"),
			filepath.Join(appdata, "PrismLauncher", "instances"),
			filepath.Join(appdata, "com.modrinth.theseus", "profiles"),
			filepath.Join(local, "Packages", "Microsoft.4297127D64EC6_8wekyb3d8bbwe", "LocalCache", "Roaming", ".minecraft", "mods"),
		)
	}
	if strings.Contains(ctx, "visual studio code") || ctx == "vscode" || ctx == "vs code" || ctx == "code" {
		out = append(out, filepath.Join(appdata, "Code", "User"), filepath.Join(home, ".vscode"))
	}
	if strings.Contains(ctx, "chrome") {
		out = append(out, filepath.Join(local, "Google", "Chrome", "User Data"))
	}
	if strings.Contains(ctx, "discord") {
		out = append(out, filepath.Join(appdata, "discord"))
	}
	return out
}

func contextPathScore(path, context string) int {
	ctx := searchName(context)
	if ctx == "" {
		return 0
	}
	p := searchName(path)
	best := 0
	for _, w := range strings.Fields(ctx) {
		if len(w) >= 3 && strings.Contains(p, w) {
			best += 7
		}
	}
	if strings.Contains(strings.ReplaceAll(p, " ", ""), strings.ReplaceAll(ctx, " ", "")) {
		best += 15
	}
	if best > 30 {
		best = 30
	}
	return best
}

func pathMatchesKind(entry os.DirEntry, kind string) bool {
	if kind == "any" {
		return true
	}
	if kind == "folder" {
		return entry.IsDir()
	}
	return !entry.IsDir() && entry.Type().IsRegular()
}

func shouldSkipSearchDir(name string) bool {
	n := strings.ToLower(name)
	switch n {
	case "node_modules", ".git", ".svn", "cache", "caches", "temp", "tmp", "crashdumps", "windows.old":
		return true
	}
	return false
}

func relativeDepth(root, path string) int {
	rel, err := filepath.Rel(root, path)
	if err != nil || rel == "." {
		return 0
	}
	return len(strings.Split(filepath.Clean(rel), string(filepath.Separator)))
}

func addPathHit(byPath map[string]pathHit, path, kind string, score int) {
	key := strings.ToLower(filepath.Clean(path))
	if old, ok := byPath[key]; !ok || score > old.Score {
		byPath[key] = pathHit{Path: path, Kind: kind, Score: score}
	}
}

// findPaths performs bounded, read-only filename/directory discovery. It never
// reads file contents. Results are intentionally limited before being sent back
// to the remote model.
func (a *Agent) findPaths(action Action) (string, error) {
	query := strings.TrimSpace(action.Query)
	if query == "" {
		return "", errors.New("find_path exige query")
	}
	if len(query) > 240 || strings.ContainsRune(query, 0) {
		return "", errors.New("query de caminho invalida")
	}
	kind, err := cleanPathKind(action.Kind)
	if err != nil {
		return "", err
	}
	needle := pathNeedle(query, action.Context)
	if needle == "" {
		return "", errors.New("nao foi possivel extrair um nome de pasta/arquivo da query")
	}
	byPath := map[string]pathHit{}

	// High-confidence known locations are checked before recursive search.
	for _, p := range contextKnownPaths(action.Context) {
		if strings.TrimSpace(p) == "" {
			continue
		}
		st, e := os.Stat(p)
		if e != nil {
			continue
		}
		entryKind := "file"
		if st.IsDir() {
			entryKind = "folder"
		}
		if kind != "any" && kind != entryKind {
			continue
		}
		score := pathMatchScore(needle, filepath.Base(p)) + contextPathScore(p, action.Context) + 35
		if score >= 45 {
			addPathHit(byPath, p, entryKind, score)
		}
	}

	var roots []pathSearchRoot
	if strings.TrimSpace(action.Path) != "" {
		p, _, e := a.resolve(action.Path)
		if e != nil {
			return "", e
		}
		st, e := os.Stat(p)
		if e != nil || !st.IsDir() {
			return "", fmt.Errorf("raiz de busca inexistente ou nao e pasta: %s", p)
		}
		roots = []pathSearchRoot{{Path: p, Depth: 8}}
	} else {
		roots = defaultPathRoots(a.Base)
		// If the context resolves to a real executable, search near its install.
		if strings.TrimSpace(action.Context) != "" {
			if c, e := a.resolveApplication(action.Context); e == nil && c.Kind == "exe" && filepath.IsAbs(c.Target) {
				seen := map[string]bool{}
				for _, r := range roots {
					seen[strings.ToLower(filepath.Clean(r.Path))] = true
				}
				roots = appendRoot(roots, seen, filepath.Dir(c.Target), 6)
			}
		}
	}

	checked := 0
	const maxChecked = 22000
	for _, root := range roots {
		if checked >= maxChecked {
			break
		}
		_ = filepath.WalkDir(root.Path, func(p string, entry os.DirEntry, walkErr error) error {
			if walkErr != nil {
				if entry != nil && entry.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}
			if p == root.Path {
				return nil
			}
			depth := relativeDepth(root.Path, p)
			if entry.IsDir() && depth > root.Depth {
				return filepath.SkipDir
			}
			if entry.Type()&os.ModeSymlink != 0 {
				if entry.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}
			if entry.IsDir() && shouldSkipSearchDir(entry.Name()) && pathMatchScore(needle, entry.Name()) < 68 {
				return filepath.SkipDir
			}
			checked++
			if checked >= maxChecked {
				return filepath.SkipAll
			}
			if !pathMatchesKind(entry, kind) {
				return nil
			}
			score := pathMatchScore(needle, entry.Name())
			if score < 68 {
				return nil
			}
			score += contextPathScore(p, action.Context)
			if entry.IsDir() && kind == "folder" {
				score += 4
			}
			addPathHit(byPath, p, map[bool]string{true: "folder", false: "file"}[entry.IsDir()], score)
			return nil
		})
	}

	hits := make([]pathHit, 0, len(byPath))
	for _, h := range byPath {
		hits = append(hits, h)
	}
	sort.Slice(hits, func(i, j int) bool {
		if hits[i].Score != hits[j].Score {
			return hits[i].Score > hits[j].Score
		}
		return len(hits[i].Path) < len(hits[j].Path)
	})
	if len(hits) == 0 {
		return fmt.Sprintf("Nenhum caminho encontrado para query=%q context=%q apos busca local limitada (%d itens examinados).", query, action.Context, checked), nil
	}
	if len(hits) > 20 {
		hits = hits[:20]
	}
	var b strings.Builder
	// Machine-readable high-confidence hint lets the local orchestrator finish
	// "ache X e abra" without spending another model round just to copy a path.
	if hits[0].Score >= 90 && (len(hits) == 1 || hits[0].Score-hits[1].Score >= 10) {
		fmt.Fprintf(&b, "BEST_PATH=%s\n", hits[0].Path)
	}
	fmt.Fprintf(&b, "Caminhos encontrados para query=%q context=%q (melhores primeiro):\n", query, action.Context)
	for _, h := range hits {
		fmt.Fprintf(&b, "%s | %s | score=%d\n", h.Kind, h.Path, h.Score)
	}
	return b.String(), nil
}
