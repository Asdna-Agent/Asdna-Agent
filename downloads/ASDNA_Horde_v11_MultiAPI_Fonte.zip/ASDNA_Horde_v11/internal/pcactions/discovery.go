package pcactions

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"time"
	"unicode"
)

type AppCandidate struct {
	Name    string   `json:"name"`
	Target  string   `json:"target"`
	Kind    string   `json:"kind"`
	Source  string   `json:"source"`
	Aliases []string `json:"aliases,omitempty"`
	Score   int      `json:"-"`
}

// Normalize names without losing word boundaries, accents or executable suffixes.
func searchName(s string) string {
	s = NormalizeIntent(strings.TrimSpace(s))
	for _, ext := range []string{".exe", ".lnk", ".url"} {
		s = strings.TrimSuffix(s, ext)
	}
	var b strings.Builder
	for _, c := range s {
		if unicode.IsLetter(c) || unicode.IsDigit(c) {
			b.WriteRune(c)
		} else {
			b.WriteByte(' ')
		}
	}
	return strings.Join(strings.Fields(b.String()), " ")
}
func nameScore(query, name string) int {
	q, n := searchName(query), searchName(name)
	if q == "" || n == "" {
		return 0
	}
	if q == n {
		return 100
	}
	qc, nc := strings.ReplaceAll(q, " ", ""), strings.ReplaceAll(n, " ", "")
	if qc == nc {
		return 99
	}
	if len(qc) < 2 {
		return 0
	}
	words := strings.Fields(n)
	for _, w := range words {
		if w == q {
			return 94
		}
	}
	if strings.HasPrefix(n, q) {
		return 90
	}
	all := true
	for _, qw := range strings.Fields(q) {
		found := false
		for _, nw := range words {
			if strings.HasPrefix(nw, qw) {
				found = true
				break
			}
		}
		if !found {
			all = false
			break
		}
	}
	if all {
		return 87
	}
	var initials strings.Builder
	for _, w := range words {
		initials.WriteRune([]rune(w)[0])
	}
	if initials.String() == qc {
		return 86
	}
	if len(qc) >= 3 && strings.Contains(nc, qc) {
		return 80
	}
	// Small spelling mistakes are suggestions, never silently selected.
	if len(qc) >= 4 {
		if editDistance(qc, nc) <= 1 || transposed(qc, nc) {
			return 70
		}
		for _, w := range words {
			if editDistance(qc, w) <= 1 || transposed(qc, w) {
				return 68
			}
		}
	}
	return 0
}
func editDistance(a, b string) int {
	x, y := []rune(a), []rune(b)
	row := make([]int, len(y)+1)
	for j := range row {
		row[j] = j
	}
	for i, c := range x {
		prev := row[0]
		row[0] = i + 1
		for j, d := range y {
			old := row[j+1]
			cost := 0
			if c != d {
				cost = 1
			}
			row[j+1] = min(row[j]+1, row[j+1]+1, prev+cost)
			prev = old
		}
	}
	return row[len(y)]
}
func rankApps(query string, apps []AppCandidate) []AppCandidate {
	byTarget := map[string]AppCandidate{}
	for _, c := range apps {
		c.Score = nameScore(query, c.Name)
		for _, alias := range c.Aliases {
			c.Score = max(c.Score, nameScore(query, alias))
		}
		// Executable basename is a useful alias for real file targets only.
		if c.Kind == "exe" {
			c.Score = max(c.Score, nameScore(query, filepath.Base(c.Target)))
		}
		if c.Score == 0 {
			continue
		}
		key := strings.ToLower(c.Kind + ":" + c.Target)
		if old, ok := byTarget[key]; !ok || c.Score > old.Score {
			byTarget[key] = c
		}
	}
	out := make([]AppCandidate, 0, len(byTarget))
	for _, c := range byTarget {
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Score != out[j].Score {
			return out[i].Score > out[j].Score
		}
		if out[i].Name != out[j].Name {
			return out[i].Name < out[j].Name
		}
		return out[i].Target < out[j].Target
	})
	return out
}
func (a *Agent) chooseCandidate(query string, matches []AppCandidate) (AppCandidate, error) {
	if len(matches) == 0 {
		return AppCandidate{}, fmt.Errorf("nenhum aplicativo instalado corresponde a %q. Use find_app ou /apps; para um programa portatil informe o caminho completo. Nao crie arquivos para substituir programas ausentes", query)
	}
	if matches[0].Score >= 80 && (len(matches) == 1 || matches[0].Score-matches[1].Score >= 10) {
		return matches[0], nil
	}
	limit := min(len(matches), 12)
	labels := make([]string, limit)
	for i, c := range matches[:limit] {
		labels[i] = fmt.Sprintf("%s — %s [%s]", c.Name, c.Target, c.Source)
	}
	return AppCandidate{}, fmt.Errorf("nome ambiguo ou aproximado %q. CANDIDATOS_PARA_O_AGENTE (nao pergunte ao usuario por numero):\n%s", query, strings.Join(labels, "\n"))
}

func runDiscoveryScript(script string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	// Force UTF-8 even under Windows PowerShell 5.1 and a Portuguese OEM codepage.
	prefix := "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false); $OutputEncoding=[Console]::OutputEncoding; "
	out, err := exec.CommandContext(ctx, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", prefix+script).Output()
	if ctx.Err() != nil {
		return nil, errors.New("busca de aplicativos excedeu 30 segundos; tente /apps novamente")
	}
	if err != nil {
		return nil, fmt.Errorf("consulta do Windows falhou: %w", err)
	}
	return out, nil
}

// This is read-only discovery. No registry command lines are evaluated.
const appCatalogScript = `
$items = New-Object System.Collections.Generic.List[object]
function AddApp($n,$t,$k,$s,$aliases) {
 if($n -and $t){$items.Add([pscustomobject]@{name=[string]$n;target=[string]$t;kind=$k;source=$s;aliases=@($aliases)})}
}
$roots=@('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths')
foreach($root in $roots){foreach($key in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)){
 $p=[Environment]::ExpandEnvironmentVariables(([string]$key.GetValue('')).Trim('"'))
 if($p -and (Test-Path -LiteralPath $p -PathType Leaf)){AddApp $key.PSChildName $p 'exe' 'Registro App Paths' @()}
}}
$ws=New-Object -ComObject WScript.Shell
$folders=@([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('CommonPrograms'),[Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'))
foreach($folder in $folders){if($folder -and (Test-Path -LiteralPath $folder)){
 foreach($f in @(Get-ChildItem -LiteralPath $folder -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.Extension -in '.lnk','.url'} | Select-Object -First 3000)){
  if($f.Extension -eq '.lnk'){
   try{$link=$ws.CreateShortcut($f.FullName);$target=$link.TargetPath
    if($target -and (Test-Path -LiteralPath $target -PathType Leaf)){
     if(-not $link.Arguments -and $target.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase)){AddApp $f.BaseName $target 'exe' 'Atalho Windows' @([IO.Path]::GetFileName($target))}
     else {AddApp $f.BaseName $f.FullName 'shortcut' ('Atalho Windows -> '+$target+' '+$link.Arguments) @()}
    }
   }catch{}
  }else{AddApp $f.BaseName $f.FullName 'shortcut' 'Atalho Internet/Steam' @()}
 }
}}
if(Get-Command Get-StartApps -ErrorAction SilentlyContinue){foreach($app in @(Get-StartApps -ErrorAction SilentlyContinue)){
 if($app.AppID -match '!'){AddApp $app.Name $app.AppID 'store' 'Menu Iniciar' @()}
}}
$steam=@()
foreach($key in @('HKCU:\Software\Valve\Steam','HKLM:\Software\WOW6432Node\Valve\Steam','HKLM:\Software\Valve\Steam')){
 $v=Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
 if($v.SteamPath){$steam+=$v.SteamPath};if($v.InstallPath){$steam+=$v.InstallPath}
}
$steam+=Join-Path ${env:ProgramFiles(x86)} 'Steam'
foreach($p in @($steam|Select-Object -Unique)){if(Test-Path -LiteralPath (Join-Path $p 'steam.exe')){AddApp 'Steam' (Join-Path $p 'steam.exe') 'exe' 'Steam' @('steam');AddApp 'Steam library' $p 'steamroot' 'Steam' @()}}
foreach($item in @(@('Google Chrome',"$env:ProgramFiles\Google\Chrome\Application\chrome.exe",'chrome'),@('Google Chrome',"${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",'chrome'),@('Google Chrome',"$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",'chrome'),@('Microsoft Edge',"${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",'edge'))){if(Test-Path -LiteralPath $item[1]){AddApp $item[0] $item[1] 'exe' 'Instalacao' @($item[2])}}
foreach($name in @('notepad.exe','calc.exe','cmd.exe','powershell.exe','explorer.exe','mspaint.exe','taskmgr.exe')){$c=Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1;if($c){AddApp $name $c.Source 'exe' 'PATH' @()}}
ConvertTo-Json -InputObject @($items.ToArray()) -Depth 4 -Compress
`

var vdfPathRE = regexp.MustCompile(`"path"\s+"((?:\\.|[^"\\])*)"`)
var vdfFieldRE = regexp.MustCompile(`"(appid|name|installdir)"\s+"([^"\r\n]*)"`)

func steamApps(root string) []AppCandidate {
	roots := []string{root}
	data, _ := os.ReadFile(filepath.Join(root, "steamapps", "libraryfolders.vdf"))
	for _, m := range vdfPathRE.FindAllStringSubmatch(string(data), -1) {
		roots = append(roots, strings.ReplaceAll(m[1], `\\`, `\`))
	}
	var result []AppCandidate
	for _, lib := range roots {
		files, _ := filepath.Glob(filepath.Join(lib, "steamapps", "appmanifest_*.acf"))
		for _, f := range files {
			data, err := os.ReadFile(f)
			if err != nil {
				continue
			}
			fields := map[string]string{}
			for _, m := range vdfFieldRE.FindAllStringSubmatch(string(data), -1) {
				fields[m[1]] = m[2]
			}
			id := fields["appid"]
			if id == "" || strings.Trim(id, "0123456789") != "" || fields["name"] == "" {
				continue
			}
			install := filepath.Join(lib, "steamapps", "common", fields["installdir"])
			if st, err := os.Stat(install); err != nil || !st.IsDir() {
				continue
			}
			c := AppCandidate{Name: fields["name"], Target: "steam://rungameid/" + id, Kind: "steam", Source: "Steam instalado"}
			if id == "10" {
				c.Aliases = []string{"cs", "cs 1.6", "cs16", "counter strike", "counter-strike.exe"}
			}
			result = append(result, c)
			// hl.exe is an actual executable, not a guessed Counter-Strike filename.
			if st, err := os.Stat(filepath.Join(install, "hl.exe")); err == nil && !st.IsDir() {
				result = append(result, AppCandidate{Name: "Half-Life (hl.exe)", Target: filepath.Join(install, "hl.exe"), Kind: "exe", Source: "Steam", Aliases: []string{"hl.exe"}})
			}
		}
	}
	return result
}
func (a *Agent) catalog(refresh bool) ([]AppCandidate, error) {
	if !refresh && len(a.apps) > 0 && time.Since(a.appsAt) < 2*time.Minute {
		return a.apps, nil
	}
	data, err := runDiscoveryScript(appCatalogScript)
	if err != nil {
		return nil, err
	}
	var found []AppCandidate
	if err = json.Unmarshal(data, &found); err != nil {
		return nil, fmt.Errorf("inventario Windows invalido: %w", err)
	}
	var apps []AppCandidate
	for _, c := range found {
		if c.Kind == "steamroot" {
			apps = append(apps, steamApps(c.Target)...)
		} else {
			apps = append(apps, c)
		}
	}
	for i := range apps {
		switch searchName(apps[i].Name) {
		case "visual studio code", "code":
			apps[i].Aliases = append(apps[i].Aliases, "vscode", "vs code", "vsc")
		case "notepad":
			apps[i].Aliases = append(apps[i].Aliases, "bloco de notas", "notas")
		case "calc":
			apps[i].Aliases = append(apps[i].Aliases, "calculadora")
		case "explorer":
			apps[i].Aliases = append(apps[i].Aliases, "explorador", "arquivos")
		case "mspaint":
			apps[i].Aliases = append(apps[i].Aliases, "paint")
		}
	}
	a.apps = apps
	a.appsAt = time.Now()
	return apps, nil
}
func (a *Agent) resolveApplication(query string) (AppCandidate, error) {
	query = strings.TrimSpace(strings.Trim(query, `"`))
	switch searchName(query) {
	case "gerenciador de tarefas", "task manager":
		query = "taskmgr.exe"
	case "gerenciador de arquivos", "explorador de arquivos", "file explorer":
		query = "explorer.exe"
	}
	if query == "" || len(query) > 2048 || strings.ContainsAny(query, "\x00\r\n") {
		return AppCandidate{}, errors.New("nome de aplicativo invalido")
	}
	// Common Windows system executables may not be exposed by the registry.
	if runtime.GOOS == "windows" && (strings.EqualFold(query, "taskmgr.exe") || strings.EqualFold(query, "explorer.exe")) {
		for _, root := range []string{os.Getenv("WINDIR"), os.Getenv("SystemRoot")} {
			if root == "" {
				continue
			}
			sub := "System32"
			if strings.EqualFold(query, "explorer.exe") {
				sub = ""
			}
			target := filepath.Join(root, sub, query)
			if st, e := os.Stat(target); e == nil && !st.IsDir() {
				return AppCandidate{Name: query, Target: target, Kind: "exe", Source: "Windows"}, nil
			}
		}
	}
	if strings.HasPrefix(strings.ToLower(query), "steam://") || strings.Contains(query, "!") {
		apps, err := a.catalog(false)
		if err != nil {
			return AppCandidate{}, err
		}
		for _, c := range apps {
			if (c.Kind == "steam" || c.Kind == "store") && strings.EqualFold(c.Target, query) {
				return c, nil
			}
		}
		return AppCandidate{}, errors.New("destino nao consta no catalogo instalado; use find_app")
	}
	if strings.ContainsAny(query, `\/:`) {
		if !filepath.IsAbs(query) {
			return AppCandidate{}, errors.New("use caminho absoluto para aplicativo fora do catalogo")
		}
		st, err := os.Stat(query)
		if err != nil || st.IsDir() {
			return AppCandidate{}, fmt.Errorf("aplicativo nao encontrado no caminho %q", query)
		}
		return AppCandidate{Name: filepath.Base(query), Target: query, Kind: "exe", Source: "Caminho informado"}, nil
	}
	apps, err := a.catalog(false)
	if err != nil {
		return AppCandidate{}, err
	}
	matches := rankApps(query, apps)
	// An explicit executable name identifies the installed binary, not an
	// unrelated Chrome desktop shortcut mentioning the same executable.
	if strings.HasSuffix(strings.ToLower(query), ".exe") {
		for _, candidate := range matches {
			if candidate.Kind == "exe" && strings.EqualFold(filepath.Base(candidate.Target), query) {
				return candidate, nil
			}
		}
	}
	if len(matches) == 0 {
		if p, e := exec.LookPath(query); e == nil {
			return AppCandidate{Name: query, Target: p, Kind: "exe", Source: "PATH"}, nil
		}
	}
	return a.chooseCandidate(query, matches)
}
func (a *Agent) findApplications(query string) (string, error) {
	apps, err := a.catalog(true)
	if err != nil {
		return "", err
	}
	if strings.TrimSpace(query) != "" {
		apps = rankApps(query, apps)
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Aplicativos encontrados: %d (exibindo ate 30).\n", len(apps))
	for _, c := range apps[:min(len(apps), 30)] {
		fmt.Fprintf(&b, "%s | %s | %s\n", c.Name, c.Target, c.Source)
	}
	return b.String(), nil
}

func transposed(a, b string) bool {
	x, y := []rune(a), []rune(b)
	if len(x) != len(y) {
		return false
	}
	for i := 0; i < len(x)-1; i++ {
		if x[i] != y[i] {
			x[i], x[i+1] = x[i+1], x[i]
			return string(x) == b
		}
	}
	return false
}
