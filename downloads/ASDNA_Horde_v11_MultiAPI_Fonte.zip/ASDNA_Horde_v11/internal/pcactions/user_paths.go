package pcactions

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

// UserPathAliases resolve *explicitly named* Windows locations. Unknown paths
// remain relative to the ASDNA workspace; the agent must search for an
// unfamiliar location rather than silently assume where it lives.
var userPathAliases = map[string]string{
	"documents": "documents", "documentos": "documents", "meus documentos": "documents",
	"downloads": "downloads", "download": "downloads", "baixados": "downloads",
	"desktop": "desktop", "area de trabalho": "desktop", "área de trabalho": "desktop",
	"pictures": "pictures", "imagens": "pictures", "minhas imagens": "pictures", "fotos": "pictures",
	"music": "music", "musicas": "music", "músicas": "music",
	"videos": "videos", "vídeos": "videos",
	"publico": "public", "público": "public", "public": "public",
	"arquivos de programas": "programfiles", "program files": "programfiles",
	"arquivos de programas (x86)": "programfilesx86", "program files (x86)": "programfilesx86",
	"programdata": "programdata", "dados de programas": "programdata",
	"windows": "windows", "system32": "system32",
	"jogos salvos": "savedgames", "saved games": "savedgames",
	"contatos": "contacts", "contacts": "contacts",
	"favoritos": "favorites", "favorites": "favorites",
	"appdata": "appdata", "roaming": "appdata", "localappdata": "localappdata",
	"onedrive": "onedrive", "home": "home", "~": "home", "perfil do usuario": "home", "perfil do usuário": "home",
	"temp": "temp", "tmp": "temp",
}

func userHome() string {
	if h := os.Getenv("USERPROFILE"); h != "" && runtime.GOOS == "windows" {
		return h
	}
	h, _ := os.UserHomeDir()
	return h
}

func userFolder(kind string) string {
	home := userHome()
	if home == "" {
		return ""
	}
	switch kind {
	case "home":
		return home
	case "public":
		return envOrPath("PUBLIC", filepath.Join(filepath.Dir(home), "Public"))
	case "programfiles":
		return envOrPath("ProgramFiles", `C:\Program Files`)
	case "programfilesx86":
		return envOrPath("ProgramFiles(x86)", `C:\Program Files (x86)`)
	case "programdata":
		return envOrPath("PROGRAMDATA", `C:\ProgramData`)
	case "windows":
		return envOrPath("SystemRoot", `C:\Windows`)
	case "system32":
		return filepath.Join(userFolder("windows"), "System32")
	case "savedgames", "contacts", "favorites":
		names := map[string]string{"savedgames": "Saved Games", "contacts": "Contacts", "favorites": "Favorites"}
		return filepath.Join(home, names[kind])
	case "appdata":
		return envOrPath("APPDATA", filepath.Join(home, "AppData", "Roaming"))
	case "localappdata":
		return envOrPath("LOCALAPPDATA", filepath.Join(home, "AppData", "Local"))
	case "onedrive":
		for _, key := range []string{"OneDrive", "OneDriveConsumer", "OneDriveCommercial"} {
			if root := os.Getenv(key); root != "" {
				return root
			}
		}
		return filepath.Join(home, "OneDrive")
	case "temp":
		return os.TempDir()
	case "downloads", "documents", "desktop", "pictures", "music", "videos":
		if actual := knownFolderPath(kind); actual != "" {
			return actual
		}
		fallback := map[string]string{"downloads": "Downloads", "documents": "Documents", "desktop": "Desktop", "pictures": "Pictures", "music": "Music", "videos": "Videos"}[kind]
		return filepath.Join(home, fallback)
	}
	return ""
}

func envOrPath(name, fallback string) string {
	if value := os.Getenv(name); value != "" {
		return value
	}
	return fallback
}

// Expand ~, %APPDATA%, %USERPROFILE% and named user-folder prefixes without
// accidentally changing an absolute drive/UNC path. Never expand arbitrary
// remote-model variables or commands.
func expandUserPath(name string) string {
	name = strings.TrimSpace(strings.Trim(name, `"'“”`))
	if name == "" {
		return name
	}
	if runtime.GOOS == "windows" {
		name = strings.ReplaceAll(name, "/", `\`)
	} else {
		name = filepath.FromSlash(name)
	}
	if filepath.IsAbs(name) {
		return filepath.Clean(name)
	}
	if strings.HasPrefix(name, "%") {
		if end := strings.Index(name[1:], "%"); end >= 0 {
			env := name[1 : end+1]
			values := map[string]string{"USERPROFILE": userHome(), "APPDATA": userFolder("appdata"), "LOCALAPPDATA": userFolder("localappdata"), "ONEDRIVE": userFolder("onedrive"), "TEMP": userFolder("temp"), "TMP": userFolder("temp"), "PUBLIC": userFolder("public"), "PROGRAMFILES": userFolder("programfiles"), "PROGRAMFILES(X86)": userFolder("programfilesx86"), "PROGRAMDATA": userFolder("programdata"), "SYSTEMROOT": userFolder("windows"), "HOMEDRIVE": os.Getenv("HOMEDRIVE")}
			if value := values[strings.ToUpper(env)]; value != "" {
				rest := strings.TrimLeft(name[end+2:], `\/`)
				return filepath.Join(value, rest)
			}
		}
	}
	clean := filepath.Clean(name)
	if clean == "." || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return clean
	}
	// Longest prefix matching supports aliases containing spaces, for example
	// "Área de Trabalho", "Meus Documentos" and "Arquivos de Programas".
	key := strings.ToLower(clean)
	bestAlias, bestKind := "", ""
	for alias, kind := range userPathAliases {
		if key == alias || strings.HasPrefix(key, alias+string(filepath.Separator)) {
			if len(alias) > len(bestAlias) {
				bestAlias, bestKind = alias, kind
			}
		}
	}
	if bestAlias != "" {
		if root := userFolder(bestKind); root != "" {
			rest := strings.TrimLeft(clean[len(bestAlias):], `\/`)
			if rest != "" {
				return filepath.Join(root, rest)
			}
			return root
		}
	}
	return clean
}

// ResolvedPath returns the effective, validated local path and workspace flag.
func (a *Agent) ResolvedPath(name string) (string, bool, error) { return a.resolve(name) }
