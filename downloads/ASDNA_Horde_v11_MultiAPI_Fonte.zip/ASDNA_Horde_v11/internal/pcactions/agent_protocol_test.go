package pcactions

import (
	"archive/zip"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestFlexibleToolFormats(t *testing.T) {
	tests := []string{
		`{"tool":"write_file","path":"main.py","content":"print(1)\\n"}`,
		"```json\n" + `{"tool":"write_file","path":"main.py","content":"print(1)\\n"}` + "\n```",
		`Perfeito! Aqui esta: {"tool":"write_file","path":"main.py","content":"print(1)\\n"}`,
		`<ASDNA_ACTION>{"tool":"write_file","path":"main.py","content":"print(1)\\n"}</ASDNA_ACTION>`,
	}
	for _, sample := range tests {
		got, found, err := ParseFlexibleResponse(sample)
		if err != nil || !found || got.Tool != "write_file" || got.Path != "main.py" {
			t.Fatalf("parsed %+v %v %v for %s", got, found, err, sample)
		}
	}
	_, found, err := ParseFlexibleResponse("criei o arquivo e ele esta disponivel")
	if found || err != nil {
		t.Fatal("plain text was accepted as a tool")
	}
}

func TestFileToZIPAndFind(t *testing.T) {
	base := t.TempDir()
	a := &Agent{Base: base, Confirm: func(string) bool { return true }}
	if _, err := a.Execute(Action{Tool: "write_file", Path: "MeuProjeto/main.py", Content: "print('oi')\n"}); err != nil {
		t.Fatal(err)
	}
	result, err := a.Execute(Action{Tool: "find_file", Path: ".", Query: "main.py"})
	if err != nil || !strings.Contains(result, "main.py") {
		t.Fatalf("find: %q %v", result, err)
	}
	result, err = a.Execute(Action{Tool: "stat_path", Path: "MeuProjeto/main.py"})
	if err != nil || !strings.Contains(result, "VERIFICADO") {
		t.Fatalf("stat: %q %v", result, err)
	}
	if _, err := a.Execute(Action{Tool: "zip_file", Path: "MeuProjeto/main.py", Destination: "main.zip"}); err != nil {
		t.Fatal(err)
	}
	z, err := zip.OpenReader(filepath.Join(base, "main.zip"))
	if err != nil {
		t.Fatal(err)
	}
	defer z.Close()
	if len(z.File) != 1 || z.File[0].Name != "main.py" {
		t.Fatalf("zip files: %+v", z.File)
	}
	if _, err := os.Stat(filepath.Join(base, "main.zip")); err != nil {
		t.Fatal(err)
	}
}
