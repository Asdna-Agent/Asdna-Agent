package pcactions

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestPathNeedleUsesSpecificNoun(t *testing.T) {
	for _, tc := range []struct {
		query, context, want string
	}{
		{"ache a pasta de mods do minecraft e abra", "Minecraft", "mods"},
		{"localize a pasta config do vscode", "vscode", "config"},
		{"procure saves", "", "saves"},
	} {
		if got := pathNeedle(tc.query, tc.context); got != tc.want {
			t.Fatalf("%q/%q => %q, want %q", tc.query, tc.context, got, tc.want)
		}
	}
}

func TestFindPathsUsesApplicationContext(t *testing.T) {
	home := t.TempDir()
	appdata := filepath.Join(home, "AppData", "Roaming")
	local := filepath.Join(home, "AppData", "Local")
	mods := filepath.Join(appdata, ".minecraft", "mods")
	if err := os.MkdirAll(mods, 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("USERPROFILE", home)
	t.Setenv("APPDATA", appdata)
	t.Setenv("LOCALAPPDATA", local)
	t.Setenv("PROGRAMDATA", filepath.Join(home, "ProgramData"))
	a := &Agent{Base: filepath.Join(home, "Downloads", "ASDNA_Horde")}
	out, err := a.findPaths(Action{Tool: "find_path", Query: "mods", Context: "Minecraft", Kind: "folder"})
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out, mods) {
		t.Fatalf("expected %s in %s", mods, out)
	}
}
