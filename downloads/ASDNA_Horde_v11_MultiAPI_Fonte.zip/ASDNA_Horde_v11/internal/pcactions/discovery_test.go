package pcactions

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestNamesAbbreviationsAndTypos(t *testing.T) {
	for _, tc := range []struct {
		query, name string
		min         int
	}{
		{"zelp", "ZelpyrnDeveloper (Eduardo)", 80}, {"edu", "ZelpyrnDeveloper (Eduardo)", 80}, {"Joao", "João", 100},
		{"cs", "Counter-Strike", 80}, {"cs.exe", "Counter-Strike", 80}, {"vsc", "Visual Studio Code", 80},
		{"chorme", "Chrome", 68}, {"chrom", "Google Chrome", 80}, {"stema", "Steam", 68}, {"steem", "Steam", 68},
		{"s", "Steam", 0}, {"garbage", "Steam", 0}, {"Profile 2", "Profile 2", 100},
	} {
		s := nameScore(tc.query, tc.name)
		if tc.min == 0 {
			if s != 0 {
				t.Errorf("%s: unexpected %d", tc.query, s)
			}
		} else if s < tc.min {
			t.Errorf("%s to %s score %d", tc.query, tc.name, s)
		}
	}
}
func TestAmbiguousAppsReturnCandidatesToAgent(t *testing.T) {
	apps := []AppCandidate{{Name: "Counter-Strike", Target: "one"}, {Name: "Counter-Strike 2", Target: "two"}}
	a := &Agent{}
	m := rankApps("counter", apps)
	if _, e := a.chooseCandidate("counter", m); e == nil || !strings.Contains(e.Error(), "CANDIDATOS_PARA_O_AGENTE") {
		t.Fatal("ambiguous target should be returned to the planner", e)
	}
	c, e := (&Agent{}).chooseCandidate("Counter-Strike", rankApps("Counter-Strike", apps))
	if e != nil || c.Target != "one" {
		t.Fatal(c, e)
	}
}
func TestCatalogDeduplicatesSameTarget(t *testing.T) {
	m := rankApps("steam", []AppCandidate{{Name: "Steam", Target: "C:/Steam/steam.exe", Kind: "exe"}, {Name: "steam.exe", Target: "C:/Steam/steam.exe", Kind: "exe"}})
	if len(m) != 1 {
		t.Fatal(m)
	}
}
func TestPartialProfilesAndAmbiguity(t *testing.T) {
	data := []byte(`{"profile":{"info_cache":{"Default":{"name":"Pessoal"},"Profile 2":{"name":"ZelpyrnDeveloper (Eduardo)","user_name":"eduardo@example.com"}}}}`)
	for _, q := range []string{"zelp", "edu", "ZELP", "zelp - Chrome", "Profile 2"} {
		dir, e := findProfileInLocalState(data, q)
		if e != nil || dir != "Profile 2" {
			t.Fatal(q, dir, e)
		}
	}
	duplicate := []byte(`{"profile":{"info_cache":{"Default":{"name":"Zelp pessoal"},"Profile 2":{"name":"Zelp trabalho"}}}}`)
	if _, e := findProfileInLocalState(duplicate, "zelp"); e == nil {
		t.Fatal("ambiguous profiles silently selected")
	}
	if _, e := findProfileInLocalState(data, "no such profile"); e == nil {
		t.Fatal("missing profile selected")
	}
}
func TestSteamManifestsMultipleLibraries(t *testing.T) {
	root := t.TempDir()
	lib := t.TempDir()
	os.MkdirAll(filepath.Join(root, "steamapps"), 0755)
	os.MkdirAll(filepath.Join(lib, "steamapps", "common", "Half-Life"), 0755)
	os.WriteFile(filepath.Join(root, "steamapps", "libraryfolders.vdf"), []byte(`"libraryfolders" { "1" { "path" "`+strings.ReplaceAll(lib, `\`, `\\`)+`" } }`), 0644)
	os.WriteFile(filepath.Join(lib, "steamapps", "appmanifest_10.acf"), []byte(`"AppState" { "appid" "10" "name" "Counter-Strike" "installdir" "Half-Life" }`), 0644)
	os.WriteFile(filepath.Join(lib, "steamapps", "common", "Half-Life", "hl.exe"), []byte("fixture"), 0644)
	apps := steamApps(root)
	for _, q := range []string{"cs", "cs 1.6", "counter-strike.exe"} {
		m := rankApps(q, apps)
		if len(m) == 0 || m[0].Target != "steam://rungameid/10" {
			t.Fatal(q, m)
		}
	}
	m := rankApps("hl.exe", apps)
	if len(m) == 0 || !strings.HasSuffix(m[0].Target, "hl.exe") {
		t.Fatal(m)
	}
}
func TestTextCannotCreateBinary(t *testing.T) {
	a := &Agent{Base: t.TempDir(), Confirm: func(string) bool { t.Fatal("should reject before asking"); return true }, ConfirmEachAction: true}
	for _, name := range []string{"hl.exe", "Steam.EXE", "evil.dll", "test.msi", "hl.exe. "} {
		for _, tool := range []string{"write_file", "append_file"} {
			if _, e := a.Execute(Action{Tool: tool, Path: name, Content: "example"}); e == nil {
				t.Fatal(name, tool)
			}
		}
	}
	entries, _ := os.ReadDir(a.Base)
	if len(entries) != 0 {
		t.Fatal(entries)
	}
}
func TestWindowsArgumentsTrailingSlashAndQuote(t *testing.T) {
	for _, tc := range []struct{ s, w string }{{"", `""`}, {`C:\a\`, `"C:\a\\"`}, {`a"b`, `"a\"b"`}, {`--profile-directory=Profile 2`, `"--profile-directory=Profile 2"`}} {
		if got := quoteWindowsArg(tc.s); got != tc.w {
			t.Errorf("%q: %q != %q", tc.s, got, tc.w)
		}
	}
}
