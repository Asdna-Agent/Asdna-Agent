package pcactions

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestOpenAnyApplicationWithoutAllowlist(t *testing.T) {
	for _, app := range []string{"chrome.exe", "cmd.exe", "firefox.exe", `C:\\Program Files\\Editor\\programa.exe`, "qualquer-outro.exe"} {
		s, err := buildStartProcess(app, nil, false)
		if err != nil || !strings.Contains(s, psLiteral(app)) {
			t.Errorf("app %q: %v %q", app, err, s)
		}
	}
	admin, err := buildStartProcess("cmd.exe", nil, true)
	if err != nil || !strings.Contains(admin, "-Verb RunAs") {
		t.Fatalf("elevated cmd %v %s", err, admin)
	}
	command, err := buildStartProcess("editor.exe", []string{"name with spaces", "a'; Write-Host danger; 'b"}, false)
	if err != nil || !strings.Contains(command, "a''; Write-Host danger; ''b") {
		t.Fatalf("argument escaped incorrectly %v %q", err, command)
	}
}

func TestEveryActionPromptsAndDenialDoesNotWrite(t *testing.T) {
	base := t.TempDir()
	called := 0
	a := &Agent{Base: base, ConfirmEachAction: true, Confirm: func(prompt string) bool {
		called++
		if !strings.Contains(prompt, "teste.txt") || !strings.Contains(prompt, "conteudo") && !strings.Contains(prompt, "Conteudo") {
			t.Fatalf("prompt did not describe action: %q", prompt)
		}
		return false
	}}
	_, err := a.Execute(Action{Tool: "write_file", Path: "teste.txt", Content: "conteudo"})
	if err == nil || called != 1 {
		t.Fatalf("refusal not enforced: %v calls %d", err, called)
	}
	if _, err := os.Stat(filepath.Join(base, "teste.txt")); !os.IsNotExist(err) {
		t.Fatal("created file after refusal")
	}
	a.Confirm = func(string) bool { return true }
	if _, err = a.Execute(Action{Tool: "write_file", Path: "teste.txt", Content: "conteudo"}); err != nil {
		t.Fatal(err)
	}
}

func TestGenericPCIntents(t *testing.T) {
	for _, s := range []string{"abra o terminal cmd para mim, no modo administrador", "abra o google chrome para mim", "abra o Notepad++", "instale o app xyz", "descompacte esse ZIP"} {
		if !IsPCRequest(s) {
			t.Errorf("not routed to agent: %q", s)
		}
	}
	for _, s := range []string{"como abrir o Chrome?", "olá", "escreva uma funcao Python"} {
		if IsPCRequest(s) {
			t.Errorf("misrouted: %q", s)
		}
	}
}
