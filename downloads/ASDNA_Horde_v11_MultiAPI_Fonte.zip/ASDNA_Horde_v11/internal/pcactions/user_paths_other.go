//go:build !windows

package pcactions

func knownFolderPath(kind string) string { return "" }
