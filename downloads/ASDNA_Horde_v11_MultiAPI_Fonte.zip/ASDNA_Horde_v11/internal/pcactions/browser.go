package pcactions

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

// Chrome profile names are obtained from the user's own Chrome Local State.
// A requested profile must match uniquely; never silently fall back to Default.
type chromeProfile struct {
	Name         string `json:"name"`
	ShortcutName string `json:"shortcut_name"`
	GaiaName     string `json:"gaia_name"`
	UserName     string `json:"user_name"`
}

func normalizeProfileName(s string) string {
	s = strings.TrimSpace(strings.Trim(s, `"'`))
	s = strings.TrimSpace(strings.TrimSuffix(strings.ToLower(s), " - chrome"))
	return strings.ToLower(strings.Join(strings.Fields(s), " "))
}

func findProfileInLocalState(data []byte, wanted string) (string, error) {
	var state struct {
		Profile struct {
			InfoCache map[string]chromeProfile `json:"info_cache"`
		} `json:"profile"`
	}
	if err := json.Unmarshal(data, &state); err != nil {
		return "", fmt.Errorf("nao foi possivel ler perfis do Chrome: %w", err)
	}
	needle := normalizeProfileName(wanted)
	if needle == "" {
		return "", errors.New("perfil do Chrome nao informado")
	}
	matches := profileMatches(state.Profile.InfoCache, needle)
	if len(matches) == 0 {
		return "", fmt.Errorf("perfil %q nao encontrado; use list_profiles", wanted)
	}
	if matches[0].Score < 80 || (len(matches) > 1 && matches[0].Score-matches[1].Score < 10) {
		return "", fmt.Errorf("perfil %q ambiguo; use list_profiles", wanted)
	}
	return matches[0].Target, nil
}

func profileMatches(profiles map[string]chromeProfile, wanted string) []AppCandidate {
	var candidates []AppCandidate
	for dir, p := range profiles {
		candidates = append(candidates, AppCandidate{Name: p.Name, Target: dir, Kind: "profile", Source: "Perfil Chrome", Aliases: []string{dir, p.ShortcutName, p.GaiaName, p.UserName}})
	}
	return rankApps(normalizeProfileName(wanted), candidates)
}
func readChromeProfiles() (map[string]chromeProfile, error) {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		return nil, errors.New("LOCALAPPDATA nao encontrado")
	}
	data, err := os.ReadFile(filepath.Join(local, "Google", "Chrome", "User Data", "Local State"))
	if err != nil {
		return nil, fmt.Errorf("perfis do Chrome indisponiveis: %w", err)
	}
	var state struct {
		Profile struct {
			InfoCache map[string]chromeProfile `json:"info_cache"`
		} `json:"profile"`
	}
	err = json.Unmarshal(data, &state)
	return state.Profile.InfoCache, err
}
func chromeShortcutDirectory(source string) string {
	if !strings.Contains(strings.ToLower(source), "chrome.exe") {
		return ""
	}
	marker := "--profile-directory="
	idx := strings.Index(strings.ToLower(source), marker)
	if idx < 0 {
		return ""
	}
	trailing := strings.TrimSpace(source[idx+len(marker):])
	if trailing == "" {
		return ""
	}
	if trailing[0] == '"' {
		if end := strings.IndexByte(trailing[1:], '"'); end >= 0 {
			return trailing[1 : 1+end]
		}
		return ""
	}
	return strings.Fields(trailing)[0]
}

func (a *Agent) resolveChromeProfile(wanted string) (string, error) {
	profiles, err := readChromeProfiles()
	if err != nil {
		return "", err
	}
	// A Chrome shortcut is allowed to have a meaningful user-chosen name
	// (e.g. ZelpyrnDeveloper - Chrome -> --profile-directory="Default")
	// even when Chrome calls that same profile "Eduardo" internally.
	if catalog, err := a.catalog(false); err == nil {
		for _, candidate := range catalog {
			if candidate.Kind != "shortcut" {
				continue
			}
			dir := chromeShortcutDirectory(candidate.Source)
			if dir == "" {
				continue
			}
			profile, found := profiles[dir]
			if !found {
				continue
			}
			profile.ShortcutName += " " + candidate.Name
			profiles[dir] = profile
		}
	}
	matches := profileMatches(profiles, wanted)
	if len(matches) == 0 {
		return "", fmt.Errorf("perfil %q nao encontrado no Chrome ou em seus atalhos", wanted)
	}
	c, err := a.chooseCandidate(wanted, matches)
	return c.Target, err
}
func listChromeProfiles(query string) (string, error) {
	profiles, err := readChromeProfiles()
	if err != nil {
		return "", err
	}
	var matches []AppCandidate
	if query != "" {
		matches = profileMatches(profiles, query)
	} else {
		for dir, p := range profiles {
			matches = append(matches, AppCandidate{Name: p.Name, Target: dir})
		}
		sort.Slice(matches, func(i, j int) bool { return matches[i].Target < matches[j].Target })
	}
	var b strings.Builder
	b.WriteString("Perfis locais do Chrome (nome e diretorio):\n")
	for _, p := range matches {
		fmt.Fprintf(&b, "%s | %s\n", p.Name, p.Target)
	}
	return b.String(), nil
}

func chromeProfileDirectory(name string) (string, error) {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		return "", errors.New("LOCALAPPDATA nao encontrado")
	}
	data, err := os.ReadFile(filepath.Join(local, "Google", "Chrome", "User Data", "Local State"))
	if err != nil {
		return "", fmt.Errorf("Chrome Local State indisponivel: %w", err)
	}
	return findProfileInLocalState(data, name)
}

func browserTarget(action Action) (string, error) {
	switch strings.ToLower(action.Tool) {
	case "browser_search":
		q := strings.TrimSpace(action.Query)
		if q == "" {
			return "", errors.New("busca sem texto; use query")
		}
		if len(q) > 1200 {
			return "", errors.New("pesquisa muito longa")
		}
		return "https://www.google.com/search?q=" + url.QueryEscape(q), nil
	case "browser_navigate":
		return validatedRemoteURL(action.URL)
	default:
		return "", errors.New("acao de navegador desconhecida")
	}
}

func (a *Agent) browserAction(action Action) (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("navegacao no navegador disponivel apenas no Windows")
	}
	target, err := browserTarget(action)
	if err != nil {
		return "", err
	}
	args := []string{}
	profileLabel := "perfil padrao atualmente selecionado pelo Chrome"
	if strings.TrimSpace(action.Profile) != "" {
		dir, err := a.resolveChromeProfile(action.Profile)
		if err != nil {
			return "", err
		}
		args = append(args, "--profile-directory="+dir)
		profileLabel = fmt.Sprintf("%s (diretorio %s)", action.Profile, dir)
	}
	args = append(args, target)
	chrome, err := a.resolveApplication("chrome.exe")
	if err != nil {
		return "", err
	}
	script, err := buildStartProcess(chrome.Target, args, false)
	if err != nil {
		return "", err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	output, err := exec.CommandContext(ctx, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", "[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false); "+script).CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("Chrome nao iniciou: %w; %s", err, previewText(string(output), 500))
	}
	return "Chrome acionado com o perfil: " + profileLabel + ". URL solicitada: " + target + ". " + strings.TrimSpace(string(output)) + ". Nao e possivel verificar visualmente o carregamento da pagina.", nil
}
