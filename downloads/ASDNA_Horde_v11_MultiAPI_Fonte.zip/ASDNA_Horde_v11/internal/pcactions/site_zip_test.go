package pcactions

import (
	"archive/zip"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSiteZipWorkflow(t *testing.T) {
	a := &Agent{Base: filepath.Join(t.TempDir(), "Downloads", "ASDNA_Horde"), Confirm: func(string) bool { return false }}
	first, msg, err := a.CreateBasicSite("crie um site basico com HTML CSS em pasta e compacte para .zip")
	if err != nil || first != "MeuSite" {
		t.Fatalf("site: %s %q %v", first, msg, err)
	}
	htmlData, err := os.ReadFile(filepath.Join(a.Base, first, "index.html"))
	if err != nil || !strings.Contains(string(htmlData), `href="style.css"`) || !strings.Contains(string(htmlData), "</html>") {
		t.Fatalf("html invalido: %s %v", string(htmlData), err)
	}
	if _, err := os.Stat(filepath.Join(a.Base, first, "style.css")); err != nil {
		t.Fatal(err)
	}
	zipOut, err := a.ZipFolder(first, first+".zip")
	if err != nil || !strings.Contains(zipOut, "ZIP criado") {
		t.Fatalf("zip: %q %v", zipOut, err)
	}
	r, err := zip.OpenReader(filepath.Join(a.Base, first+".zip"))
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	got := map[string]bool{}
	for _, f := range r.File {
		got[f.Name] = true
	}
	for _, name := range []string{"MeuSite/", "MeuSite/index.html", "MeuSite/style.css"} {
		if !got[name] {
			t.Errorf("faltou %s no zip: %v", name, got)
		}
	}
	if _, err := a.ZipFolder(first, first+".zip"); err == nil {
		t.Fatal("ZIP sobrescrito")
	}
	second, _, err := a.CreateBasicSite("crie um site basico")
	if err != nil || second != "MeuSite_2" {
		t.Fatalf("segunda pasta: %s %v", second, err)
	}
}

func TestZipSafety(t *testing.T) {
	root := t.TempDir()
	a := &Agent{Base: filepath.Join(root, "base"), Confirm: func(string) bool { return false }}
	if _, _, err := a.CreateBasicSite("crie um site"); err != nil {
		t.Fatal(err)
	}
	if _, err := a.ZipFolder("../../", "out.zip"); err == nil {
		t.Fatal("leitura externa liberada")
	}
	if _, err := a.ZipFolder("MeuSite", "../out.zip"); err == nil {
		t.Fatal("gravacao externa liberada")
	}
	target := filepath.Join(root, "secret.txt")
	if err := os.WriteFile(target, []byte("PRIVATE"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(target, filepath.Join(a.Base, "MeuSite", "link.txt")); err == nil {
		if _, err := a.ZipFolder("MeuSite", "safe.zip"); err != nil {
			t.Fatal(err)
		}
		r, err := zip.OpenReader(filepath.Join(a.Base, "safe.zip"))
		if err != nil {
			t.Fatal(err)
		}
		defer r.Close()
		for _, f := range r.File {
			if strings.Contains(f.Name, "link.txt") {
				t.Fatal("symlink foi incluido")
			}
		}
	}
}

func TestNaturalLanguageSiteAndZip(t *testing.T) {
	for _, v := range []string{"crie um site basico com html e css", "faça um site de pizzaria e compacte para .zip"} {
		if !IsSiteRequest(v) {
			t.Errorf("nao reconheceu site %q", v)
		}
	}
	for _, v := range []string{"crie um arqivo .zip", "compacte a pasta MeuSite para ZIP", "criar arquivo .zip"} {
		if !IsZipRequest(v) {
			t.Errorf("nao reconheceu ZIP %q", v)
		}
	}
	for _, v := range []string{"como criar um arquivo .zip?", "ensine a criar um site", "bom dia"} {
		if IsSiteRequest(v) || IsZipRequest(v) {
			t.Errorf("falso pedido de acao %q", v)
		}
	}
}
