package pcactions

import "strings"

// IsPCRequest e propositalmente conservador para nao confundir perguntas
// normais de programacao com permissoes para alterar o computador.
func IsPCRequest(s string) bool {
	s = strings.ToLower(strings.TrimSpace(s))
	replacer := strings.NewReplacer("á", "a", "à", "a", "â", "a", "ã", "a", "é", "e", "ê", "e", "í", "i", "ó", "o", "ô", "o", "õ", "o", "ú", "u", "ç", "c")
	s = replacer.Replace(s)
	for _, p := range []string{"pfv ", "pf ", "por favor "} {
		s = strings.TrimPrefix(s, p)
	}
	for _, prefix := range []string{"como ", "qual ", "o que ", "por que ", "porque ", "explique ", "me explique ", "ensine "} {
		if strings.HasPrefix(s, prefix) {
			return false
		}
	}
	verbs := []string{"crie ", "cria ", "criar ", "faca ", "faz ", "fazer ", "monte ", "construa ", "coloque ", "gere ", "gera ", "gerar ", "salve ", "salva ", "salvar ", "guarde ", "escreva ", "escrever ", "abra ", "abre ", "abrir ", "liste ", "listar ", "lista ", "leia ", "ler ", "copie ", "copiar ", "mova ", "mover ", "renomeie ", "organize ", "organizar ", "compacte ", "compactar ", "zipar ", "zip ", "empacote ", "instale ", "instalar ", "baixe ", "baixar ", "download ", "encontre ", "encontrar ", "localize ", "localizar ", "procure ", "procurar ", "pesquise ", "execute ", "executar ", "rode ", "rodar ", "atualize ", "atualizar ", "verifique ", "verificar ", "desinstale ", "desinstalar ", "extraia ", "extrair ", "descompacte ", "descompactar "}
	subjects := []string{"arquivo", "script", "pasta", "diretorio", "downloads", "explorador", "bloco de notas", "notepad", "calculadora", "paint", ".txt", ".py", ".html", ".json", ".go", ".rs", ".md", "no meu pc", "no computador", "aqui no pc", ".zip", "zip", "site", "website", "pagina", "arqivo", "arquivo de python", "codigo", "programa", "aplicativo", "aplicacao", "app", "software", "pacote", "chrome", "firefox", "github", "projeto", "instalador", "site", "navegador", "winget", "powershell", "windows", "download", "computador", "cmd", "terminal", "prompt de comando", "administrador", "executavel", "exe"}
	hasVerb, hasSubject := false, false
	for _, v := range verbs {
		if strings.Contains(" "+s, " "+v) {
			hasVerb = true
			break
		}
	}
	for _, v := range subjects {
		if strings.Contains(s, v) {
			hasSubject = true
			break
		}
	}
	if hasVerb && hasSubject {
		return true
	}
	// Open/run/install commands are device actions even if the application's
	// name is unknown in advance. /pc always forces the agent for other cases.
	for _, prefix := range []string{"abra ", "abre ", "abrir ", "execute ", "executar ", "rode ", "instale ", "instalar ", "desinstale ", "desinstalar ", "extraia ", "descompacte "} {
		if strings.HasPrefix(s, prefix) || strings.HasPrefix(s, "por favor "+prefix) || strings.HasPrefix(s, "consegue "+prefix) || strings.HasPrefix(s, "pode "+prefix) {
			return true
		}
	}
	return false
}

// NormalizeIntent evita depender de acentos para detectar pedidos simples.
func NormalizeIntent(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	return strings.NewReplacer("á", "a", "à", "a", "â", "a", "ã", "a", "é", "e", "ê", "e", "í", "i", "ó", "o", "ô", "o", "õ", "o", "ú", "u", "ç", "c").Replace(s)
}

// IsSiteRequest identifica o pedido de CRIAR um site, e nao perguntas de como fazer.
func IsSiteRequest(s string) bool {
	norm := NormalizeIntent(s)
	for _, p := range []string{"como ", "qual ", "o que ", "explique ", "ensine "} {
		if strings.HasPrefix(norm, p) {
			return false
		}
	}
	website := strings.Contains(norm, "site") || strings.Contains(norm, "website") || strings.Contains(norm, "pagina web")
	create := false
	for _, v := range []string{"crie ", "cria ", "faca ", "faz ", "monte ", "construa ", "gere ", "gera ", "desenvolva ", "produza "} {
		if strings.Contains(" "+norm, " "+v) {
			create = true
			break
		}
	}
	return website && create
}

// IsZipRequest permite compactar via linguagem natural mesmo sem ferramenta no modelo.
func IsZipRequest(s string) bool {
	norm := NormalizeIntent(s)
	for _, p := range []string{"como ", "qual ", "o que ", "explique ", "ensine "} {
		if strings.HasPrefix(norm, p) {
			return false
		}
	}
	hasArchive := strings.Contains(norm, ".zip") || strings.Contains(norm, "zipar") || strings.Contains(norm, "compacte") || strings.Contains(norm, "compactar") || strings.Contains(norm, "compactado")
	hasAsk := false
	for _, v := range []string{"crie ", "cria ", "criar ", "faca ", "faz ", "gere ", "gera ", "compacte ", "compactar ", "zipar ", "zip ", "transforme ", "salve "} {
		if strings.Contains(" "+norm, " "+v) {
			hasAsk = true
			break
		}
	}
	return hasArchive && hasAsk
}
