package pcactions

import (
	"archive/zip"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const maxZipFiles = 1000
const maxZipBytes int64 = 25 << 20

// ZipFolder compacta arquivos locais sem abrir terminal ou executar scripts.
// Preserva a pasta superior no arquivo e recusa sobrescrever ZIP existente.
func (a *Agent) ZipFolder(folder, destination string) (string, error) {
	if a == nil {
		return "", errors.New("assistente nao inicializado")
	}
	if err := os.MkdirAll(a.Base, 0755); err != nil {
		return "", err
	}
	src, srcInside, err := a.resolve(folder)
	if err != nil {
		return "", err
	}
	if err := a.checkExternal(src, srcInside, "compactar pasta (origem)"); err != nil {
		return "", err
	}
	st, err := os.Lstat(src)
	if err != nil {
		return "", err
	}
	if !st.IsDir() {
		return "", errors.New("para criar .zip indique uma pasta existente")
	}
	dst, dstInside, err := a.resolve(destination)
	if err != nil {
		return "", err
	}
	if strings.ToLower(filepath.Ext(dst)) != ".zip" {
		return "", errors.New("destino deve terminar em .zip")
	}
	if err := a.checkExternal(dst, dstInside, "criar ZIP (destino)"); err != nil {
		return "", err
	}
	if info, err := os.Lstat(dst); err == nil {
		_ = info
		return "", fmt.Errorf("ZIP ja existe, escolha outro nome: %s", dst)
	} else if !os.IsNotExist(err) {
		return "", err
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return "", err
	}
	// O_EXCL impede substituir arquivos criados entre a checagem e a abertura.
	f, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		return "", err
	}
	good := false
	defer func() {
		f.Close()
		if !good {
			_ = os.Remove(dst)
		}
	}()
	writer := zip.NewWriter(f)
	files := 0
	var total int64
	prefix := filepath.Dir(src)
	err = filepath.WalkDir(src, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if path == dst {
			return nil
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return nil
		}
		rel, err := filepath.Rel(prefix, path)
		if err != nil {
			return err
		}
		if rel == "." || strings.HasPrefix(rel, "..") {
			return errors.New("caminho zip inseguro")
		}
		arcname := filepath.ToSlash(rel)
		if entry.IsDir() {
			_, err = writer.Create(arcname + "/")
			return err
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		files++
		total += info.Size()
		if files > maxZipFiles || total > maxZipBytes {
			return errors.New("ZIP excede 1000 arquivos ou 25 MB (descompactados)")
		}
		header, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}
		header.Name = arcname
		header.Method = zip.Deflate
		out, err := writer.CreateHeader(header)
		if err != nil {
			return err
		}
		in, err := os.Open(path)
		if err != nil {
			return err
		}
		n, copyErr := io.Copy(out, io.LimitReader(in, info.Size()+1))
		closeErr := in.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		if n != info.Size() {
			return errors.New("arquivo alterado durante a compactacao")
		}
		return nil
	})
	if err != nil {
		_ = writer.Close()
		return "", err
	}
	if files == 0 {
		_ = writer.Close()
		return "", errors.New("pasta vazia ou sem arquivos regulares")
	}
	if err := writer.Close(); err != nil {
		return "", err
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	good = true
	return fmt.Sprintf("ZIP criado em: %s (%d arquivos)", dst, files), nil
}

// ZipFile creates an archive from a single regular file, preserving its name.
func (a *Agent) ZipFile(filename, destination string) (string, error) {
	src, inside, err := a.resolve(filename)
	if err != nil {
		return "", err
	}
	if err = a.checkExternal(src, inside, "compactar arquivo"); err != nil {
		return "", err
	}
	stat, err := os.Lstat(src)
	if err != nil {
		return "", err
	}
	if !stat.Mode().IsRegular() || stat.Size() > maxZipBytes {
		return "", errors.New("zip_file requer arquivo regular de ate 25 MB")
	}
	dst, dInside, err := a.resolve(destination)
	if err != nil {
		return "", err
	}
	if err = a.checkExternal(dst, dInside, "criar ZIP"); err != nil {
		return "", err
	}
	if !strings.EqualFold(filepath.Ext(dst), ".zip") {
		return "", errors.New("destino deve terminar em .zip")
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return "", err
	}
	f, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_EXCL, 0644)
	if err != nil {
		return "", err
	}
	success := false
	defer func() {
		f.Close()
		if !success {
			os.Remove(dst)
		}
	}()
	z := zip.NewWriter(f)
	header, err := zip.FileInfoHeader(stat)
	if err == nil {
		header.Name = filepath.Base(src)
		header.Method = zip.Deflate
		var out io.Writer
		out, err = z.CreateHeader(header)
		if err == nil {
			var in *os.File
			in, err = os.Open(src)
			if err == nil {
				_, err = io.CopyN(out, in, stat.Size())
				cerr := in.Close()
				if err == nil {
					err = cerr
				}
			}
		}
	}
	closeErr := z.Close()
	if err != nil {
		return "", err
	}
	if closeErr != nil {
		return "", closeErr
	}
	if err = f.Close(); err != nil {
		return "", err
	}
	success = true
	return fmt.Sprintf("ZIP criado em: %s (1 arquivo)", dst), nil
}
