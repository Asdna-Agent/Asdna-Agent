package pcactions

import (
	"context"
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// psLiteral quotes an exact string for PowerShell, with no interpretation of
// variables, command separators, backticks or nested expressions.
func psLiteral(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }

func previewText(s string, n int) string {
	runes := []rune(s)
	if len(runes) > n {
		return string(runes[:n]) + "..."
	}
	return s
}

func buildStartProcess(app string, args []string, elevated bool) (string, error) {
	app = strings.TrimSpace(app)
	if app == "" || strings.ContainsRune(app, 0) || len(app) > 2048 || strings.ContainsAny(app, "\n\r") {
		return "", errors.New("nome ou caminho do programa invalido")
	}
	if len(args) > 30 {
		return "", errors.New("argumentos em excesso")
	}
	script := "$ErrorActionPreference='Stop'; $p = Start-Process -FilePath " + psLiteral(app)
	if len(args) > 0 {
		escaped := make([]string, 0, len(args))
		for _, arg := range args {
			if len(arg) > 3000 || strings.ContainsRune(arg, 0) || strings.ContainsAny(arg, "\r\n") {
				return "", errors.New("argumento de programa invalido")
			}
			// Start-Process joins ArgumentList entries with spaces. Keep each
			// argument in Windows command-line quotes so profile paths such
			// as "Profile 2" remain a single argument to Chrome.
			quoted := quoteWindowsArg(arg)
			escaped = append(escaped, psLiteral(quoted))
		}
		script += " -ArgumentList @(" + strings.Join(escaped, ",") + ")"
	}
	if elevated {
		script += " -Verb RunAs"
	}
	script += " -PassThru; if($null -ne $p){Write-Output ('Processo iniciado, PID: ' + $p.Id)}else{Write-Output 'Solicitacao enviada ao Windows; sem PID retornado'}"
	return script, nil
}

// openApplication can start arbitrary installed applications rather than a
// hard-coded application list. Users must see the exact proposed target and
// grant consent, independently of the model's own statements.
func (a *Agent) openApplication(action Action) (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("abrir aplicativos requer Windows")
	}
	executable := strings.TrimSpace(action.App)
	if executable == "" {
		executable = strings.TrimSpace(action.Path)
	}
	candidate, err := a.resolveApplication(executable)
	if err != nil {
		return "", err
	}
	executable = candidate.Target
	args := append([]string(nil), action.Args...)
	for i, arg := range args {
		if strings.HasPrefix(arg, "--profile-directory=") && strings.EqualFold(filepath.Base(executable), "chrome.exe") {
			if action.Profile != "" {
				return "", errors.New("informe o perfil uma unica vez, em profile")
			}
			dir, e := a.resolveChromeProfile(strings.TrimPrefix(arg, "--profile-directory="))
			if e != nil {
				return "", e
			}
			args[i] = "--profile-directory=" + dir
		}
	}
	if candidate.Kind == "steam" || candidate.Kind == "store" || candidate.Kind == "shortcut" {
		if action.Admin || len(args) > 0 || action.Profile != "" {
			return "", errors.New("atalhos, apps Store e jogos Steam devem abrir sem argumentos adicionais ou elevacao")
		}
	}
	if action.Profile != "" {
		if !strings.EqualFold(filepath.Base(executable), "chrome.exe") {
			return "", errors.New("profile so e aceito ao abrir Chrome")
		}
		dir, e := a.resolveChromeProfile(action.Profile)
		if e != nil {
			return "", e
		}
		args = append([]string{"--profile-directory=" + dir}, args...)
	}
	displayTarget := executable
	if candidate.Kind == "store" {
		executable = "explorer.exe"
		args = []string{`shell:AppsFolder\` + candidate.Target}
	}
	script, err := buildStartProcess(executable, args, action.Admin)
	if err != nil {
		return "", err
	}
	if candidate.Kind == "exe" && filepath.IsAbs(executable) {
		script = strings.Replace(script, " -PassThru;", " -WorkingDirectory "+psLiteral(filepath.Dir(executable))+" -PassThru;", 1)
	}
	mode := "normal"
	if action.Admin {
		mode = "ADMINISTRADOR (o Windows solicitara UAC)"
	}
	// A normal app launch is the direct effect of the user's agent request and
	// should not degrade into a second "SIM" prompt. Elevation remains gated.
	if action.Admin {
		details := fmt.Sprintf("Aplicativo localizado: %s\nOrigem: %s\nDestino: %s\nArgumentos: %q\nPrivilegios: %s\nAutoriza abrir como administrador?", candidate.Name, candidate.Source, displayTarget, args, mode)
		if !a.approved(details) {
			return "", errors.New("abertura elevada do aplicativo recusada pelo usuario")
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	output, err := exec.CommandContext(ctx, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", "[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false); "+script).CombinedOutput()
	if err != nil {
		a.apps = nil
		return "", fmt.Errorf("nao foi possivel iniciar %q: %w; %s. Nao crie um executavel substituto", displayTarget, err, previewText(string(output), 800))
	}
	return "Abertura solicitada: " + candidate.Name + " — " + displayTarget + ". " + strings.TrimSpace(string(output)) + ". Janela/conteudo nao verificados visualmente.", nil
}

// Windows CommandLineToArgvW/CRT escaping, including trailing backslashes.
func quoteWindowsArg(s string) string {
	var b strings.Builder
	b.WriteByte('"')
	slashes := 0
	for _, r := range s {
		if r == '\\' {
			slashes++
			continue
		}
		if r == '"' {
			b.WriteString(strings.Repeat("\\", slashes*2+1))
		} else {
			b.WriteString(strings.Repeat("\\", slashes))
		}
		slashes = 0
		b.WriteRune(r)
	}
	b.WriteString(strings.Repeat("\\", slashes*2))
	b.WriteByte('"')
	return b.String()
}
