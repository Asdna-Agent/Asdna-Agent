package pcactions

import (
	"runtime"
	"strings"
	"testing"
)

func TestBrowserProfileLookupNameAndShortcut(t *testing.T) {
	jsonState := []byte(`{"profile":{"info_cache":{"Default":{"name":"Pessoal","shortcut_name":"Pessoal"},"Profile 2":{"name":"ZelpyrnDeveloper (Eduardo)","shortcut_name":"ZelpyrnDeveloper (Eduardo)"}}}}`)
	path, err := findProfileInLocalState(jsonState, `ZelpyrnDeveloper (Eduardo) - Chrome`)
	if err != nil || path != "Profile 2" {
		t.Fatalf("incorrect profile: %q %v", path, err)
	}
	if path, err = findProfileInLocalState(jsonState, "Profile 2"); err != nil || path != "Profile 2" {
		t.Fatal(path, err)
	}
	if _, err = findProfileInLocalState(jsonState, "Outro Perfil"); err == nil {
		t.Fatal("silently fell back to default")
	}
}

func TestChromeProfileArgumentStaysOneArgument(t *testing.T) {
	script, err := buildStartProcess("chrome.exe", []string{"--profile-directory=Profile 2", "https://www.google.com/search?q=Youtube"}, false)
	if err != nil || !strings.Contains(script, `"--profile-directory=Profile 2"`) {
		t.Fatalf("Chrome profile lost quoting: %v %s", err, script)
	}
}

func TestBrowserSearchAndNavigation(t *testing.T) {
	url, err := browserTarget(Action{Tool: "browser_search", Query: "Youtube videos de carros"})
	if err != nil || url != "https://www.google.com/search?q=Youtube+videos+de+carros" {
		t.Fatal(url, err)
	}
	if _, err := browserTarget(Action{Tool: "browser_navigate", URL: "javascript:alert(1)"}); err == nil {
		t.Fatal("unsafe protocol accepted")
	}
}

func TestDesktopWindowsGenericCommands(t *testing.T) {
	for _, tc := range []struct {
		action   Action
		contains string
	}{
		{Action{Window: "Bloco de Notas", Operation: "type", Content: "Olá, mundo!"}, "Clipboard"},
		{Action{Window: "Chrome", Operation: "hotkey", Keys: "ctrl+l"}, "SendWait('^l')"},
		{Action{Window: "Editor", Operation: "click", X: 180, Y: 90}, "SetCursorPos(180,90)"},
		{Action{Window: "Painel", Operation: "focus"}, "Janela ativada"},
	} {
		script, err := buildDesktopScript(tc.action)
		if err != nil || !strings.Contains(script, tc.contains) {
			t.Fatalf("desktop script: %v / %s", err, script)
		}
	}
	if _, err := buildDesktopScript(Action{Window: "", Operation: "type", Content: "oops"}); err == nil {
		t.Fatal("no target window allowed")
	}
	if _, err := buildDesktopScript(Action{Window: "Editor", Operation: "hotkey", Keys: "ctrl+malicious"}); err == nil {
		t.Fatal("unsafe hotkey accepted")
	}
	script, err := buildDesktopScript(Action{Window: "O'Brien", Operation: "type", Content: "x'; rm -rf; 'y"})
	if err != nil || !strings.Contains(script, "O''Brien") || !strings.Contains(script, "x''; rm -rf; ''y") {
		t.Fatal(script, err)
	}
}

func TestPCExecutorNewToolsPlatformCheck(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("unsupported-platform test; never launch desktop in unit tests")
	}
	a := &Agent{Base: t.TempDir(), Confirm: func(s string) bool { t.Fatal("confirmed on unsupported platform"); return false }}
	if _, err := a.Execute(Action{Tool: "desktop_control", Window: "abc", Operation: "focus"}); err == nil {
		t.Fatal("must require Windows")
	}
	if _, err := a.Execute(Action{Tool: "browser_search", Query: "YouTube"}); err == nil {
		t.Fatal("must require Windows")
	}
}
