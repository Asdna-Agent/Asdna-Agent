package pcactions

import (
	"errors"
	"fmt"
	"html"
	"os"
	"path/filepath"
	"strings"
)

// SiteTitle escolhe um nome simples sem permitir que um pedido escreva fora do workspace.
func SiteTitle(request string) (folder, title, desc string) {
	lower := NormalizeIntent(request)
	folder, title, desc = "MeuSite", "Meu Site", "Um espaço simples, bonito e feito para você."
	switch {
	case strings.Contains(lower, "pizzaria"):
		folder, title, desc = "SitePizzaria", "Pizzaria da Casa", "Pizza feita com carinho, ingredientes frescos e muito sabor."
	case strings.Contains(lower, "cafeteria") || strings.Contains(lower, "cafe"):
		folder, title, desc = "SiteCafeteria", "Café & Companhia", "Momentos especiais começam com um bom café."
	case strings.Contains(lower, "portfolio"):
		folder, title, desc = "MeuPortfolio", "Meu Portfólio", "Projetos, habilidades e ideias reunidos em um só lugar."
	case strings.Contains(lower, "loja"):
		folder, title, desc = "MinhaLoja", "Minha Loja", "Produtos que combinam com você, em um só lugar."
	case strings.Contains(lower, "restaurante"):
		folder, title, desc = "SiteRestaurante", "Nosso Restaurante", "Sabores que contam histórias e momentos para compartilhar."
	case strings.Contains(lower, "jogo") || strings.Contains(lower, "gaming"):
		folder, title, desc = "SiteGaming", "Game Zone", "Seu espaço para novidades, jogos e diversão."
	}
	return
}

const pageCSS = `:root{color-scheme:dark;--bg:#0b1020;--panel:#151d32;--fg:#f1f5ff;--muted:#b8c3dd;--primary:#79b5ff;--accent:#af91ff}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(circle at 70% 0%,#19274d,var(--bg) 65%);color:var(--fg);font:16px/1.65 system-ui,-apple-system,Segoe UI,sans-serif}a{color:inherit;text-decoration:none}.container{max-width:1100px;padding:0 22px;margin:auto}.nav{display:flex;align-items:center;justify-content:space-between;padding:26px 0;gap:14px}.brand{font-size:1.3rem;font-weight:800;letter-spacing:-.04em}.brand span{color:var(--primary)}.menu{display:flex;gap:24px;color:var(--muted);font-size:.96rem}.menu a:hover{color:var(--fg)}.hero{text-align:center;padding:105px 0 90px}.eyebrow{display:inline-block;border:1px solid #344366;border-radius:99px;padding:6px 16px;color:#b6caff;background:#172440;font-size:.85rem}.hero h1{font-size:clamp(2.6rem,6vw,5.3rem);line-height:1.08;letter-spacing:-.06em;margin:28px auto 22px;max-width:850px}.hero h1 em{font-style:normal;color:var(--primary)}.hero p{font-size:1.15rem;color:var(--muted);max-width:650px;margin:0 auto 30px}.btn{display:inline-block;background:linear-gradient(100deg,var(--primary),var(--accent));color:#0b1020;font-weight:750;padding:14px 24px;border-radius:12px;box-shadow:0 6px 30px #7fa9ff26}.btn:hover{filter:brightness(1.1)}.section{padding:45px 0 100px}.section h2{text-align:center;font-size:2rem;letter-spacing:-.04em}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-top:35px}.card{border:1px solid #2a3859;border-radius:20px;padding:30px;background:#172038;min-height:190px}.card .symbol{font-size:2rem}.card h3{margin:14px 0 6px}.card p{color:var(--muted);margin:0}.contact{text-align:center;padding:70px 18px 100px;background:#101a30;border-top:1px solid #263553}.contact p{color:var(--muted)}.footer{text-align:center;color:#8693b1;padding:25px;font-size:.9rem}@media(max-width:720px){.menu{gap:12px;font-size:.85rem}.hero{padding:75px 0}.grid{grid-template-columns:1fr}.nav{flex-wrap:wrap}}
`

// CreateBasicSite gera HTML/CSS reais e permite que qualquer modelo pequeno crie
// um primeiro projeto, mesmo quando nao suporta chamadas de ferramentas.
func (a *Agent) CreateBasicSite(request string) (folderName, result string, err error) {
	if a == nil {
		return "", "", errors.New("agente nao inicializado")
	}
	baseName, title, subtitle := SiteTitle(request)
	if err := os.MkdirAll(a.Base, 0755); err != nil {
		return "", "", err
	}
	// Nunca sobrescreve um projeto antigo; cria uma nova versao numerada.
	folderName = baseName
	for i := 2; i < 1000; i++ {
		p, inside, e := a.resolve(folderName)
		if e != nil {
			return "", "", e
		}
		if !inside {
			return "", "", errors.New("nome de pasta fora da area de trabalho")
		}
		if _, e = os.Lstat(p); os.IsNotExist(e) {
			break
		} else if e != nil {
			return "", "", e
		}
		folderName = fmt.Sprintf("%s_%d", baseName, i)
	}
	dir, inside, e := a.resolve(folderName)
	if e != nil {
		return "", "", e
	}
	if !inside {
		return "", "", errors.New("pasta fora da area permitida")
	}
	if err = os.Mkdir(dir, 0755); err != nil {
		return "", "", err
	}
	safeTitle := html.EscapeString(title)
	safeSubtitle := html.EscapeString(subtitle)
	index := `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="` + safeSubtitle + `">
  <title>` + safeTitle + `</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="container nav" id="inicio"><a class="brand" href="#inicio">` + safeTitle + `<span>.</span></a><nav class="menu"><a href="#inicio">Início</a><a href="#sobre">Sobre</a><a href="#contato">Contato</a></nav></header>
  <main>
    <section class="hero container"><span class="eyebrow">Bem-vindo ao nosso espaço</span><h1>Uma ideia incrível <em>começa aqui.</em></h1><p>` + safeSubtitle + `</p><a class="btn" href="#sobre">Saiba mais</a></section>
    <section class="section container" id="sobre"><h2>O que você encontra aqui</h2><div class="grid">
      <article class="card"><div class="symbol">✦</div><h3>Qualidade</h3><p>Atenção aos detalhes, do começo ao fim.</p></article>
      <article class="card"><div class="symbol">◈</div><h3>Criatividade</h3><p>Ideias novas para transformar o cotidiano.</p></article>
      <article class="card"><div class="symbol">★</div><h3>Confiança</h3><p>Uma experiência simples, agradável e transparente.</p></article>
    </div></section>
    <section class="contact" id="contato"><h2>Vamos conversar?</h2><p>Este é um site de exemplo. Personalize o texto e adicione seus contatos.</p><a class="btn" href="#inicio">Voltar ao início</a></section>
  </main><footer class="footer">© ` + safeTitle + ` · Criado com ASDNA Horde</footer>
</body>
</html>
`
	// Criar arquivos com O_EXCL, sem passar pelo terminal nem interpretar codigo remoto.
	for name, content := range map[string]string{"index.html": index, "style.css": pageCSS} {
		if err = os.WriteFile(filepath.Join(dir, name), []byte(content), 0644); err != nil {
			return "", "", err
		}
	}
	return folderName, "Site criado em: " + dir + " (index.html e style.css)", nil
}
