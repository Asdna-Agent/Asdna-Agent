package pcactions

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestParseResponse(t *testing.T) {
	action, ok, err := ParseResponse(`Beleza. <ASDNA_ACTION>{"tool":"write_file","path":"teste.py","content":"print(1)\n"}</ASDNA_ACTION>`)
	if !ok || err != nil || action.Tool != "write_file" || action.Content != "print(1)\n" {
		t.Fatalf("parse: %+v, %v, %v", action, ok, err)
	}
	if _, ok, err := ParseResponse("resposta normal"); ok || err != nil {
		t.Fatalf("plain: %v %v", ok, err)
	}
	if _, ok, err := ParseResponse(`<ASDNA_ACTION>{"tool":"write_file","shell":"rm -rf /"}</ASDNA_ACTION>`); !ok || err == nil {
		t.Fatal("unknown key allowed")
	}
	if _, ok, err := ParseResponse(`<ASDNA_ACTION>{"tool":"write_file"}`); !ok || err == nil {
		t.Fatal("incomplete action allowed")
	}
}
func TestSaveOutsidePermissionsAndOverwrites(t *testing.T) {
	tmp := t.TempDir()
	base := filepath.Join(tmp, "Downloads", "ASDNA_Horde")
	n := 0
	a := &Agent{Base: base, Confirm: func(_ string) bool { n++; return false }}
	out, err := a.Execute(Action{Tool: "write_file", Path: "sub/a.py", Content: "print('a')\n"})
	if err != nil || !strings.Contains(out, "a.py") {
		t.Fatalf("write %q %v", out, err)
	}
	b, err := os.ReadFile(filepath.Join(base, "sub", "a.py"))
	if err != nil || string(b) != "print('a')\n" {
		t.Fatalf("read %q %v", b, err)
	}
	if _, err := a.Execute(Action{Tool: "write_file", Path: "sub/a.py", Content: "new"}); err == nil {
		t.Fatal("overwrite did not require confirmation")
	}
	if n != 1 {
		t.Fatalf("confirm calls %d", n)
	}
	if _, err := a.Execute(Action{Tool: "write_file", Path: "../../outside.txt", Content: "unsafe"}); err == nil {
		t.Fatal("traversal allowed")
	}
	if _, err := os.Stat(filepath.Join(tmp, "outside.txt")); err == nil {
		t.Fatal("escaped to outside")
	}
	if _, err := a.Execute(Action{Tool: "delete_file", Path: "sub/a.py"}); err == nil {
		t.Fatal("delete should be disallowed")
	}
	if _, err := a.Execute(Action{Tool: "read_file", Path: "sub/a.py"}); err == nil {
		t.Fatal("read should ask consent")
	}
}
func TestReadAndCopy(t *testing.T) {
	a := &Agent{Base: t.TempDir(), Confirm: func(_ string) bool { return true }}
	if _, err := a.Execute(Action{Tool: "write_file", Path: "hello.txt", Content: "teste"}); err != nil {
		t.Fatal(err)
	}
	result, err := a.Execute(Action{Tool: "read_file", Path: "hello.txt"})
	if err != nil || !strings.Contains(result, "teste") {
		t.Fatalf("read %v %s", err, result)
	}
	if _, err := a.Execute(Action{Tool: "copy_file", Path: "hello.txt", Destination: "copy.txt"}); err != nil {
		t.Fatal(err)
	}
	if _, err := a.Execute(Action{Tool: "move_file", Path: "copy.txt", Destination: "moved.txt"}); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(a.Base, "copy.txt")); !os.IsNotExist(err) {
		t.Fatal("origem nao foi removida")
	}
}
func TestSymlinkParent(t *testing.T) {
	a := &Agent{Base: t.TempDir(), Confirm: func(_ string) bool { return false }}
	outside := t.TempDir()
	if err := os.Symlink(outside, filepath.Join(a.Base, "link")); err != nil {
		t.Skipf("symlink indisponivel: %v", err)
	}
	if _, err := a.Execute(Action{Tool: "write_file", Path: "link/test.txt", Content: "v"}); err == nil {
		t.Fatal("symlink escaped without permission")
	}
}
func TestExtractAndIntent(t *testing.T) {
	body, ext, ok := ExtractCode("texto\n```python\nprint(1)\n```\n")
	if !ok || ext != "py" || body != "print(1)\n" {
		t.Fatalf("extract %t %s %q", ok, ext, body)
	}
	for _, s := range []string{"crie um arquivo python teste.py", "gera um arquivo .txt", "abra o bloco de notas"} {
		if !IsPCRequest(s) {
			t.Errorf("intent not detected %s", s)
		}
	}
	for _, s := range []string{"como criar um arquivo em Go?", "escreva uma funcao Python", "bom dia"} {
		if IsPCRequest(s) {
			t.Errorf("false pc intent %s", s)
		}
	}
}
