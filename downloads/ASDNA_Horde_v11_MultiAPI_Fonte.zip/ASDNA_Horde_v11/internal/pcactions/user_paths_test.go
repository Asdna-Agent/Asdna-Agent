package pcactions

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func TestUserLocationsAndAliases(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("knownFolder API depends on actual Windows profile; covered in Windows integration")
	}
	h := t.TempDir()
	t.Setenv("HOME", h)
	t.Setenv("USERPROFILE", h)
	t.Setenv("APPDATA", filepath.Join(h, "AppData", "Roaming"))
	t.Setenv("LOCALAPPDATA", filepath.Join(h, "AppData", "Local"))
	for _, tc := range []struct{ raw, want string }{
		{"Documents/WikiAleatoria/index.html", filepath.Join(h, "Documents", "WikiAleatoria", "index.html")},
		{"Meus Documentos/WikiAleatoria/index.html", filepath.Join(h, "Documents", "WikiAleatoria", "index.html")},
		{"Área de Trabalho/site.html", filepath.Join(h, "Desktop", "site.html")},
		{"Desktop/site.html", filepath.Join(h, "Desktop", "site.html")},
		{"%APPDATA%/Minecraft", filepath.Join(h, "AppData", "Roaming", "Minecraft")},
		{"OneDrive/site.html", filepath.Join(h, "OneDrive", "site.html")},
		{"~/site.html", filepath.Join(h, "site.html")},
	} {
		if got := expandUserPath(tc.raw); got != tc.want {
			t.Errorf("%s => %s (want %s)", tc.raw, got, tc.want)
		}
	}
	a := &Agent{Base: filepath.Join(h, "Downloads", "ASDNA_Horde"), Confirm: func(string) bool { return true }}
	out, err := a.Execute(Action{Tool: "write_file", Path: "Documents/WikiAleatoria/index.html", Content: "<html>ok</html>"})
	if err != nil || !strings.Contains(out, "index.html") {
		t.Fatalf("write: %v %s", err, out)
	}
	if _, err := os.Stat(filepath.Join(h, "Documents", "WikiAleatoria", "index.html")); err != nil {
		t.Fatal(err)
	}
}

func TestFindPathScopedToNamedWindowsDirectory(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("OS known folder API test needs an isolated Windows profile")
	}
	h := t.TempDir()
	t.Setenv("HOME", h)
	t.Setenv("USERPROFILE", h)
	folder := filepath.Join(h, "Documents", "Meu Projeto Arquivado")
	if err := os.MkdirAll(folder, 0755); err != nil {
		t.Fatal(err)
	}
	a := &Agent{Base: filepath.Join(h, "Downloads", "ASDNA_Horde")}
	result, err := a.Execute(Action{Tool: "find_path", Query: "Arquivado", Kind: "folder", Path: "Documents"})
	if err != nil || !strings.Contains(result, folder) {
		t.Fatalf("search: %v %q", err, result)
	}
}
