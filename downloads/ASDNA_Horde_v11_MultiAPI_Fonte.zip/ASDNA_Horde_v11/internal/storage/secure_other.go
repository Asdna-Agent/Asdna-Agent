//go:build !windows

package storage

import "errors"

func EncryptKey(key string) (string, error) {
	return "", errors.New("armazenamento DPAPI de chaves funciona apenas no Windows")
}
func DecryptKey(s string) (string, error) {
	return "", errors.New("armazenamento DPAPI de chaves funciona apenas no Windows")
}
