//go:build windows

package storage

import (
	"encoding/base64"
	"errors"
	"syscall"
	"unsafe"
)

type dataBlob struct {
	Size uint32
	Data *byte
}

var (
	crypt32        = syscall.NewLazyDLL("crypt32.dll")
	kernel32       = syscall.NewLazyDLL("kernel32.dll")
	cryptProtect   = crypt32.NewProc("CryptProtectData")
	cryptUnprotect = crypt32.NewProc("CryptUnprotectData")
	localFree      = kernel32.NewProc("LocalFree")
)

func bytesBlob(input []byte) dataBlob {
	if len(input) == 0 {
		return dataBlob{}
	}
	return dataBlob{Size: uint32(len(input)), Data: &input[0]}
}
func protect(input []byte, encrypt bool) ([]byte, error) {
	in := bytesBlob(input)
	var out dataBlob
	var ret uintptr
	var err error
	if encrypt {
		ret, _, err = cryptProtect.Call(uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 1, uintptr(unsafe.Pointer(&out)))
	} else {
		ret, _, err = cryptUnprotect.Call(uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 1, uintptr(unsafe.Pointer(&out)))
	}
	if ret == 0 {
		return nil, err
	}
	if out.Data == nil || out.Size == 0 {
		return nil, errors.New("DPAPI retornou dados vazios")
	}
	defer localFree.Call(uintptr(unsafe.Pointer(out.Data)))
	copied := make([]byte, int(out.Size))
	copy(copied, unsafe.Slice(out.Data, int(out.Size)))
	return copied, nil
}
func EncryptKey(key string) (string, error) {
	b, err := protect([]byte(key), true)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(b), nil
}
func DecryptKey(s string) (string, error) {
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		return "", err
	}
	raw, err := protect(b, false)
	if err != nil {
		return "", err
	}
	return string(raw), nil
}
