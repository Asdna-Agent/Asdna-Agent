package storage

import (
	"encoding/json"
	"testing"
)

func TestLegacyConfigCanReadNewGoSetupField(t *testing.T) {
	var c Config
	if err := json.Unmarshal([]byte(`{"selected_model":"old","max_tokens":160}`), &c); err != nil {
		t.Fatal(err)
	}
	if c.GoSetupPrompted {
		t.Fatal("legacy config should not be marked as prompted")
	}
	c.GoSetupPrompted = true
	b, err := json.Marshal(c)
	if err != nil {
		t.Fatal(err)
	}
	var next Config
	if err := json.Unmarshal(b, &next); err != nil {
		t.Fatal(err)
	}
	if !next.GoSetupPrompted || next.SelectedModel != "old" || next.MaxTokens != 160 {
		t.Fatalf("setup status or previous config lost: %+v", next)
	}
}
