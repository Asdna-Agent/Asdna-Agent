package storage

import (
	"asdna-horde-reconstructed/internal/horde"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"time"
)

// ProviderProfile is stored independently per provider to prevent credentials
// from being accidentally transmitted to a different service.
type ProviderProfile struct {
	Endpoint     string `json:"endpoint,omitempty"`
	KeyProtected string `json:"key_protected,omitempty"`
	Model        string `json:"model,omitempty"`
}
type Config struct {
	EncryptedKey         string                     `json:"api_key_protected,omitempty"` // legacy Horde key
	SelectedModel        string                     `json:"selected_model,omitempty"`
	MaxTokens            int                        `json:"max_tokens"`
	GoSetupPrompted      bool                       `json:"go_setup_prompted,omitempty"`
	Provider             string                     `json:"provider,omitempty"`
	APIEndpoint          string                     `json:"api_endpoint,omitempty"`           // legacy custom URL
	ProviderKeyProtected string                     `json:"provider_key_protected,omitempty"` // legacy custom key
	Profiles             map[string]ProviderProfile `json:"provider_profiles,omitempty"`
	AutoDownloadMCP      *bool                      `json:"auto_download_mcp,omitempty"`
}

func (c *Config) AutoMCP() bool         { return c.AutoDownloadMCP == nil || *c.AutoDownloadMCP }
func (c *Config) SetAutoMCP(value bool) { c.AutoDownloadMCP = &value }
func (c *Config) Profile(name string) ProviderProfile {
	if c.Profiles != nil {
		if p, ok := c.Profiles[name]; ok {
			return p
		}
	}
	if name == "horde" {
		return ProviderProfile{KeyProtected: c.EncryptedKey, Model: c.SelectedModel}
	}
	if name == "compativel" {
		return ProviderProfile{Endpoint: c.APIEndpoint, KeyProtected: c.ProviderKeyProtected}
	}
	return ProviderProfile{}
}
func (c *Config) SetProfile(name string, p ProviderProfile) {
	if c.Profiles == nil {
		c.Profiles = map[string]ProviderProfile{}
	}
	c.Profiles[name] = p
}

type Record struct {
	Time    time.Time `json:"time"`
	Model   string    `json:"model"`
	Role    string    `json:"role"`
	Content string    `json:"content"`
}
type History struct {
	Items []Record `json:"items"`
}

func Dir() (string, error) {
	p, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	path := filepath.Join(p, "ASDNA_Code_Horde_v1")
	return path, os.MkdirAll(path, 0700)
}
func File(name string) (string, error) {
	dir, err := Dir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, name), nil
}
func LoadConfig() (Config, error) {
	c := Config{MaxTokens: 1024}
	p, err := File("config.json")
	if err != nil {
		return c, err
	}
	b, err := os.ReadFile(p)
	if errors.Is(err, os.ErrNotExist) {
		return c, nil
	}
	if err != nil {
		return c, err
	}
	if err := json.Unmarshal(b, &c); err != nil {
		return c, err
	}
	if c.MaxTokens < 48 || c.MaxTokens > 8192 {
		c.MaxTokens = 1024
	}
	return c, nil
}
func SaveConfig(c Config) error { return writeJSON("config.json", c) }
func LoadHistory() (History, error) {
	h := History{Items: []Record{}}
	p, err := File("historico.json")
	if err != nil {
		return h, err
	}
	b, err := os.ReadFile(p)
	if errors.Is(err, os.ErrNotExist) {
		return h, nil
	}
	if err != nil {
		return h, err
	}
	err = json.Unmarshal(b, &h)
	return h, err
}
func SaveHistory(h History) error { return writeJSON("historico.json", h) }
func Archive(h History) error {
	if len(h.Items) == 0 {
		return nil
	}
	return writeJSON("conversa_"+time.Now().Format("20060102_150405")+".json", h)
}
func (h *History) Append(role, model, content string) {
	h.Items = append(h.Items, Record{Time: time.Now(), Role: role, Model: model, Content: content})
}
func (h History) Messages() []horde.Message {
	out := make([]horde.Message, 0, len(h.Items))
	for _, r := range h.Items {
		if r.Role == "user" || r.Role == "assistant" {
			out = append(out, horde.Message{Role: r.Role, Content: r.Content})
		}
	}
	return out
}
func writeJSON(name string, v any) error {
	p, err := File(name)
	if err != nil {
		return err
	}
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, p)
}
