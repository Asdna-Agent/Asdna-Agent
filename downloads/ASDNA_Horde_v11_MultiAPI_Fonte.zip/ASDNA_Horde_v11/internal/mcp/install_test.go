package mcp

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func makeTestZip(t *testing.T, names map[string]string) []byte {
	t.Helper()
	var data bytes.Buffer
	writer := zip.NewWriter(&data)
	for name, content := range names {
		w, err := writer.Create(name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = w.Write([]byte(content)); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	return data.Bytes()
}
func TestInstallChecksumParser(t *testing.T) {
	b := []byte("hello")
	hash := sha256.Sum256(b)
	line := hex.EncodeToString(hash[:]) + "  *release.zip\n"
	got, err := expectedSHA256([]byte(line), "release.zip")
	if err != nil || got != hex.EncodeToString(hash[:]) {
		t.Fatalf("hash: %q %v", got, err)
	}
	_, err = expectedSHA256([]byte(line), "other.zip")
	if err == nil {
		t.Fatal("expected missing checksum error")
	}
}
func TestInstallZipSafety(t *testing.T) {
	root := t.TempDir()
	b := makeTestZip(t, map[string]string{"node-v24.1.0-win-x64/node.exe": "ok", "node-v24.1.0-win-x64/node_modules/npm/bin/npm-cli.js": "npm"})
	if err := safeExtract(b, root, 10000, "node-v24.1.0-win-x64"); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(filepath.Join(root, "node.exe"))
	if err != nil || string(got) != "ok" {
		t.Fatalf("missing file: %s %v", got, err)
	}
	for _, name := range []string{"../escape.txt", "/escape.txt", "C:/evil.txt"} {
		b = makeTestZip(t, map[string]string{name: "evil"})
		if err := safeExtract(b, t.TempDir(), 10000, ""); err == nil {
			t.Fatalf("unsafe zip accepted: %s", name)
		}
	}
	b = makeTestZip(t, map[string]string{"huge.txt": strings.Repeat("a", 1000)})
	if err := safeExtract(b, t.TempDir(), 50, ""); err == nil {
		t.Fatal("oversized zip accepted")
	}
}
func TestInstallRegistryRetainsCustomProviders(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config", "mcp-servers.json")
	initial := Registry{Servers: map[string]Config{"custom": {Command: "test.exe", Enabled: true}, "windows": {Command: "old.exe", Enabled: true}}}
	if err := SaveRegistry(path, initial); err != nil {
		t.Fatal(err)
	}
	after, err := Load(path, Registry{})
	if err != nil {
		t.Fatal(err)
	}
	if after.Servers["custom"].Command != "test.exe" || after.Servers["windows"].Command != "old.exe" {
		t.Fatalf("lost registry entries: %+v", after)
	}
}
func TestInstallerRejectsUnsupportedPlatform(t *testing.T) {
	if _, err := (Installer{}).Install(nil, []string{"windows"}); err == nil && os.PathSeparator == '/' {
		t.Fatal("installer must refuse platform")
	}
}
