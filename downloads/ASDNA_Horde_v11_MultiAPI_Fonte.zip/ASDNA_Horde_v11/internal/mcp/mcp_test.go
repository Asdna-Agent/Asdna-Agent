package mcp

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"testing"
	"time"
)

// A stdio process exercises the wire protocol without Node or network access.
func TestMCPHelper(t *testing.T) {
	if os.Getenv("ASDNA_TEST_MCP_HELPER") != "1" {
		return
	}
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		var request struct {
			ID     json.RawMessage `json:"id"`
			Method string          `json:"method"`
		}
		if json.Unmarshal(scanner.Bytes(), &request) != nil {
			continue
		}
		if len(request.ID) == 0 {
			continue
		}
		var result any
		switch request.Method {
		case "initialize":
			result = map[string]any{"protocolVersion": "2025-06-18", "capabilities": map[string]any{"tools": map[string]any{}}, "serverInfo": map[string]string{"name": "mock", "version": "1"}}
		case "tools/list":
			result = map[string]any{"tools": []map[string]any{{"name": "echo", "description": "echoes input", "inputSchema": map[string]any{"type": "object", "properties": map[string]any{"text": map[string]any{"type": "string"}}}}}}
		case "tools/call":
			result = map[string]any{"content": []map[string]string{{"type": "text", "text": "TEST_OK"}}, "isError": false}
		default:
			result = map[string]any{}
		}
		out, _ := json.Marshal(map[string]any{"jsonrpc": "2.0", "id": request.ID, "result": result})
		fmt.Println(string(out))
	}
	os.Exit(0)
}
func TestStdioMCPIntegration(t *testing.T) {
	t.Setenv("ASDNA_TEST_MCP_HELPER", "1")
	mgr := New(Registry{Servers: map[string]Config{"fake": {Command: os.Args[0], Args: []string{"-test.run=^TestMCPHelper$"}, Enabled: true}}})
	defer mgr.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second)
	defer cancel()
	names := mgr.Names()
	if len(names) != 1 || names[0] != "fake" {
		t.Fatalf("names=%v", names)
	}
	tools, err := mgr.ListTools(ctx, "fake")
	if err != nil {
		t.Fatal(err)
	}
	if len(tools) != 1 || tools[0].Name != "echo" {
		t.Fatalf("tools=%+v", tools)
	}
	got, err := mgr.CallTool(ctx, "fake", "echo", []byte(`{"text":"hi"}`))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(got, "TEST_OK") {
		t.Fatalf("got=%q", got)
	}
	if _, err := mgr.CallTool(ctx, "fake", "unlisted", nil); err == nil {
		t.Fatal("unlisted tool accepted")
	}
}
