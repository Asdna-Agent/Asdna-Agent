package mcp

// Optional, explicit local installers for three free MCP servers. Downloads are
// never started on launch: only the /mcp instalar command can call these APIs.
import (
	"archive/zip"
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"
)

const windowsRelease = "v1.3.28"

var installerHTTP = &http.Client{Timeout: 4 * time.Minute}

type Installer struct {
	Root       string
	ConfigPath string
	Home       string
	Workspace  string
	Progress   func(string)
}

func (i Installer) say(s string) {
	if i.Progress != nil {
		i.Progress(s)
	}
}

func (i Installer) Install(ctx context.Context, targets []string) ([]string, error) {
	if runtime.GOOS != "windows" {
		return nil, errors.New("instalacao integrada disponivel somente no Windows")
	}
	if err := os.MkdirAll(i.Root, 0700); err != nil {
		return nil, err
	}
	cfg, err := Load(i.ConfigPath, DefaultRegistry(i.Home, i.Workspace))
	if err != nil {
		return nil, err
	}
	// Ensure known names only; unexpected names must never execute arbitrary commands.
	var done []string
	var failed []string
	var nodeExe, npmCLI string
	for _, name := range targets {
		switch name {
		case "windows":
			i.say("Windows MCP: baixando versao independente do GitHub e verificando SHA-256...")
			binary, e := i.installWindows(ctx)
			if e != nil {
				failed = append(failed, "windows: "+e.Error())
				continue
			}
			cfg.Servers[name] = Config{Command: binary, Enabled: true}
			done = append(done, name)
		case "filesystem", "playwright":
			if nodeExe == "" {
				i.say("Node.js: verificando instalacao existente ou preparando versao portatil...")
				var e error
				nodeExe, npmCLI, e = i.ensureNode(ctx)
				if e != nil {
					failed = append(failed, name+": "+e.Error())
					continue
				}
			}
			bin := map[string]string{"filesystem": "@modelcontextprotocol/server-filesystem/dist/index.js", "playwright": "@playwright/mcp/cli.js"}[name]
			packageName := map[string]string{"filesystem": "@modelcontextprotocol/server-filesystem@latest", "playwright": "@playwright/mcp@latest"}[name]
			file := filepath.Join(i.Root, "packages", "node_modules", filepath.FromSlash(bin))
			if _, e := os.Stat(file); e != nil {
				i.say(name + ": instalando pacote gratuito pelo npm (sem scripts de instalacao)...")
				if e = i.npmInstall(ctx, nodeExe, npmCLI, packageName); e != nil {
					failed = append(failed, name+": "+e.Error())
					continue
				}
			}
			if _, e := os.Stat(file); e != nil {
				failed = append(failed, name+": arquivo executavel nao encontrado apos instalar")
				continue
			}
			args := []string{file}
			if name == "filesystem" {
				args = append(args, allowedDirectories(i.Home, i.Workspace)...)
			}
			if name == "playwright" {
				args = append(args, "--browser", "chrome")
			}
			cfg.Servers[name] = Config{Command: nodeExe, Args: args, Enabled: true}
			done = append(done, name)
		default:
			failed = append(failed, "alvo desconhecido: "+name)
		}
		if len(done) > 0 {
			if e := SaveRegistry(i.ConfigPath, cfg); e != nil {
				return done, fmt.Errorf("falha salvando MCP: %w", e)
			}
		}
	}
	if len(failed) > 0 {
		return done, errors.New(strings.Join(failed, " | "))
	}
	return done, nil
}

func allowedDirectories(home, workspace string) []string {
	out := []string{}
	seen := map[string]bool{}
	for _, p := range []string{workspace, filepath.Join(home, "Documents"), filepath.Join(home, "Desktop"), filepath.Join(home, "Downloads"), filepath.Join(home, "OneDrive", "Documents"), filepath.Join(home, "OneDrive", "Desktop")} {
		if info, e := os.Stat(p); e == nil && info.IsDir() && !seen[strings.ToLower(p)] {
			seen[strings.ToLower(p)] = true
			out = append(out, p)
		}
	}
	return out
}

func SaveRegistry(path string, r Registry) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(r, "", "  ")
	if err != nil {
		return err
	}
	temp, err := os.CreateTemp(filepath.Dir(path), "mcp-config-*.tmp")
	if err != nil {
		return err
	}
	defer os.Remove(temp.Name())
	if err = temp.Chmod(0600); err != nil {
		temp.Close()
		return err
	}
	if _, err = temp.Write(b); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Close(); err != nil {
		return err
	}
	if _, err = os.Stat(path); errors.Is(err, os.ErrNotExist) {
		return os.Rename(temp.Name(), path)
	}
	backup := path + ".before-install.bak"
	_ = os.Remove(backup)
	if err = os.Rename(path, backup); err != nil {
		return err
	}
	if err = os.Rename(temp.Name(), path); err != nil {
		_ = os.Rename(backup, path)
		return err
	}
	_ = os.Remove(backup)
	return nil
}

// Fetch a bounded official HTTPS resource. Redirects must remain HTTPS.
func fetch(ctx context.Context, url string, maxBytes int64) ([]byte, error) {
	if !strings.HasPrefix(url, "https://") {
		return nil, errors.New("download exige HTTPS")
	}
	request, e := http.NewRequestWithContext(ctx, "GET", url, nil)
	if e != nil {
		return nil, e
	}
	request.Header.Set("User-Agent", "ASDNA-MCP-Installer/10.1")
	client := *installerHTTP
	client.CheckRedirect = func(req *http.Request, via []*http.Request) error {
		if req.URL.Scheme != "https" {
			return errors.New("redirecionamento nao seguro")
		}
		if len(via) >= 6 {
			return errors.New("redirecionamentos excessivos")
		}
		return nil
	}
	res, e := client.Do(request)
	if e != nil {
		return nil, e
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return nil, fmt.Errorf("download HTTP %d de %s", res.StatusCode, url)
	}
	b, e := io.ReadAll(io.LimitReader(res.Body, maxBytes+1))
	if e != nil {
		return nil, e
	}
	if int64(len(b)) > maxBytes {
		return nil, errors.New("download maior que limite de seguranca")
	}
	return b, nil
}
func expectedSHA256(checksums []byte, file string) (string, error) {
	s := bufio.NewScanner(strings.NewReader(string(checksums)))
	for s.Scan() {
		fields := strings.Fields(s.Text())
		if len(fields) < 2 {
			continue
		}
		if strings.TrimLeft(fields[1], "*") == file {
			h := fields[0]
			if len(h) != 64 {
				break
			}
			if _, err := hex.DecodeString(h); err != nil {
				break
			}
			return strings.ToLower(h), nil
		}
	}
	return "", fmt.Errorf("checksum SHA-256 nao encontrado para %s", file)
}
func verifiedDownload(ctx context.Context, url string, checksum []byte, filename string, max int64) ([]byte, error) {
	want, e := expectedSHA256(checksum, filename)
	if e != nil {
		return nil, e
	}
	body, e := fetch(ctx, url, max)
	if e != nil {
		return nil, e
	}
	sum := sha256.Sum256(body)
	if got := hex.EncodeToString(sum[:]); got != want {
		return nil, fmt.Errorf("SHA-256 divergente: download %s rejeitado", filename)
	}
	return body, nil
}

func safeExtract(data []byte, target string, maxExpanded int64, stripPrefix string) error {
	z, e := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if e != nil {
		return e
	}
	if len(z.File) > 12000 {
		return errors.New("ZIP com entradas demais")
	}
	var total int64
	base, e := filepath.Abs(target)
	if e != nil {
		return e
	}
	for _, f := range z.File {
		name := strings.ReplaceAll(f.Name, "\\", "/")
		if stripPrefix != "" {
			if !strings.HasPrefix(name, stripPrefix+"/") {
				continue
			}
			name = strings.TrimPrefix(name, stripPrefix+"/")
		}
		if name == "" {
			continue
		}
		cleaned := filepath.Clean(filepath.FromSlash(name))
		if filepath.IsAbs(cleaned) || cleaned == ".." || strings.HasPrefix(cleaned, ".."+string(os.PathSeparator)) || strings.Contains(cleaned, ":") {
			return fmt.Errorf("caminho inseguro no ZIP: %q", f.Name)
		}
		if f.Mode()&os.ModeSymlink != 0 {
			return errors.New("links simbolicos nao permitidos em instaladores")
		}
		full := filepath.Join(base, cleaned)
		if rel, err := filepath.Rel(base, full); err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
			return errors.New("entrada ZIP fora do diretorio")
		}
		if f.FileInfo().IsDir() {
			if e := os.MkdirAll(full, 0700); e != nil {
				return e
			}
			continue
		}
		if f.UncompressedSize64 > uint64(maxExpanded) || total+int64(f.UncompressedSize64) > maxExpanded {
			return errors.New("conteudo ZIP excede limite")
		}
		total += int64(f.UncompressedSize64)
		if e := os.MkdirAll(filepath.Dir(full), 0700); e != nil {
			return e
		}
		r, e := f.Open()
		if e != nil {
			return e
		}
		dst, e := os.OpenFile(full, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
		if e != nil {
			r.Close()
			return e
		}
		copied, copyErr := io.Copy(dst, io.LimitReader(r, int64(f.UncompressedSize64)+1))
		closeErr := dst.Close()
		r.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		if copied != int64(f.UncompressedSize64) {
			return errors.New("tamanho expandido divergente")
		}
	}
	return nil
}

func (i Installer) installWindows(ctx context.Context) (string, error) {
	if runtime.GOARCH != "amd64" {
		return "", errors.New("o pacote Windows MCP automatico exige arquitetura x64")
	}
	target := filepath.Join(i.Root, "windows")
	// Preserve existing installation and avoid repeated network download.
	if b := findWindowsBinary(target); b != "" {
		return b, nil
	}
	name := "windows-mcp-server-" + strings.TrimPrefix(windowsRelease, "v") + "-win-x64.zip"
	base := "https://github.com/sbroenne/mcp-windows/releases/download/" + windowsRelease + "/"
	sha, e := fetch(ctx, base+"SHA256SUMS.txt", 1024*1024)
	if e != nil {
		return "", e
	}
	bytes, e := verifiedDownload(ctx, base+name, sha, name, 300<<20)
	if e != nil {
		return "", e
	}
	stage, e := os.MkdirTemp(i.Root, "windows-stage-")
	if e != nil {
		return "", e
	}
	defer os.RemoveAll(stage)
	if e = safeExtract(bytes, stage, 900<<20, ""); e != nil {
		return "", e
	}
	b := findWindowsBinary(stage)
	if b == "" {
		return "", errors.New("pacote Windows MCP sem executavel esperado")
	}
	if e = os.Rename(stage, target); e != nil {
		return "", e
	}
	return findWindowsBinary(target), nil
}
func findWindowsBinary(root string) string {
	var result string
	_ = filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if !info.IsDir() && strings.EqualFold(info.Name(), "Sbroenne.WindowsMcp.exe") {
			result = path
			return filepath.SkipAll
		}
		return nil
	})
	return result
}

func nodeMajor(exe string) int {
	out, e := exec.Command(exe, "--version").Output()
	if e != nil {
		return 0
	}
	ver := strings.TrimSpace(strings.TrimPrefix(string(out), "v"))
	parts := strings.Split(ver, ".")
	if len(parts) == 0 {
		return 0
	}
	n, _ := strconv.Atoi(parts[0])
	return n
}
func (i Installer) ensureNode(ctx context.Context) (string, string, error) {
	port := filepath.Join(i.Root, "node")
	nodeExe := filepath.Join(port, "node.exe")
	npmCLI := filepath.Join(port, "node_modules", "npm", "bin", "npm-cli.js")
	if nodeMajor(nodeExe) >= 24 {
		if _, err := os.Stat(npmCLI); err == nil {
			return nodeExe, npmCLI, nil
		}
	}
	if sys, err := exec.LookPath("node.exe"); err == nil && nodeMajor(sys) >= 24 {
		parent := filepath.Dir(sys)
		for _, candidate := range []string{filepath.Join(parent, "node_modules", "npm", "bin", "npm-cli.js")} {
			if _, err := os.Stat(candidate); err == nil {
				return sys, candidate, nil
			}
		}
	}
	// Node.js official portable ZIP: no admin privileges, MSI or global PATH changes.
	const root = "https://nodejs.org/dist/latest-v24.x/"
	sums, e := fetch(ctx, root+"SHASUMS256.txt", 1<<20)
	if e != nil {
		return "", "", e
	}
	var name string
	matches := regexp.MustCompile(`node-v24\.[0-9]+\.[0-9]+-win-x64\.zip`).FindAllString(string(sums), -1)
	if len(matches) == 0 {
		return "", "", errors.New("ZIP oficial Node 24 x64 nao encontrado")
	}
	name = matches[0]
	body, e := verifiedDownload(ctx, root+name, sums, name, 110<<20)
	if e != nil {
		return "", "", e
	}
	stage, e := os.MkdirTemp(i.Root, "node-stage-")
	if e != nil {
		return "", "", e
	}
	defer os.RemoveAll(stage)
	prefix := strings.TrimSuffix(name, ".zip")
	if e = safeExtract(body, stage, 550<<20, prefix); e != nil {
		return "", "", e
	}
	if nodeMajor(filepath.Join(stage, "node.exe")) < 24 {
		return "", "", errors.New("Node baixado nao e versao compativel")
	}
	if _, e = os.Stat(filepath.Join(stage, "node_modules", "npm", "bin", "npm-cli.js")); e != nil {
		return "", "", errors.New("Node oficial sem npm incluido")
	}
	if _, e = os.Stat(nodeExe); e == nil {
		return "", "", errors.New("Node portatil anterior ja existe, mas esta incompleto; remova a pasta mcp-runtime/node")
	}
	if e = os.Rename(stage, port); e != nil {
		return "", "", e
	}
	return nodeExe, npmCLI, nil
}

func (i Installer) npmInstall(ctx context.Context, nodeExe, npmCLI, pkg string) error {
	packages := filepath.Join(i.Root, "packages")
	if e := os.MkdirAll(packages, 0700); e != nil {
		return e
	}
	// Controlled package names only, never arbitrary shell text.
	if pkg != "@playwright/mcp@latest" && pkg != "@modelcontextprotocol/server-filesystem@latest" {
		return errors.New("pacote nao permitido")
	}
	// npm init if needed. The package lock keeps a record of resolved versions.
	manifest := filepath.Join(packages, "package.json")
	if _, e := os.Stat(manifest); errors.Is(e, os.ErrNotExist) {
		if e = os.WriteFile(manifest, []byte(`{"name":"asdna-mcp-runtime","private":true,"version":"1.0.0"}`), 0600); e != nil {
			return e
		}
	}
	command := exec.CommandContext(ctx, nodeExe, npmCLI, "install", "--prefix", packages, "--no-audit", "--no-fund", "--ignore-scripts", "--save-exact", pkg)
	command.Dir = packages
	command.Env = append(os.Environ(), "PATH="+filepath.Dir(nodeExe)+string(os.PathListSeparator)+os.Getenv("PATH"))
	output, e := command.CombinedOutput()
	if e != nil {
		return fmt.Errorf("npm: %w: %s", e, stringTrim(string(output), 1400))
	}
	return nil
}
func stringTrim(s string, n int) string {
	if len(s) > n {
		return s[:n] + "..."
	}
	return s
}
