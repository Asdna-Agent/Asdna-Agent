//go:build windows

package terminal

import (
	"os"
	"unsafe"
)

const (
	enableProcessedOutput = 0x0001
	enableVTProcessing    = 0x0004
)

type coord struct{ X, Y int16 }
type smallRect struct{ Left, Top, Right, Bottom int16 }
type consoleInfo struct {
	Size       coord
	Cursor     coord
	Attributes uint16
	Window     smallRect
	MaxSize    coord
}

var getScreenInfo = kernel32.NewProc("GetConsoleScreenBufferInfo")

// EnableVT liga o processamento de sequencias ANSI/VT no console do Windows.
// Retorna false se a saida nao for um console (ex.: redirecionada) ou se o
// Windows nao suportar (versoes muito antigas).
func EnableVT() bool {
	h := os.Stdout.Fd()
	var mode uint32
	r, _, _ := getConsoleMode.Call(h, uintptr(unsafe.Pointer(&mode)))
	if r == 0 {
		return false
	}
	r, _, _ = setConsoleMode.Call(h, uintptr(mode|enableProcessedOutput|enableVTProcessing))
	return r != 0
}

// Width devolve a largura atual da janela do console (0 se desconhecida).
func Width() int {
	var info consoleInfo
	r, _, _ := getScreenInfo.Call(os.Stdout.Fd(), uintptr(unsafe.Pointer(&info)))
	if r == 0 {
		return 0
	}
	return int(info.Window.Right-info.Window.Left) + 1
}
