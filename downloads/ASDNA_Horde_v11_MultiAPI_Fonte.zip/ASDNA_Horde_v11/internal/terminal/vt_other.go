//go:build !windows

package terminal

import (
	"os"
	"strconv"
)

// EnableVT: fora do Windows, assume suporte a ANSI, salvo TERM=dumb/NO_COLOR.
func EnableVT() bool {
	return os.Getenv("TERM") != "dumb" && os.Getenv("NO_COLOR") == ""
}

// Width le COLUMNS (0 se desconhecida).
func Width() int {
	n, _ := strconv.Atoi(os.Getenv("COLUMNS"))
	return n
}
