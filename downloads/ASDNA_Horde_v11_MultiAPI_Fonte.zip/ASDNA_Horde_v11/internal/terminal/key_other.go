//go:build !windows

package terminal

func HideInputEcho() func() { return func() {} }
