//go:build windows

package terminal

import (
	"os"
	"syscall"
	"unsafe"
)

const echoInput = 0x0004

var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var getConsoleMode = kernel32.NewProc("GetConsoleMode")
var setConsoleMode = kernel32.NewProc("SetConsoleMode")

func HideInputEcho() func() {
	handle := os.Stdin.Fd()
	var mode uint32
	r, _, _ := getConsoleMode.Call(handle, uintptr(unsafe.Pointer(&mode)))
	if r == 0 {
		return func() {}
	}
	r, _, _ = setConsoleMode.Call(handle, uintptr(mode&^echoInput))
	if r == 0 {
		return func() {}
	}
	return func() { setConsoleMode.Call(handle, uintptr(mode)) }
}
