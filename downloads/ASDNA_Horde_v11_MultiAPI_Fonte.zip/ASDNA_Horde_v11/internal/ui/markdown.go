package ui

import (
	"fmt"
	"strings"
	"unicode"
)

// ---------------------------------------------------------------------------
// Estilo inline
// ---------------------------------------------------------------------------

type style struct {
	bold, ital, strike, code, link, dim bool
	hd                                  uint8 // 0 = nada, 1..3 = nivel de titulo
}

type run struct {
	text string
	st   style
}

var (
	cWhite    = rgb{240, 244, 255}
	cCodeSpan = rgb{46, 52, 78}
)

func (s style) sgr() string {
	if !on {
		return ""
	}
	if s == (style{}) {
		return "\x1b[0m"
	}
	var b strings.Builder
	b.WriteString("\x1b[0")
	if s.bold || s.hd > 0 {
		b.WriteString(";1")
	}
	if s.ital {
		b.WriteString(";3")
	}
	if s.strike {
		b.WriteString(";9")
	}
	if s.link {
		b.WriteString(";4")
	}
	col := cText
	switch {
	case s.code:
		col = cOrange
	case s.link:
		col = cAccent
	case s.hd == 1:
		col = cPurple
	case s.hd == 2:
		col = cAccent
	case s.hd >= 3:
		col = cCyan
	case s.dim:
		col = cDim
	case s.bold:
		col = cWhite
	}
	b.WriteString(fmt.Sprintf(";38;2;%d;%d;%d", col.r, col.g, col.b))
	if s.code {
		b.WriteString(fmt.Sprintf(";48;2;%d;%d;%d", cCodeSpan.r, cCodeSpan.g, cCodeSpan.b))
	}
	b.WriteString("m")
	return b.String()
}

func setStyle(b *strings.Builder, active *style, st style) {
	if *active != st {
		b.WriteString(st.sgr())
		*active = st
	}
}

// ---------------------------------------------------------------------------
// Utilidades de largura / texto
// ---------------------------------------------------------------------------

func runeWidth(r rune) int {
	switch {
	case r == 0 || (r >= 0x300 && r <= 0x36F) || (r >= 0x200B && r <= 0x200F) || r == 0xFE0F:
		return 0
	case (r >= 0x1100 && r <= 0x115F) || (r >= 0x2E80 && r <= 0xA4CF) ||
		(r >= 0xAC00 && r <= 0xD7A3) || (r >= 0xF900 && r <= 0xFAFF) ||
		(r >= 0xFE30 && r <= 0xFE6F) || (r >= 0xFF00 && r <= 0xFF60) ||
		(r >= 0xFFE0 && r <= 0xFFE6) || (r >= 0x1F300 && r <= 0x1F64F) ||
		(r >= 0x1F900 && r <= 0x1F9FF):
		return 2
	}
	return 1
}

func strWidth(s string) int {
	w := 0
	for _, r := range s {
		w += runeWidth(r)
	}
	return w
}

func truncate(s string, n int) string {
	if n <= 0 {
		return ""
	}
	if strWidth(s) <= n {
		return s
	}
	var b strings.Builder
	w := 0
	for _, r := range s {
		rw := runeWidth(r)
		if w+rw > n-1 {
			break
		}
		b.WriteRune(r)
		w += rw
	}
	return b.String() + "…"
}

// sanitize remove caracteres de controle (evita que o texto do modelo
// injete sequencias de escape no console), mantendo \n e \t.
func sanitize(s string) string {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.ReplaceAll(s, "\r", "\n")
	return strings.Map(func(r rune) rune {
		if r == '\n' || r == '\t' {
			return r
		}
		if r < 0x20 || r == 0x7f || (r >= 0x80 && r < 0xa0) {
			return -1
		}
		return r
	}, s)
}

func isAlnum(r rune) bool { return unicode.IsLetter(r) || unicode.IsDigit(r) }

func isMdPunct(r rune) bool {
	return r != 0 && strings.ContainsRune("\\`*_{}[]()#+-.!|~>", r)
}

func indexRune(rs []rune, r rune, from int) int {
	for k := from; k < len(rs); k++ {
		if rs[k] == r {
			return k
		}
	}
	return -1
}

func hasCloser(rs []rune, from int, m rune, cnt int) bool {
	for k := from; k < len(rs); k++ {
		if rs[k] == m && (cnt == 1 || (k+1 < len(rs) && rs[k+1] == m)) {
			return true
		}
	}
	return false
}

func plainText(runs []run) string {
	var b strings.Builder
	for _, r := range runs {
		b.WriteString(r.text)
	}
	return b.String()
}

// ---------------------------------------------------------------------------
// Parser inline: **negrito**, *italico*, `codigo`, ~~riscado~~, [link](url)
// ---------------------------------------------------------------------------

func parseInline(src string) []run {
	rs := []rune(src)
	n := len(rs)
	at := func(i int) rune {
		if i < 0 || i >= n {
			return 0
		}
		return rs[i]
	}
	var out []run
	var cur strings.Builder
	var st style
	flush := func() {
		if cur.Len() > 0 {
			out = append(out, run{cur.String(), st})
			cur.Reset()
		}
	}
	for i := 0; i < n; i++ {
		c := rs[i]
		switch {
		case c == '\\' && isMdPunct(at(i+1)):
			cur.WriteRune(at(i + 1))
			i++

		case c == '`':
			t := 0
			for i+t < n && rs[i+t] == '`' {
				t++
			}
			j := -1
			for k := i + t; k < n; k++ {
				if rs[k] == '`' {
					m := 0
					for k+m < n && rs[k+m] == '`' {
						m++
					}
					if m == t {
						j = k
						break
					}
					k += m - 1
				}
			}
			if j >= 0 {
				flush()
				content := strings.TrimSpace(string(rs[i+t : j]))
				if content != "" {
					cs := st
					cs.code = true
					out = append(out, run{content, cs})
				}
				i = j + t - 1
			} else {
				cur.WriteString(strings.Repeat("`", t))
				i += t - 1
			}

		case (c == '*' || c == '_') && at(i+1) == c:
			if !st.bold {
				nx := at(i + 2)
				okOpen := nx != 0 && !unicode.IsSpace(nx) && hasCloser(rs, i+2, c, 2)
				if c == '_' && isAlnum(at(i-1)) {
					okOpen = false
				}
				if okOpen {
					flush()
					st.bold = true
					i++
				} else {
					cur.WriteRune(c)
				}
			} else {
				okClose := !unicode.IsSpace(at(i - 1))
				if c == '_' && isAlnum(at(i+2)) {
					okClose = false
				}
				if okClose {
					flush()
					st.bold = false
					i++
				} else {
					cur.WriteRune(c)
				}
			}

		case c == '~' && at(i+1) == '~':
			if !st.strike {
				nx := at(i + 2)
				if nx != 0 && !unicode.IsSpace(nx) && hasCloser(rs, i+2, '~', 2) {
					flush()
					st.strike = true
					i++
				} else {
					cur.WriteRune(c)
				}
			} else {
				flush()
				st.strike = false
				i++
			}

		case c == '*' || c == '_':
			if !st.ital {
				nx := at(i + 1)
				okOpen := nx != 0 && !unicode.IsSpace(nx) && nx != c && hasCloser(rs, i+1, c, 1)
				if c == '_' && isAlnum(at(i-1)) {
					okOpen = false
				}
				if okOpen {
					flush()
					st.ital = true
				} else {
					cur.WriteRune(c)
				}
			} else {
				okClose := !unicode.IsSpace(at(i - 1))
				if c == '_' && isAlnum(at(i+1)) {
					okClose = false
				}
				if okClose {
					flush()
					st.ital = false
				} else {
					cur.WriteRune(c)
				}
			}

		case c == '[':
			cl := indexRune(rs, ']', i+1)
			if cl > i && at(cl+1) == '(' {
				ce := indexRune(rs, ')', cl+2)
				if ce > cl {
					flush()
					label := parseInline(string(rs[i+1 : cl]))
					for k := range label {
						label[k].st.link = true
					}
					out = append(out, label...)
					url := strings.TrimSpace(string(rs[cl+2 : ce]))
					if url != "" {
						out = append(out, run{" (" + url + ")", style{dim: true}})
					}
					i = ce
					continue
				}
			}
			cur.WriteRune(c)

		default:
			cur.WriteRune(c)
		}
	}
	flush()
	return out
}

// ---------------------------------------------------------------------------
// Quebra de linha (word wrap) com estilos
// ---------------------------------------------------------------------------

type token struct {
	text string
	st   style
	sp   bool // havia espaco antes deste token
}

func tokenize(runs []run) []token {
	var toks []token
	pending := false
	for _, r := range runs {
		if r.st.code {
			toks = append(toks, token{" " + r.text + " ", r.st, pending})
			pending = false
			continue
		}
		var b strings.Builder
		for _, ch := range r.text {
			if ch == ' ' || ch == '\t' || ch == '\n' {
				if b.Len() > 0 {
					toks = append(toks, token{b.String(), r.st, pending})
					b.Reset()
					pending = false
				}
				pending = true
			} else {
				b.WriteRune(ch)
			}
		}
		if b.Len() > 0 {
			toks = append(toks, token{b.String(), r.st, pending})
			pending = false
		}
	}
	return toks
}

func splitLong(t token, width int) []token {
	if strWidth(t.text) <= width {
		return []token{t}
	}
	var out []token
	var b strings.Builder
	w := 0
	first := true
	flushTok := func() {
		if b.Len() > 0 {
			nt := token{b.String(), t.st, false}
			if first {
				nt.sp = t.sp
				first = false
			}
			out = append(out, nt)
			b.Reset()
			w = 0
		}
	}
	for _, r := range t.text {
		rw := runeWidth(r)
		if w+rw > width {
			flushTok()
		}
		b.WriteRune(r)
		w += rw
	}
	flushTok()
	return out
}

func wrapTokens(toks []token, width int) [][]token {
	if width < 8 {
		width = 8
	}
	var lines [][]token
	var line []token
	w := 0
	for _, t := range toks {
		for _, piece := range splitLong(t, width) {
			tw := strWidth(piece.text)
			add := tw
			if len(line) > 0 && piece.sp {
				add++
			}
			if len(line) > 0 && w+add > width {
				lines = append(lines, line)
				line = nil
				w = 0
				add = tw
			}
			if len(line) == 0 {
				piece.sp = false
			}
			line = append(line, piece)
			w += add
		}
	}
	if len(line) > 0 {
		lines = append(lines, line)
	}
	return lines
}

func tokensString(line []token) string {
	var b strings.Builder
	active := style{}
	for i, t := range line {
		if i > 0 && t.sp {
			prev := line[i-1]
			if prev.st == t.st && !t.st.code {
				b.WriteString(" ")
			} else {
				setStyle(&b, &active, style{})
				b.WriteString(" ")
			}
		}
		setStyle(&b, &active, t.st)
		b.WriteString(t.text)
	}
	setStyle(&b, &active, style{})
	return b.String()
}

func plainLine(line []token) string {
	var b strings.Builder
	for i, t := range line {
		if i > 0 && t.sp {
			b.WriteByte(' ')
		}
		b.WriteString(t.text)
	}
	return b.String()
}

func renderRuns(runs []run, width int) []string {
	lines := wrapTokens(tokenize(runs), width)
	out := make([]string, 0, len(lines))
	for _, l := range lines {
		out = append(out, tokensString(l))
	}
	return out
}

func inlineString(runs []run) string {
	var b strings.Builder
	active := style{}
	for _, r := range runs {
		setStyle(&b, &active, r.st)
		b.WriteString(r.text)
	}
	setStyle(&b, &active, style{})
	return b.String()
}

// wrapPlain quebra texto simples (sem markdown) preservando indentacao e
// linhas em branco.
func wrapPlain(text string, width int) []string {
	var out []string
	for _, src := range strings.Split(sanitize(text), "\n") {
		exp := strings.ReplaceAll(src, "\t", "    ")
		ind := len(exp) - len(strings.TrimLeft(exp, " "))
		if ind > 16 {
			ind = 16
		}
		body := strings.TrimSpace(exp)
		if body == "" {
			out = append(out, "")
			continue
		}
		for _, l := range wrapTokens(tokenize([]run{{body, style{}}}), width-ind) {
			out = append(out, strings.Repeat(" ", ind)+plainLine(l))
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Blocos markdown
// ---------------------------------------------------------------------------

// Markdown converte texto markdown em linhas ja estilizadas (ANSI) que cabem
// em "width" colunas.
func Markdown(text string, width int) []string {
	if width < 20 {
		width = 20
	}
	src := strings.Split(sanitize(text), "\n")
	var out []string
	for i := 0; i < len(src); {
		raw := strings.TrimRight(src[i], " \t")
		trim := strings.TrimSpace(raw)
		switch {
		case trim == "":
			if len(out) > 0 && out[len(out)-1] != "" {
				out = append(out, "")
			}
			i++

		case strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~"):
			fence := trim[:3]
			lang := strings.TrimSpace(trim[3:])
			var code []string
			i++
			for i < len(src) && !strings.HasPrefix(strings.TrimSpace(src[i]), fence) {
				code = append(code, strings.TrimRight(src[i], " \t"))
				i++
			}
			if i < len(src) {
				i++
			}
			if len(out) > 0 && out[len(out)-1] != "" {
				out = append(out, "")
			}
			out = append(out, codeBlock(code, lang, width)...)

		case isRule(trim):
			out = append(out, paint(cFaint, strings.Repeat("─", width)))
			i++

		case headingLevel(trim) > 0:
			lvl := headingLevel(trim)
			title := strings.TrimSpace(trim[lvl:])
			if len(out) > 0 && out[len(out)-1] != "" {
				out = append(out, "")
			}
			hd := uint8(lvl)
			if hd > 3 {
				hd = 3
			}
			runs := parseInline(title)
			for k := range runs {
				runs[k].st.hd = hd
				runs[k].st.bold = true
			}
			out = append(out, renderRuns(runs, width)...)
			if lvl == 1 {
				out = append(out, paint(cFaint, strings.Repeat("─", min(width, 40))))
			}
			i++

		case strings.HasPrefix(trim, ">"):
			var qs []string
			for i < len(src) {
				t := strings.TrimSpace(src[i])
				if !strings.HasPrefix(t, ">") {
					break
				}
				t = strings.TrimPrefix(t, ">")
				t = strings.TrimPrefix(t, " ")
				qs = append(qs, t)
				i++
			}
			for _, l := range Markdown(strings.Join(qs, "\n"), width-2) {
				out = append(out, paint(cPurple, "│")+" "+l)
			}

		case strings.HasPrefix(trim, "|") && i+1 < len(src) && isTableSep(src[i+1]):
			var rows [][]string
			for i < len(src) && strings.HasPrefix(strings.TrimSpace(src[i]), "|") {
				if !isTableSep(src[i]) {
					rows = append(rows, splitRow(src[i]))
				}
				i++
			}
			if len(out) > 0 && out[len(out)-1] != "" {
				out = append(out, "")
			}
			out = append(out, renderTable(rows, width)...)

		default:
			if ind, num, rest, ok := parseListItem(raw); ok {
				out = append(out, renderListItem(ind, num, rest, width)...)
			} else {
				ind := len(raw) - len(strings.TrimLeft(raw, " "))
				if ind > 8 {
					ind = 8
				}
				for _, l := range renderRuns(parseInline(trim), width-ind) {
					out = append(out, strings.Repeat(" ", ind)+l)
				}
			}
			i++
		}
	}
	for len(out) > 0 && out[len(out)-1] == "" {
		out = out[:len(out)-1]
	}
	return out
}

func headingLevel(t string) int {
	n := 0
	for n < len(t) && t[n] == '#' {
		n++
	}
	if n >= 1 && n <= 6 && n < len(t) && t[n] == ' ' {
		return n
	}
	return 0
}

func isRule(t string) bool {
	s := strings.ReplaceAll(t, " ", "")
	if len(s) < 3 {
		return false
	}
	c := s[0]
	if c != '-' && c != '*' && c != '_' {
		return false
	}
	for i := 0; i < len(s); i++ {
		if s[i] != c {
			return false
		}
	}
	return true
}

func parseListItem(raw string) (indent int, num string, rest string, ok bool) {
	i := 0
	for i < len(raw) && (raw[i] == ' ' || raw[i] == '\t') {
		if raw[i] == '\t' {
			indent += 4
		} else {
			indent++
		}
		i++
	}
	s := raw[i:]
	if len(s) >= 2 && (s[0] == '-' || s[0] == '*' || s[0] == '+') && s[1] == ' ' {
		return indent, "", strings.TrimSpace(s[2:]), true
	}
	j := 0
	for j < len(s) && s[j] >= '0' && s[j] <= '9' {
		j++
	}
	if j > 0 && j < len(s)-1 && (s[j] == '.' || s[j] == ')') && s[j+1] == ' ' {
		return indent, s[:j] + ".", strings.TrimSpace(s[j+2:]), true
	}
	return 0, "", "", false
}

func renderListItem(indent int, num, rest string, width int) []string {
	level := indent / 2
	if level > 4 {
		level = 4
	}
	marker := num
	mcol := cAccent
	if marker == "" {
		marker = []string{"•", "◦", "▪"}[level%3]
	}
	if strings.HasPrefix(rest, "[ ]") {
		marker = "[ ]"
		mcol = cDim
		rest = strings.TrimSpace(rest[3:])
	} else if strings.HasPrefix(rest, "[x]") || strings.HasPrefix(rest, "[X]") {
		marker = "[x]"
		mcol = cGreen
		rest = strings.TrimSpace(rest[3:])
	}
	pad := strings.Repeat(" ", level*2)
	mw := strWidth(marker)
	avail := width - level*2 - mw - 1
	if avail < 10 {
		avail = 10
	}
	ls := renderRuns(parseInline(rest), avail)
	if len(ls) == 0 {
		ls = []string{""}
	}
	out := make([]string, 0, len(ls))
	for k, l := range ls {
		if k == 0 {
			out = append(out, pad+paint(mcol, marker)+" "+l)
		} else {
			out = append(out, pad+strings.Repeat(" ", mw+1)+l)
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Tabelas
// ---------------------------------------------------------------------------

func isTableSep(s string) bool {
	t := strings.TrimSpace(s)
	if !strings.Contains(t, "-") || !strings.Contains(t, "|") {
		return false
	}
	for _, r := range t {
		if r != '|' && r != '-' && r != ':' && r != ' ' {
			return false
		}
	}
	return true
}

func splitRow(line string) []string {
	t := strings.TrimSpace(line)
	t = strings.TrimPrefix(t, "|")
	t = strings.TrimSuffix(t, "|")
	parts := strings.Split(t, "|")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return parts
}

func renderTable(rows [][]string, width int) []string {
	cols := 0
	for _, r := range rows {
		if len(r) > cols {
			cols = len(r)
		}
	}
	if cols == 0 {
		return nil
	}
	cells := make([][][]run, len(rows))
	colW := make([]int, cols)
	for ri, r := range rows {
		cells[ri] = make([][]run, cols)
		for ci := 0; ci < cols; ci++ {
			txt := ""
			if ci < len(r) {
				txt = r[ci]
			}
			rr := parseInline(txt)
			cells[ri][ci] = rr
			if w := strWidth(plainText(rr)); w > colW[ci] {
				colW[ci] = w
			}
		}
	}
	total := 1
	for _, w := range colW {
		total += w + 3
	}
	for total > width {
		mi := -1
		for ci, w := range colW {
			if w > 6 && (mi < 0 || w > colW[mi]) {
				mi = ci
			}
		}
		if mi < 0 {
			break
		}
		colW[mi]--
		total--
	}
	hline := func(l, m, r string) string {
		parts := make([]string, cols)
		for ci, w := range colW {
			parts[ci] = strings.Repeat("─", w+2)
		}
		return paint(cFaint, l+strings.Join(parts, m)+r)
	}
	var out []string
	out = append(out, hline("┌", "┬", "┐"))
	for ri := range rows {
		var b strings.Builder
		b.WriteString(paint(cFaint, "│"))
		for ci := 0; ci < cols; ci++ {
			rr := cells[ri][ci]
			if ri == 0 {
				for k := range rr {
					rr[k].st.bold = true
					rr[k].st.hd = 2
				}
			}
			plain := plainText(rr)
			if strWidth(plain) > colW[ci] {
				st := style{}
				if ri == 0 {
					st = style{bold: true, hd: 2}
				}
				rr = []run{{truncate(plain, colW[ci]), st}}
				plain = plainText(rr)
			}
			pad := colW[ci] - strWidth(plain)
			if pad < 0 {
				pad = 0
			}
			b.WriteString(" " + inlineString(rr) + strings.Repeat(" ", pad) + " " + paint(cFaint, "│"))
		}
		out = append(out, b.String())
		if ri == 0 {
			out = append(out, hline("├", "┼", "┤"))
		}
	}
	out = append(out, hline("└", "┴", "┘"))
	return out
}

// ---------------------------------------------------------------------------
// Blocos de codigo
// ---------------------------------------------------------------------------

func splitRows(rs []rune, inner int) [][2]int {
	var rows [][2]int
	start, w := 0, 0
	for i, r := range rs {
		rw := runeWidth(r)
		if w+rw > inner && i > start {
			rows = append(rows, [2]int{start, i})
			start, w = i, 0
		}
		w += rw
	}
	rows = append(rows, [2]int{start, len(rs)})
	return rows
}

func codeRow(rs []rune, cls []uint8, s, e, inner int) string {
	var b strings.Builder
	b.WriteString(paint(cFaint, "│"))
	b.WriteString(bg(cCode))
	b.WriteString(" ")
	last := uint8(255)
	wv := 0
	for k := s; k < e; k++ {
		if on && cls[k] != last {
			b.WriteString(fg(clsColor[cls[k]]))
			last = cls[k]
		}
		b.WriteRune(rs[k])
		wv += runeWidth(rs[k])
	}
	pad := inner - wv
	if pad < 0 {
		pad = 0
	}
	b.WriteString(strings.Repeat(" ", pad+1))
	b.WriteString(reset())
	b.WriteString(paint(cFaint, "│"))
	return b.String()
}

func codeBlock(code []string, lang string, width int) []string {
	inner := width - 4
	if inner < 10 {
		inner = 10
	}
	label := ""
	if f := strings.Fields(strings.ToLower(lang)); len(f) > 0 {
		label = truncate(f[0], inner-4)
	}
	total := inner + 4
	var out []string
	if label == "" {
		out = append(out, paint(cFaint, "╭"+strings.Repeat("─", total-2)+"╮"))
	} else {
		dashes := total - 5 - strWidth(label)
		if dashes < 1 {
			dashes = 1
		}
		out = append(out, paint(cFaint, "╭─ ")+paint(cCyan, label)+paint(cFaint, " "+strings.Repeat("─", dashes)+"╮"))
	}
	if len(code) == 0 {
		code = []string{""}
	}
	for _, line := range code {
		line = strings.ReplaceAll(line, "\t", "    ")
		rs, cls := highlight(line, label)
		for _, rg := range splitRows(rs, inner) {
			out = append(out, codeRow(rs, cls, rg[0], rg[1], inner))
		}
	}
	out = append(out, paint(cFaint, "╰"+strings.Repeat("─", total-2)+"╯"))
	return out
}
