// Package ui cuida SOMENTE da parte visual do ASDNA Horde: cores, caixas,
// markdown, animacao de "Thinking". Nenhuma regra de negocio fica aqui.
package ui

import (
	"fmt"
	"strings"
	"sync"
	"time"

	"asdna-horde-reconstructed/internal/terminal"
)

type rgb struct{ r, g, b int }

// Paleta (tons estilo "Tokyo Night": legiveis em fundo escuro e claro).
var (
	cAccent = rgb{122, 162, 247}
	cPurple = rgb{187, 154, 247}
	cCyan   = rgb{125, 207, 255}
	cGreen  = rgb{158, 206, 106}
	cYellow = rgb{224, 175, 104}
	cRed    = rgb{247, 118, 142}
	cOrange = rgb{255, 158, 100}
	cText   = rgb{205, 214, 244}
	cDim    = rgb{130, 138, 175}
	cFaint  = rgb{78, 86, 120}
	cBubble = rgb{36, 40, 59}
	cCode   = rgb{26, 29, 43}
)

var shimmer = []rgb{
	{187, 154, 247}, {170, 160, 250}, {150, 168, 250}, {122, 162, 247}, {125, 190, 255},
	{125, 207, 255}, {125, 190, 255}, {122, 162, 247}, {150, 168, 250}, {170, 160, 250},
}

// on indica se o console aceita cores/ANSI. Se nao aceitar (saida
// redirecionada, Windows muito antigo), tudo sai em texto simples.
var on bool

func fg(c rgb) string {
	if !on {
		return ""
	}
	return fmt.Sprintf("\x1b[38;2;%d;%d;%dm", c.r, c.g, c.b)
}

func bg(c rgb) string {
	if !on {
		return ""
	}
	return fmt.Sprintf("\x1b[48;2;%d;%d;%dm", c.r, c.g, c.b)
}

func reset() string {
	if !on {
		return ""
	}
	return "\x1b[0m"
}

func paint(c rgb, s string) string {
	if !on {
		return s
	}
	return fg(c) + s + "\x1b[0m"
}

func styledBold(c rgb, s string) string {
	if !on {
		return s
	}
	return "\x1b[1m" + fg(c) + s + "\x1b[0m"
}

// Init liga o modo colorido do console, define o titulo da janela e limpa a tela.
func Init() {
	on = terminal.EnableVT()
	if on {
		fmt.Print("\x1b]0;ASDNA Agente de IA · Horde\x07\x1b[2J\x1b[H")
	}
}

func termWidth() int {
	w := terminal.Width()
	if w <= 0 {
		w = 100
	}
	return w
}

// boxWidth: largura total das caixas (bordas incluidas).
func boxWidth() int {
	w := termWidth() - 4
	if w > 100 {
		w = 100
	}
	if w < 50 {
		w = 50
	}
	return w
}

type seg struct {
	t string
	c rgb
	b bool
}

func styledSeg(s seg) string {
	if s.b {
		return styledBold(s.c, s.t)
	}
	return paint(s.c, s.t)
}

func boxRow(inner int, ss ...seg) string {
	var sb strings.Builder
	w := 0
	for _, s := range ss {
		sb.WriteString(styledSeg(s))
		w += strWidth(s.t)
	}
	pad := inner - w
	if pad < 0 {
		pad = 0
	}
	return "  " + paint(cFaint, "│") + sb.String() + strings.Repeat(" ", pad) + paint(cFaint, "│")
}

// ---------------------------------------------------------------------------
// Cabecalho
// ---------------------------------------------------------------------------

type BannerData struct {
	Model     string
	Anonymous bool
	Tokens    int
}

func Banner(d BannerData) {
	inner := boxWidth() - 2
	model := d.Model
	if model == "" {
		model = "nenhum (use /atualizar)"
	}
	model = truncate(model, inner-14)
	key := seg{"pessoal", cGreen, false}
	if d.Anonymous {
		key = seg{"anônima (pública)", cYellow, false}
	}
	fmt.Println()
	fmt.Println("  " + paint(cFaint, "╭"+strings.Repeat("─", inner)+"╮"))
	fmt.Println(boxRow(inner, seg{"  ●  ", cPurple, true}, seg{"ASDNA Agente de IA", cText, true}, seg{"   Horde v9.1", cDim, false}))
	fmt.Println(boxRow(inner, seg{"     Agente conversacional e automacao no Windows", cDim, false}))
	fmt.Println(boxRow(inner))
	fmt.Println(boxRow(inner, seg{"  modelo  ", cDim, false}, seg{model, cCyan, false}))
	fmt.Println(boxRow(inner, seg{"  chave   ", cDim, false}, key, seg{"     tokens  ", cDim, false}, seg{fmt.Sprint(d.Tokens), cText, false}))
	fmt.Println(boxRow(inner))
	fmt.Println(boxRow(inner, seg{"  ", cDim, false}, seg{"/ajuda", cAccent, false}, seg{"  ·  ", cFaint, false},
		seg{"/modelos", cAccent, false}, seg{"  ·  ", cFaint, false}, seg{"/colar", cAccent, false},
		seg{"  ·  ", cFaint, false}, seg{"/sair", cAccent, false}))
	fmt.Println("  " + paint(cFaint, "╰"+strings.Repeat("─", inner)+"╯"))
	fmt.Println("  " + paint(cFaint, "Requer internet. Nenhuma resposta é garantida pela Horde."))
}

// ---------------------------------------------------------------------------
// Mensagens de status
// ---------------------------------------------------------------------------

func status(icon string, ic, tc rgb, msg string) {
	for i, l := range wrapPlain(msg, boxWidth()-4) {
		if i == 0 {
			fmt.Println("  " + paint(ic, icon) + " " + paint(tc, l))
		} else {
			fmt.Println("    " + paint(tc, l))
		}
	}
}

func Info(msg string)                  { status("•", cAccent, cText, msg) }
func Infof(f string, a ...interface{}) { Info(fmt.Sprintf(f, a...)) }
func OK(msg string)                    { status("●", cGreen, cText, msg) }
func OKf(f string, a ...interface{})   { OK(fmt.Sprintf(f, a...)) }
func Warn(msg string)                  { status("▲", cYellow, cYellow, msg) }
func Warnf(f string, a ...interface{}) { Warn(fmt.Sprintf(f, a...)) }
func Err(msg string)                   { status("×", cRed, cRed, msg) }
func Errf(f string, a ...interface{})  { Err(fmt.Sprintf(f, a...)) }
func Hint(msg string)                  { status(" ", cDim, cDim, msg) }

func Title(s string) {
	fmt.Println()
	fmt.Println("  " + styledBold(cText, s))
}

// ---------------------------------------------------------------------------
// Caixa de entrada
// ---------------------------------------------------------------------------

// InputBox desenha a caixa de mensagem e deixa o cursor dentro dela.
// Em seguida o programa le a linha normalmente (stdin).
func InputBox() {
	if !on {
		fmt.Print("\n  VOCE  >  ")
		return
	}
	inner := boxWidth() - 2
	hint := " Enter envia  ·  /ajuda  ·  /colar = várias linhas "
	hw := strWidth(hint)
	bottom := strings.Repeat("─", inner)
	if inner-2-hw >= 0 {
		bottom = "──" + hint + strings.Repeat("─", inner-2-hw)
	}
	fmt.Println()
	fmt.Println("  " + paint(cAccent, "╭"+strings.Repeat("─", inner)+"╮"))
	fmt.Println("  " + paint(cAccent, "│") + " " + styledBold(cPurple, "›") + strings.Repeat(" ", inner-2) + paint(cAccent, "│"))
	fmt.Print("  " + paint(cAccent, "╰") + paint(cFaint, bottom) + paint(cAccent, "╯"))
	// sobe uma linha e posiciona o cursor depois de "  │ › "
	fmt.Print("\r\x1b[1A\x1b[6C")
}

// EndInput limpa a caixa depois do Enter (quando a mensagem coube em uma linha).
func EndInput(text string, complete bool) {
	if !on {
		return
	}
	if !complete {
		fmt.Println()
		return
	}
	plain := strings.TrimRight(text, "\r\n")
	if strWidth(plain) <= boxWidth()-6 {
		fmt.Print("\x1b[2A\r\x1b[J")
	}
}

func KeyPrompt() {
	fmt.Print("  " + paint(cYellow, "●") + " " + paint(cText, "Cole sua chave AI Horde (entrada oculta) e pressione Enter: "))
}

func PasteStart() {
	Info("Cole texto/código; finalize escrevendo /fim sozinho em uma linha.")
}

func PastePrompt() {
	if !on {
		fmt.Print("  ... ")
		return
	}
	fmt.Print("  " + paint(cFaint, "┊ "))
}

// ---------------------------------------------------------------------------
// Mensagens do chat
// ---------------------------------------------------------------------------

// User mostra a mensagem enviada como um balao.
func User(text string) {
	w := boxWidth() - 4
	lines := wrapPlain(strings.TrimSpace(text), w)
	extra := 0
	if len(lines) > 14 {
		extra = len(lines) - 14
		lines = lines[:14]
	}
	fmt.Println()
	for i, ln := range lines {
		if !on {
			prefix := "  VOCE  >  "
			if i > 0 {
				prefix = "           "
			}
			fmt.Println(prefix + ln)
			continue
		}
		pad := w - strWidth(ln)
		if pad < 0 {
			pad = 0
		}
		fmt.Println("  " + paint(cAccent, "▌") + bg(cBubble) + fg(cText) + " " + ln + strings.Repeat(" ", pad) + " " + reset())
	}
	if extra > 0 {
		fmt.Println("    " + paint(cDim, fmt.Sprintf("… +%d linhas", extra)))
	}
}

// Assistant mostra a resposta da IA com markdown renderizado.
func Assistant(model, text string) {
	fmt.Println()
	if !on {
		fmt.Printf("  HORDE  >  %s\n", text)
		return
	}
	fmt.Println("  " + paint(cPurple, "●") + " " + styledBold(cText, "Horde") + "  " + paint(cDim, truncate(model, boxWidth()-14)))
	for _, l := range Markdown(text, boxWidth()-4) {
		fmt.Println("    " + l)
	}
}

// ---------------------------------------------------------------------------
// Spinner / Thinking
// ---------------------------------------------------------------------------

func elapsed(d time.Duration) string {
	s := int(d.Seconds())
	if s < 60 {
		return fmt.Sprintf("%ds", s)
	}
	return fmt.Sprintf("%dm%02ds", s/60, s%60)
}

// Spinner mostra uma animacao em uma linha ate a funcao devolvida ser chamada.
// slowHint aparece depois de 15 segundos (ex.: fila da Horde).
func Spinner(label, detail, slowHint string) func() {
	if !on {
		fmt.Printf("  %s... %s\n", label, detail)
		return func() {}
	}
	restore := terminal.HideInputEcho()
	fmt.Print("\x1b[?25l")
	done := make(chan struct{})
	fin := make(chan struct{})
	start := time.Now()
	go func() {
		defer close(fin)
		tick := time.NewTicker(90 * time.Millisecond)
		defer tick.Stop()
		rs := []rune(label)
		n := len(shimmer)
		for f := 0; ; f++ {
			var sb strings.Builder
			sb.WriteString("\r\x1b[2K  ")
			sb.WriteString(fg(shimmer[(f/2)%n]) + "●" + reset() + " ")
			for i, r := range rs {
				sb.WriteString(fg(shimmer[(i+f/2)%n]))
				sb.WriteRune(r)
			}
			sb.WriteString(reset())
			dots := (f / 4) % 4
			sb.WriteString(fg(cDim) + strings.Repeat(".", dots) + strings.Repeat(" ", 3-dots) + reset())
			sb.WriteString(fg(cFaint) + "  " + elapsed(time.Since(start)) + reset())
			room := termWidth() - 2 - 2 - len(rs) - 3 - 8 - 26
			d := detail
			if d != "" && room > 8 {
				sb.WriteString(fg(cDim) + "  ·  " + truncate(d, room) + reset())
			}
			if slowHint != "" && time.Since(start) > 15*time.Second {
				sb.WriteString(fg(cYellow) + "  ·  " + slowHint + reset())
			}
			fmt.Print(sb.String())
			select {
			case <-done:
				return
			case <-tick.C:
			}
		}
	}()
	var once sync.Once
	return func() {
		once.Do(func() {
			close(done)
			<-fin
			fmt.Print("\r\x1b[2K\x1b[?25h")
			restore()
		})
	}
}

// Thinking: indicador mostrado enquanto o modelo ainda nao respondeu.
func Thinking(model string) func() {
	fmt.Println()
	return Spinner("Thinking", model, "na fila da Horde")
}

// ---------------------------------------------------------------------------
// Listas e ajuda
// ---------------------------------------------------------------------------

func Help() {
	items := [][2]string{
		{"/ajuda", "Mostra os comandos"},
		{"/atualizar", "Consulta modelos do provedor ativo"},
		{"/modelos", "Consulta e lista os modelos do provedor conectado"},
		{"/models", "Consulta dinamicamente /models da API atual"},
		{"/modelo 1", "Seleciona modelo pelo número (ou pelo nome completo)"},
		{"/chave", "Define sua chave privada, protegida com DPAPI do Windows"},
		{"/anonimo", "Usa a chave pública 0000000000"},
		{"/tokens 2048", "Ajusta geracao (48 a 8192; sujeito ao provedor)"},
		{"/mcp", "Status dos servidores MCP locais e dependencias"},
		{"/mcp instalar todos", "Baixa e configura 3 MCPs gratuitos apos confirmacao"},
		{"/mcp ferramentas", "Lista capacidades de um servidor MCP pelo nome"},
		{"/plano", "Mostra a tarefa atual e evidencias"},
		{"/provedores", "Mostra todas as APIs prontas para configurar"},
		{"/provedor NOME", "Alterna Horde, BlockRun, llmfaucet, OpenAI, Gemini etc."},
		{"/api-url", "Configura endereco HTTPS ou local de outra API"},
		{"/api-chave", "Define chave do provedor ativo via DPAPI"},
		{"/api-chave limpar", "Desconecta apenas a chave do provedor atual"},
		{"/api-testar", "Testa acesso ao catalogo do provedor ativo"},
		{"/mcp auto on/off", "Baixa MCPs oficiais sob demanda quando necessarios"},
		{"/colar", "Insere texto/código em várias linhas; termine com /fim"},
		{"/historico", "Lista últimas mensagens locais"},
		{"/novo", "Começa outra conversa, arquivando a atual"},
		{"/pasta", "Mostra a pasta com histórico e configuração"},
		{"/agente on/off", "Habilita/desabilita agentes para todos os modelos"},
		{"/pc TEXTO", "Forca tarefa de agente (mesmo se modo automatico off)"},
		{"/salvar nome.py", "Salva o ultimo bloco de codigo no seu PC"},
		{"/zip", "Compacta o ultimo projeto em Downloads"},
		{"/zip PASTA", "Compacta a pasta escolhida"},
		{"/arquivos", "Mostra onde os arquivos gerados sao salvos"},
		{"/arquivos abrir", "Abre a pasta dos arquivos gerados no Explorador"},
		{"/sair", "Encerra o aplicativo"},
	}
	Title("Comandos")
	fmt.Println()
	for _, it := range items {
		fmt.Println("  " + paint(cAccent, fmt.Sprintf("%-14s", it[0])) + paint(cText, it[1]))
	}
	fmt.Println()
	Hint("A chave pública tem prioridade baixa. A AI Horde pode exigir Kudos e limitar solicitações maiores, inclusive durante alta demanda.")
}

func ModelList(ids []string, selected string) {
	fmt.Println()
	for i, id := range ids {
		num := fmt.Sprintf("%2d", i+1)
		if id == selected {
			fmt.Println("  " + paint(cGreen, "●") + " " + paint(cDim, num) + "  " + styledBold(cGreen, id))
		} else {
			fmt.Println("    " + paint(cDim, num) + "  " + paint(cText, id))
		}
	}
	fmt.Println()
	Hint("Use /modelo NUMERO para mudar. Modelos podem sair da fila a qualquer momento.")
}

func HistoryItem(t time.Time, role, content string) {
	who := paint(cAccent, "VOCÊ ")
	if role != "user" {
		who = paint(cPurple, "HORDE")
	}
	fmt.Println("  " + paint(cDim, t.Format("02/01 15:04")) + "  " + who + "  " + paint(cText, content))
}
