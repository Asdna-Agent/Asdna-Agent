package ui

import (
	"strings"
	"unicode"
)

const (
	clsPlain uint8 = iota
	clsKeyword
	clsString
	clsComment
	clsNumber
	clsFunc
)

var clsColor = [...]rgb{cText, cPurple, cGreen, cDim, cOrange, cAccent}

var keywords = func() map[string]bool {
	m := map[string]bool{}
	for _, w := range strings.Fields(`func function def class return if else elif for while switch case
		break continue import from package var let const type struct interface go defer select range map
		chan nil null true false True False None new try catch except finally throw throws raise with as
		in is not and or async await yield public private protected static void int string bool float
		double char long using namespace fn pub mut impl use mod enum match self this extends implements
		lambda del pass global default do goto fallthrough override abstract final readonly`) {
		m[w] = true
	}
	return m
}()

func setOf(words string) map[string]bool {
	m := map[string]bool{}
	for _, w := range strings.Fields(words) {
		m[w] = true
	}
	return m
}

var hashLangs = setOf("python py sh bash shell zsh yaml yml toml ruby rb powershell ps1 dockerfile r perl makefile ini conf env")
var dashLangs = setOf("sql lua haskell")
var plainLangs = setOf("text txt plaintext output log console markdown md")

func isIdent(r rune) bool { return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' }

// highlight devolve as runas da linha e uma classe de cor para cada uma.
// E um realce leve e generico (palavras-chave, textos, comentarios, numeros).
func highlight(line, lang string) ([]rune, []uint8) {
	rs := []rune(line)
	n := len(rs)
	cls := make([]uint8, n)
	if plainLangs[lang] {
		return rs, cls
	}
	hash := hashLangs[lang]
	dash := dashLangs[lang]
	for i := 0; i < n; {
		c := rs[i]
		switch {
		case (hash && c == '#') ||
			(dash && c == '-' && i+1 < n && rs[i+1] == '-') ||
			(!hash && !dash && c == '/' && i+1 < n && (rs[i+1] == '/' || rs[i+1] == '*')):
			for ; i < n; i++ {
				cls[i] = clsComment
			}

		case c == '"' || c == '\'' || c == '`':
			j := i + 1
			for j < n && rs[j] != c {
				if rs[j] == '\\' {
					j++
				}
				j++
			}
			if j >= n {
				j = n - 1
			}
			for k := i; k <= j; k++ {
				cls[k] = clsString
			}
			i = j + 1

		case unicode.IsDigit(c) && (i == 0 || !isIdent(rs[i-1])):
			j := i
			for j < n && (unicode.IsDigit(rs[j]) || rs[j] == '.' || rs[j] == '_' || rs[j] == 'x' ||
				(rs[j] >= 'a' && rs[j] <= 'f') || (rs[j] >= 'A' && rs[j] <= 'F')) {
				j++
			}
			for k := i; k < j; k++ {
				cls[k] = clsNumber
			}
			i = j

		case unicode.IsLetter(c) || c == '_':
			j := i
			for j < n && isIdent(rs[j]) {
				j++
			}
			k := clsPlain
			if keywords[string(rs[i:j])] {
				k = clsKeyword
			} else if j < n && rs[j] == '(' {
				k = clsFunc
			}
			for m := i; m < j; m++ {
				cls[m] = k
			}
			i = j

		default:
			i++
		}
	}
	return rs, cls
}
