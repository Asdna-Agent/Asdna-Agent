# ASDNA Horde Agentes v11 — Multi-API + MCP

**Aplicativo Windows 64 bits** (Go 1.23, console próprio). A v11 foi construída sobre os fontes da v10.2, preservando o histórico, tarefas, ferramentas nativas, servidor MCP e configuração da pasta `%APPDATA%\ASDNA_Code_Horde_v1`.

## Novidades

1. **AI Horde permanece como padrão**, com chave pública anônima `0000000000`. Quem instala pela primeira vez não precisa criar conta.
2. **Provedores opcionais**: `blockrun`, `llmfaucet`, `kilo`, `openai`, `gemini`, `openrouter`, `groq`, `deepseek`, `ollama` e `compativel` (OpenAI-compatible). Alternar provedores **não** envia chave armazenada de outro provedor.
3. **`/models` e `/modelos`** fazem uma consulta ao `/models` do provedor selecionado e listam os IDs retornados. No llmfaucet, o `/models` ainda pode não existir: apenas em casos documentados de HTTP 404/405/501, o aplicativo usa os seletores publicados `auto:coding`, `auto:smart`, `auto:fast`, `auto` (isso **não** comprova disponibilidade de backend).
4. **Proteção de credenciais**: perfis independentes, chaves cifradas via DPAPI do Windows, entrada oculta. Se o URL do provedor for alterado, a chave armazenada nesse perfil é desconectada para não vazar para outro host.
5. **Evita confundir modelos pagos com gratuitos**. A listagem do BlockRun está limitada a `billing_mode: free`, pois os modelos pagos usam x402 (não implementado). Kilo anônimo mostra apenas IDs gratuitos ou preços zerados; uso autenticado pode acessar modelos pagos conforme a conta.
6. **Agente mais robusto**: aceita respostas com tool calls nativas nas APIs compatíveis quando suportadas, reaproveitando o validador de ferramentas existente; fallback para JSON em texto nos modelos da Horde/llmfaucet/Ollama. Melhora orientação de descoberta do esquema, observação, execução, verificação e correção dos erros.
7. **MCP com download sob demanda ativado por padrão**: se faltar um dos servidores conhecidos `filesystem`, `playwright` ou `windows`, pode instalar automaticamente com o instalador integrado **depois de você autorizar a inicialização**. O instalador usa fontes oficiais e verifica integridade quando o fornecedor disponibiliza checksums. Não instala navegadores extras nem outras ferramentas arbitrárias por iniciativa própria. Você pode desativar: `/mcp auto off`.

## Como usar

### Sem chave, com a Horde (primeira execução)

```text
/models
/modelo 1
Olá, ASDNA!
```

### BlockRun (grátis, sem chave)

```text
/provedor blockrun
/models
/modelo 1
```

### llmfaucet (experimental, sem chave)

```text
/provedor llmfaucet
/models
/modelo auto:coding
```

### OpenAI ou Gemini

```text
/provedor openai
/api-chave
/models
/modelo NOME_QUE_APARECEU_NA_LISTA
```

```text
/provedor gemini
/api-chave
/models
```

As APIs comerciais podem cobrar pelo uso. **Ter uma chave não significa conversa gratuita ou ilimitada.**

### Outra API compatível com OpenAI

```text
/api-url https://servidor.example/v1
/api-chave
/models
/modelo nome-do-modelo
```

`/api-url` na Horde muda para o perfil separado `compativel`, sem alterar o endereço oficial da Horde. URLs remotas precisam ser HTTPS; HTTP só é permitido para localhost. Também pode alternar para `/provedor compativel` depois de configurar o endereço.

### Alternar/revogar credenciais e baixar MCPs

```text
/provedores
/provedor horde
/anonimo
/mcp status
/mcp auto on
/mcp ferramentas filesystem
/mcp instalar todos
/api-chave limpar
```

**Importante:** `/api-chave` grava somente a credencial do provedor ativo. `/chave` é um atalho para o mesmo comando. `/api-chave limpar` remove a chave do provedor atual da configuração do aplicativo, sem revogar o token no site de origem.

## Limitações importantes

- **Não é compatível com todas as APIs do mundo.** Os conectores usam a convenção OpenAI-compatible (`GET /models` e `POST /chat/completions`). Serviços com protocolos diferentes ou autenticação especial precisam de adaptador próprio.
- **Não há treinamento de pesos de modelos** dentro deste EXE: o que foi aprimorado é o código do agente, as instruções, o planejamento e as interfaces de ferramentas. A qualidade ainda depende do modelo, das permissões e dos endpoints disponíveis.
- Nenhum provedor oferece gratuitamente todos os modelos sem limite. Respeite as cotas e preços que eles publicam. O uso de ferramentas pode enviar conteúdo de arquivos/janelas para o provedor conectado; autorizações continuam necessárias para operações sensíveis.
- O download de MCPs funciona no Windows, necessita de Internet, e só é acionado **quando um MCP conhecido precisa ser iniciado**, não na abertura do programa. Instalação pode ser demorada ou falhar por bloqueios do Windows/rede.
- Resultados com OpenAI, BlockRun, llmfaucet, Kilo, Windows MCP ou Playwright **não foram verificados ao vivo neste ambiente**. Há testes automatizados usando servidores HTTP simulados e compilação cruzada para Windows.

## Arquivos e compilação

O ZIP contém o código-fonte Go e a versão `.exe` Windows 64-bit. Não precisa instalar Go para executar o EXE. Se quiser recompilar, instale Go e execute `build.bat` ou:

```bat
set GOOS=windows
set GOARCH=amd64
go build -trimpath -o ASDNA_Horde_Agentes_v11_MultiAPI.exe ./cmd/asdna-horde
```

## Transparência

Base: ASDNA Horde v10.2 fornecida na biblioteca de arquivos do projeto. Atualização nesta sessão: suporte a múltiplos provedores e instruções de execução do agente. O código-fonte acompanha esta distribuição para auditoria e modificações.
