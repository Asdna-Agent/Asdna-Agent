package main

import "testing"

func TestSimpleOpenRequests(t *testing.T) {
	for _, tc := range []struct{ q, app, profile string }{{`abra "Counter-Strike"`, "Counter-Strike", ""}, {`abra "hl.exe"`, "hl.exe", ""}, {`pode abrir a "Steam"?`, "Steam", ""}, {"abre cs", "cs", ""}, {"abre chrome zelp", "chrome.exe", "zelp"}, {"abra o Chrome no perfil zelp", "chrome.exe", "zelp"}, {"abra chrome com o perfil Eduardo", "chrome.exe", "Eduardo"}, {"abre steam pra mim", "steam", ""}} {
		a, ok := simpleOpenAction(tc.q)
		if !ok || a.App != tc.app || a.Profile != tc.profile {
			t.Errorf("%s: %+v %v", tc.q, a, ok)
		}
	}
	for _, q := range []string{"como abrir steam?", "abra chrome e pesquise gatos", "abra cmd como administrador", "abra a pasta downloads", "abra chrome --new-window"} {
		if a, ok := simpleOpenAction(q); ok {
			t.Errorf("compound request consumed: %s %+v", q, a)
		}
	}
}

func TestDiscoveryIsNotAnOpening(t *testing.T) {
	for _, q := range []string{"liste apps", "encontre steam", "quais perfis existem?"} {
		if needsActionAfterDiscovery(q) {
			t.Fatal(q)
		}
	}
	for _, q := range []string{"abra chrome e pesquise gatos", "pode abrir steam?"} {
		if !needsActionAfterDiscovery(q) {
			t.Fatal(q)
		}
	}
}
