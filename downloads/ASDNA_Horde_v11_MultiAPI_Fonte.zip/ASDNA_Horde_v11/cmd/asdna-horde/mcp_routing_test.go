package main

import (
	"encoding/json"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/pcactions"
)

func TestMCPServerPriorities(t *testing.T) {
	cases := []struct{ request, server string }{
		{`Abra https://demo.playwright.dev/todomvc, adicione duas tarefas e confirme`, "playwright"},
		{`Abra o Bloco de Notas. Utilize especificamente o Windows MCP para localizar a janela, digitar e verificar`, "windows"},
		{`Use Filesystem MCP para criar uma pasta`, "filesystem"},
		{`Abra o Google Chrome no perfil zelp`, ""},
	}
	for _, tt := range cases {
		if got := preferredMCP(tt.request); got != tt.server {
			t.Errorf("%q: wanted %q, got %q", tt.request, tt.server, got)
		}
	}
}
func TestMCPBrowserUsesDOMInsteadOfDesktop(t *testing.T) {
	request := `Abra https://demo.playwright.dev/todomvc e adicione tarefas`
	action, converted := correctMCPBrowserAction(request, pcactions.Action{Tool: "open_url", URL: "https://demo.playwright.dev/todomvc"})
	if !converted || action.Tool != "mcp_call" || action.Server != "playwright" || action.Name != "browser_navigate" {
		t.Fatalf("unexpected action: %#v", action)
	}
	var args map[string]string
	if err := json.Unmarshal(action.Arguments, &args); err != nil || args["url"] != "https://demo.playwright.dev/todomvc" {
		t.Fatalf("wrong args %#v: %v", args, err)
	}
	if !wrongMCPBrowserTool(request, pcactions.Action{Tool: "desktop_control", Operation: "type"}) {
		t.Fatal("desktop_control must be rejected for DOM work")
	}
}
func TestExactSchemaIncludedWithoutTruncatingRequiredFields(t *testing.T) {
	tools := []mcp.Tool{
		{Name: "browser_navigate", InputSchema: json.RawMessage(`{"type":"object","required":["url"],"properties":{"url":{"type":"string","description":"URL"}}}`)},
		{Name: "browser_type", InputSchema: json.RawMessage(`{"type":"object","required":["element","text"],"properties":{"element":{"type":"string"},"text":{"type":"string"}}}`)},
	}
	result := chosenToolSchemas("playwright", tools, 3000)
	if !strings.Contains(result, `"required":["url"]`) || !strings.Contains(result, "browser_type") {
		t.Fatal(result)
	}
}
func TestFolderInCompoundFileRequest(t *testing.T) {
	input := `Crie a pasta Documents/ASDNA_Teste_MCP e um arquivo teste.txt contendo tres linhas`
	path := fileForCreation(input)
	if path != "Documents/ASDNA_Teste_MCP/teste.txt" {
		t.Fatalf("file sent to wrong directory: %s", path)
	}
}
func TestMultiStepWindowsMCPIsNotSingleOpen(t *testing.T) {
	input := `Abra o Bloco de Notas. Utilize especificamente o Windows MCP para localizar a janela, digitar um texto e verificar`
	_, ok := simpleOpenAction(input)
	if ok {
		t.Fatal("compound request must reach the orchestrator")
	}
}
