//go:build windows

package main

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

func goSetupSupported() bool { return true }

func goInstallationStatus() (bool, string) {
	candidates := []string{}
	if exe, err := exec.LookPath("go.exe"); err == nil {
		candidates = append(candidates, exe)
	}
	if programFiles := os.Getenv("ProgramFiles"); programFiles != "" {
		candidates = append(candidates, filepath.Join(programFiles, "Go", "bin", "go.exe"))
	}
	if programFiles := os.Getenv("ProgramW6432"); programFiles != "" {
		candidates = append(candidates, filepath.Join(programFiles, "Go", "bin", "go.exe"))
	}
	for _, binary := range candidates {
		ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		output, err := exec.CommandContext(ctx, binary, "version").CombinedOutput()
		cancel()
		if err == nil && strings.HasPrefix(strings.TrimSpace(string(output)), "go version go") {
			return true, strings.TrimSpace(string(output))
		}
	}
	return false, ""
}

func installGoToolchain() (string, error) {
	exe, err := exec.LookPath("winget.exe")
	if err != nil {
		return "", fmt.Errorf("WinGet nao esta disponivel; instale App Installer ou obtenha Go em https://go.dev/dl")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, exe, goWingetArguments()...)
	// WinGet itself must be the direct child. Never interpret shell text from
	// the model or invoke PowerShell for the first-run install.
	out, runErr := cmd.CombinedOutput()
	if ctx.Err() != nil {
		return string(out), fmt.Errorf("instalacao interrompida: %w", ctx.Err())
	}
	if runErr != nil {
		return string(out), fmt.Errorf("WinGet retornou erro: %w", runErr)
	}
	return string(out), nil
}
