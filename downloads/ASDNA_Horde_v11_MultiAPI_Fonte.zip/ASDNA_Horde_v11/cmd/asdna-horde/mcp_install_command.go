package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/ui"
)

func (a *App) mcpInstallCommand(parts []string) {
	if len(parts) < 3 {
		ui.Warn("Uso: /mcp instalar todos | /mcp instalar windows | /mcp instalar playwright | /mcp instalar filesystem")
		return
	}
	which := strings.ToLower(parts[2])
	var names []string
	switch which {
	case "todos", "all":
		names = []string{"windows", "filesystem", "playwright"}
	case "windows", "filesystem", "playwright":
		names = []string{which}
	default:
		ui.Warn("Servidor desconhecido. Use todos, windows, filesystem ou playwright.")
		return
	}
	home, e := os.UserHomeDir()
	if e != nil {
		ui.Warnf("Instalacao: %v", e)
		return
	}
	configDir, e := storage.Dir()
	if e != nil {
		ui.Warnf("Instalacao: %v", e)
		return
	}
	root := filepath.Join(configDir, "mcp-runtime")
	// Command is an explicit opt-in to download, but still display source/size and
	// request one unambiguous approval before downloading executable programs.
	notice := fmt.Sprintf("Baixar e instalar os MCPs gratuitos [%s] em %s?\nFontes: GitHub sbroenne/mcp-windows, nodejs.org, registro oficial npm.\nSe precisar, inclui Node 24 portatil. Playwright usara o Chrome instalado; nao instala navegador extra.\nNao precisa de administrador. Faz downloads de executaveis de terceiros e concede ferramentas para controlar o PC.", strings.Join(names, ", "), root)
	if !a.confirmPC(notice) {
		ui.Info("Instalacao MCP cancelada.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	inst := mcp.Installer{Root: root, ConfigPath: a.mcpConfigPath, Home: home, Workspace: filepath.Join(home, "Downloads", "ASDNA_Horde"), Progress: func(msg string) { ui.Info(msg) }}
	done, err := inst.Install(ctx, names)
	// Always reload settings after partial installation, without restarting app.
	if len(done) > 0 {
		updated, e := mcp.Load(a.mcpConfigPath, mcp.DefaultRegistry(home, filepath.Join(home, "Downloads", "ASDNA_Horde")))
		if e != nil {
			ui.Warnf("Instalado, mas nao foi possivel recarregar configuracoes: %v", e)
		} else {
			if a.mcp != nil {
				a.mcp.Close()
			}
			a.mcp = mcp.New(updated)
			a.mcpApproved = map[string]bool{}
			ui.OKf("MCP(s) instalado(s): %s", strings.Join(done, ", "))
		}
	}
	if err != nil {
		ui.Warnf("Uma ou mais instalacoes falharam: %v", err)
	}
	ui.Info("Consulte /mcp status e /mcp ferramentas windows|filesystem|playwright para testar.")
}
