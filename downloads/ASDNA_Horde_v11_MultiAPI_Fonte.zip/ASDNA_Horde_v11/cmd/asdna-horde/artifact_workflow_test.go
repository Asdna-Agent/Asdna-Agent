package main

import (
	"archive/zip"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
)

func TestCreationDetectsExplicitPathAndKnownDestination(t *testing.T) {
	cases := []struct{ request, expected string }{
		{`crie um index.html em "Documents/WikiAleatoria/index.html" de uma wiki sobre "agentes de ia" com textos de no minimo 3 linhas, e no minimo um botão`, "Documents/WikiAleatoria/index.html"},
		{`crie index.html na Área de Trabalho`, "Desktop/index.html"},
		{`crie index.html em "Documents/Wiki Aleatoria"`, "Documents/Wiki Aleatoria/index.html"},
		{`crie a.py na pasta Downloads`, "Downloads/a.py"},
		{`crie um arquivo C:\Users\Teste\MeuSite\index.html`, `C:\Users\Teste\MeuSite\index.html`},
		{`crie projeto/main.py e compacte para projeto.zip`, "projeto/main.py"},
	}
	for _, tc := range cases {
		if got := fileForCreation(tc.request); got != tc.expected {
			t.Errorf("for %q: got %q want %q", tc.request, got, tc.expected)
		}
	}
	for _, request := range []string{`crie um index.html na pasta ProjetosDoJogo`, `explique como criar um index.html`, `bom dia`} {
		if got := fileForCreation(request); got != "" {
			t.Errorf("unsafe or false creation for %q: %s", request, got)
		}
	}
}

func TestHTMLGenerationCreationAndZipWithFakeModel(t *testing.T) {
	// No actual Horde network needed: the fake model writes source content and
	// the real PC executor saves the file in the test user's Documents folder.
	userHome := t.TempDir()
	t.Setenv("HOME", userHome)
	t.Setenv("USERPROFILE", userHome)
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	html := `<!DOCTYPE html><html lang="pt-BR"><head><title>Agentes de IA</title></head><body><h1>Agentes de IA</h1><p>Agentes de inteligência artificial recebem objetivos e utilizam ferramentas para realizar tarefas.</p><p>Eles trabalham com diferentes etapas, observando os resultados antes de continuar a atividade.</p><p>Um bom agente considera o contexto e verifica o resultado da tarefa antes de concluí-la.</p><button>Saiba mais</button></body></html>`
	mock := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": html}}}})
	}))
	defer mock.Close()
	api := horde.New(horde.AnonymousKey)
	api.Endpoint = mock.URL
	a := &App{api: api, pc: &pcactions.Agent{Base: filepath.Join(userHome, "Downloads", "ASDNA_Horde"), Confirm: func(string) bool { return true }}, config: storage.Config{SelectedModel: "fake", MaxTokens: 160}}
	request := `crie um index.html em "Documents/WikiAleatoria/index.html" de uma wiki sobre "agentes de ia" com textos de no minimo 3 linhas, e no minimo um botão e compacte o arquivo em "Documents/WikiAleatoria/site.zip"`
	if !a.tryArtifactWorkflow(request) {
		t.Fatal("requested creation must be executed")
	}
	result := filepath.Join(userHome, "Documents", "WikiAleatoria", "index.html")
	data, err := os.ReadFile(result)
	if err != nil || !strings.Contains(string(data), "<button") {
		t.Fatalf("HTML not saved to Documents: %v %q", err, data)
	}
	z, err := zip.OpenReader(filepath.Join(userHome, "Documents", "WikiAleatoria", "site.zip"))
	if err != nil {
		t.Fatal("ZIP missing:", err)
	}
	defer z.Close()
	if len(z.File) != 1 || z.File[0].Name != "index.html" {
		t.Fatalf("unexpected ZIP: %+v", z.File)
	}
}
