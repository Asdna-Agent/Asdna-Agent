package main

import (
	"asdna-horde-reconstructed/internal/pcactions"
	"regexp"
	"strings"
)

var browserProfileQuoted = regexp.MustCompile(`["“]([^"”]+)["”]`)
var browserSearchQuoted = regexp.MustCompile(`(?i)(?:pesquis\w*|busqu\w*|procur\w*)\s+(?:por\s+)?["“]([^"”]+)["”]`)

// Complements an incomplete open_app Chrome action only when the original user
// request explicitly specifies a browser search and/or profile. Never guesses
// a different profile or a search term from unrelated conversation history.
func completeBrowserAction(request string, action pcactions.Action) (pcactions.Action, bool) {
	if (action.Tool != "open_app" && action.Tool != "run_process") || !strings.Contains(strings.ToLower(action.App), "chrome") {
		return action, false
	}
	norm := pcactions.NormalizeIntent(request)
	if !strings.Contains(norm, "chrome") && !strings.Contains(norm, "navegador") {
		return action, false
	}
	if !strings.Contains(norm, "pesquis") && !strings.Contains(norm, "busqu") && !strings.Contains(norm, "procur") {
		return action, false
	}
	match := browserSearchQuoted.FindStringSubmatch(request)
	if len(match) < 2 {
		return action, false
	}
	result := pcactions.Action{Tool: "browser_search", Query: strings.TrimSpace(match[1])}
	for _, q := range browserProfileQuoted.FindAllStringSubmatch(request, -1) {
		if len(q) >= 2 && strings.Contains(strings.ToLower(q[1]), "chrome") {
			result.Profile = strings.TrimSpace(q[1])
			break
		}
	}
	return result, true
}

func needsMoreDesktopWork(request string, lastTool string) bool {
	if lastTool != "open_app" && lastTool != "run_process" {
		return false
	}
	r := pcactions.NormalizeIntent(request)
	for _, verb := range []string{"pesquise", "pesquisar", "busque", "procure", "digite", "escreva", "clique", "selecione", "pressione", "aperte"} {
		if strings.Contains(r, verb) {
			return true
		}
	}
	return false
}
