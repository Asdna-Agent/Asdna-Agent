package main

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
)

func TestAgentUsesSameProtocolFor32ModelSelections(t *testing.T) {
	os.Setenv("XDG_CONFIG_HOME", t.TempDir())
	base := t.TempDir()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var payload struct {
			Model    string          `json:"model"`
			Messages []horde.Message `json:"messages"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			t.Errorf("decode: %v", err)
			return
		}
		var id int
		_, _ = fmt.Sscanf(payload.Model, "modelo-teste-%d", &id)
		last := payload.Messages[len(payload.Messages)-1].Content
		reply := "Tarefa concluida; arquivo e ZIP gravados."
		if !strings.Contains(last, "RESULTADO_FERRAMENTA") {
			reply = fmt.Sprintf(`{"tool":"write_file","path":"projeto_%d/main.py","content":"print('teste')\\n"}`, id)
		} else if strings.Contains(last, "Arquivo salvo em") {
			reply = fmt.Sprintf(`{"tool":"zip_dir","path":"projeto_%d","destination":"projeto_%d.zip"}`, id, id)
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": reply}}}})
	}))
	defer server.Close()
	api := horde.New(horde.AnonymousKey)
	api.Endpoint = server.URL
	a := &App{api: api, pc: &pcactions.Agent{Base: base, Confirm: func(string) bool { return true }}, agentMode: true}
	for n := 0; n < 32; n++ {
		a.config = storage.Config{SelectedModel: fmt.Sprintf("modelo-teste-%d", n), MaxTokens: 160}
		a.agent(fmt.Sprintf("crie projeto_%d/main.py e compacte para projeto_%d.zip", n, n))
		r, err := zip.OpenReader(filepath.Join(base, fmt.Sprintf("projeto_%d.zip", n)))
		if err != nil {
			t.Fatalf("model %d: ZIP not generated: %v", n, err)
		}
		found := false
		for _, f := range r.File {
			if f.Name == fmt.Sprintf("projeto_%d/main.py", n) {
				found = true
			}
		}
		if !found {
			t.Errorf("model %d wrong zip contents", n)
		}
		r.Close()
	}
}
