package main

import (
	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/planner"
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/terminal"
	"asdna-horde-reconstructed/internal/ui"
)

type App struct {
	reader             *bufio.Reader
	api                *horde.Client
	config             storage.Config
	history            storage.History
	models             []horde.Model
	pc                 *pcactions.Agent
	lastProject        string
	agentMode          bool
	recentApp          string
	recentPath         string
	recentTool         string
	recentResult       string
	recentRequest      string
	mcp                *mcp.Manager
	mcpConfigPath      string
	task               *planner.Task
	mcpApproved        map[string]bool
	autoInstallAttempt map[string]bool
}

func main() {
	ui.Init()
	a := &App{reader: bufio.NewReaderSize(os.Stdin, 256*1024), agentMode: true}
	if err := a.init(); err != nil {
		ui.Errf("Falha na inicialização: %v", err)
		os.Exit(1)
	}
	defer func() {
		if a.mcp != nil {
			a.mcp.Close()
		}
	}()
	a.run()
}
func (a *App) init() error {
	var err error
	a.config, err = storage.LoadConfig()
	if err != nil {
		return fmt.Errorf("config: %w", err)
	}
	a.history, err = storage.LoadHistory()
	if err != nil {
		return fmt.Errorf("historico: %w", err)
	}
	a.api, err = clientForConfig(a.config)
	if err != nil {
		ui.Warnf("Configuracao de provedor anterior nao utilizavel: %v. Retornando a Horde anonima.", err)
		a.config.Provider = "horde"
		a.config.SelectedModel = ""
		a.api = horde.New(horde.AnonymousKey)
		if err := storage.SaveConfig(a.config); err != nil {
			return err
		}
	}
	configDir, e := storage.Dir()
	if e != nil {
		return e
	}
	a.mcpConfigPath = filepath.Join(configDir, "mcp-servers.json")
	home, e := os.UserHomeDir()
	if e != nil {
		return e
	}
	mcpWorkspace := filepath.Join(home, "Downloads", "ASDNA_Horde")
	if e := os.MkdirAll(mcpWorkspace, 0755); e != nil {
		ui.Warnf("Pasta MCP: %v", e)
	}
	defaults := mcp.DefaultRegistry(home, mcpWorkspace)
	mc, e := mcp.Load(a.mcpConfigPath, defaults)
	if e != nil {
		ui.Warnf("MCP: %v", e)
	} else {
		a.mcp = mcp.New(mc)
	}
	a.pc, err = pcactions.New(a.confirmPC)
	if err != nil {
		return fmt.Errorf("assistente local: %w", err)
	}
	// Agent-first mode: ordinary operations inside ASDNA's workspace and
	// read-only discovery do not stop for confirmation. Elevated commands,
	// PowerShell, downloads, external writes and desktop input still require it.
	a.pc.ConfirmEachAction = false
	// No numbered application/profile chooser: ambiguity is returned to the
	// planner so the AI can resolve it from context.
	return nil
}
func (a *App) run() {
	ui.Banner(ui.BannerData{
		Model:     a.config.SelectedModel,
		Anonymous: a.api.Provider == "horde" && a.api.Key == horde.AnonymousKey,
		Tokens:    a.config.MaxTokens,
	})
	if a.api.Provider == "horde" && a.api.Key == horde.AnonymousKey {
		ui.Hint("Modo anônimo ativo (chave pública). Use /chave para chave própria.")
	}
	// Go is optional for users of the prebuilt EXE; never prompt to install it on startup.
	a.refresh()
	for {
		ui.InputBox()
		s, err := a.readLine()
		ui.EndInput(s, err == nil)
		if errors.Is(err, io.EOF) {
			ui.Info("Encerrando.")
			return
		}
		if err != nil {
			ui.Errf("Erro de leitura: %v", err)
			return
		}
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		if strings.HasPrefix(s, "/") {
			if !a.command(s) {
				return
			}
			continue
		}
		a.send(s)
	}
}
func (a *App) readLine() (string, error) { return a.reader.ReadString('\n') }
func (a *App) command(input string) bool {
	parts := strings.Fields(input)
	switch strings.ToLower(parts[0]) {
	case "/sair", "/exit", "/quit":
		return false
	case "/abrir", "/apps", "/perfis", "/janelas":
		tool := map[string]string{"/abrir": "open_app", "/apps": "find_app", "/perfis": "list_profiles", "/janelas": "list_windows"}[strings.ToLower(parts[0])]
		query := strings.TrimSpace(input[len(parts[0]):])
		if tool == "open_app" && query == "" {
			ui.Hint("Uso: /abrir steam ou /abrir chrome zelp")
			return true
		}
		action := pcactions.Action{Tool: tool, Query: query, App: query}
		if tool == "open_app" {
			if parsed, ok := simpleOpenAction("abra " + query); ok {
				action = parsed
			}
		}
		a.executeLocalAction(input, action)
	case "/ajuda", "/help":
		ui.Help()
		ui.Hint("/abrir NOME, /apps TEXTO, /perfis TEXTO, /janelas — busca local por nomes e abreviacoes.")
	case "/mcp":
		a.mcpCommand(parts)
	case "/plano":
		a.showTask()
	case "/provedor":
		a.providerCommand(parts)
	case "/provedores":
		a.providersList()
	case "/models":
		a.refresh()
		a.listModels()
	case "/api-url":
		a.endpointCommand(strings.TrimSpace(input[len(parts[0]):]))
	case "/api-chave":
		a.providerKeyCommand(len(parts) > 1 && (strings.EqualFold(parts[1], "limpar") || strings.EqualFold(parts[1], "remover")))
	case "/api-testar":
		a.testProvider()
	case "/atualizar":
		a.refresh()
	case "/modelos":
		a.refresh()
		a.listModels()
	case "/modelo":
		if len(parts) < 2 {
			ui.Warn("Uso: /modelo NUMERO ou /modelo NOME")
			return true
		}
		a.choose(strings.Join(parts[1:], " "))
	case "/chave":
		a.providerKeyCommand(false)
	case "/anonimo":
		if err := a.anonymousHorde(); err != nil {
			ui.Warnf("%v", err)
		} else {
			ui.OK("Chave publica da Horde ativada.")
		}
	case "/novo":
		if err := storage.Archive(a.history); err != nil {
			ui.Errf("ERRO ao arquivar: %v", err)
			return true
		}
		a.history = storage.History{Items: []storage.Record{}}
		if err := storage.SaveHistory(a.history); err != nil {
			ui.Errf("ERRO: %v", err)
		} else {
			ui.OK("Nova conversa iniciada; histórico anterior arquivado.")
		}
	case "/historico":
		a.showHistory()
	case "/colar":
		a.paste()
	case "/tokens":
		if len(parts) < 2 {
			ui.Infof("Limite de resposta: %d tokens; uso /tokens 2048 (48-8192). Depende da capacidade do modelo.", a.config.MaxTokens)
			return true
		}
		n, err := strconv.Atoi(parts[1])
		if err != nil || n < 48 || n > 8192 {
			ui.Warn("Informe valor de 48 a 8192 (modelos podem limitar).")
			return true
		}
		a.config.MaxTokens = n
		if err := storage.SaveConfig(a.config); err != nil {
			ui.Errf("ERRO: %v", err)
		} else {
			ui.OKf("Limite de resposta definido em %d tokens.", n)
		}
	case "/pc":
		if len(parts) < 2 {
			ui.Hint("Uso: /pc crie um arquivo de texto chamado teste.txt com ...")
			return true
		}
		request := strings.TrimSpace(input[len(parts[0]):])
		a.agent(request)
	case "/agente":
		if len(parts) < 2 {
			if a.agentMode {
				ui.OK("Modo agente automatico: ATIVO, para todos os modelos.")
			} else {
				ui.Info("Modo agente automatico: DESLIGADO. Use /pc para acionar manualmente.")
			}
			return true
		}
		switch strings.ToLower(parts[1]) {
		case "on", "ligar", "ativar":
			a.agentMode = true
			ui.OK("Modo agente ATIVO para qualquer modelo selecionado.")
		case "off", "desligar", "desativar":
			a.agentMode = false
			ui.Info("Modo agente automatico desativado. /pc continua disponivel.")
		default:
			ui.Warn("Uso: /agente on ou /agente off")
		}
	case "/arquivos":
		if a.pc == nil {
			ui.Warn("Recursos locais nao disponiveis.")
			return true
		}
		path := a.pc.Base
		ui.Infof("Seus arquivos gerados ficam em: %s", path)
		if len(parts) > 1 && strings.EqualFold(parts[1], "abrir") {
			result, err := a.pc.Execute(pcactions.Action{Tool: "open_path", Path: "."})
			if err != nil {
				ui.Errf("ERRO: %v", err)
			} else {
				ui.OK(result)
			}
		}
	case "/zip":
		a.zipRequest(strings.TrimSpace(input[len(parts[0]):]))
	case "/salvar":
		a.saveLastCode(strings.TrimSpace(input[len(parts[0]):]))
	case "/go":
		a.showGoStatus()
	case "/instalar-go":
		a.requestGoInstallation()
	case "/pasta":
		p, err := storage.Dir()
		if err != nil {
			ui.Errf("ERRO: %v", err)
		} else {
			ui.Infof("Arquivos locais: %s", p)
		}
	case "/fim":
		ui.Warn("/fim só funciona dentro de /colar.")
	default:
		ui.Warn("Comando não reconhecido. Use /ajuda.")
	}
	return true
}
func (a *App) refresh() {
	stop := ui.Spinner("Consultando modelos", a.api.Provider, "")
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	ms, err := a.api.Models(ctx)
	stop()
	if err != nil {
		ui.Warnf("Nao foi possivel consultar modelos em %s: %v", a.api.Provider, err)
		return
	}
	if a.api.Provider == "llmfaucet" && len(ms) == 4 && ms[0].ID == "auto:coding" {
		ui.Hint("llmfaucet: os seletores auto sao documentados, mas o endpoint /models pode nao estar implementado.")
	}
	if len(ms) == 0 {
		ui.Warn("Nenhum modelo disponível agora.")
		return
	}
	a.models = ms
	preserved := false
	for _, m := range ms {
		if m.ID == a.config.SelectedModel {
			preserved = true
			break
		}
	}
	if !preserved {
		a.config.SelectedModel = ms[0].ID
		profile := a.config.Profile(configuredProvider(a.config))
		profile.Model = a.config.SelectedModel
		a.config.SetProfile(configuredProvider(a.config), profile)
		_ = storage.SaveConfig(a.config)
	}
	ui.OKf("%d modelos identificados. Selecionado: %s", len(ms), a.config.SelectedModel)
}
func (a *App) listModels() {
	if len(a.models) == 0 {
		ui.Warn("Sem modelos; execute /atualizar.")
		return
	}
	ids := make([]string, len(a.models))
	for i, m := range a.models {
		ids[i] = m.ID
	}
	ui.ModelList(ids, a.config.SelectedModel)
}
func (a *App) choose(choice string) {
	if len(a.models) == 0 && a.api.Provider == "horde" {
		ui.Warn("Primeiro execute /atualizar.")
		return
	}
	target := choice
	if n, err := strconv.Atoi(choice); err == nil {
		if n < 1 || n > len(a.models) {
			ui.Warn("Número fora da lista.")
			return
		}
		target = a.models[n-1].ID
	}
	ok := false
	for _, m := range a.models {
		if m.ID == target {
			ok = true
			break
		}
	}
	if !ok && a.api.Provider == "horde" {
		ui.Warn("Modelo não encontrado. Use /modelos.")
		return
	}
	a.config.SelectedModel = target
	prof := a.config.Profile(configuredProvider(a.config))
	prof.Model = target
	a.config.SetProfile(configuredProvider(a.config), prof)
	if err := storage.SaveConfig(a.config); err != nil {
		ui.Errf("ERRO: %v", err)
		return
	}
	ui.OKf("Modelo selecionado: %s", target)
}
func (a *App) changeKey() {
	ui.KeyPrompt()
	restore := terminal.HideInputEcho()
	s, err := a.readLine()
	restore()
	fmt.Println()
	if err != nil && !errors.Is(err, io.EOF) {
		ui.Errf("ERRO: %v", err)
		return
	}
	s = strings.TrimSpace(s)
	if s == "" {
		ui.Warn("Chave vazia; nenhuma alteração.")
		return
	}
	encrypted, err := storage.EncryptKey(s)
	if err != nil {
		ui.Errf("ERRO ao proteger chave: %v", err)
		return
	}
	a.config.EncryptedKey = encrypted
	if err := storage.SaveConfig(a.config); err != nil {
		ui.Errf("ERRO ao salvar: %v", err)
		return
	}
	a.api.Key = s
	ui.OK("Chave salva com proteção do Windows. Para validar, envie uma pergunta.")
}
func (a *App) paste() {
	ui.PasteStart()
	var lines []string
	for {
		ui.PastePrompt()
		s, err := a.readLine()
		if err != nil && len(s) == 0 {
			ui.Info("Entrada encerrada.")
			return
		}
		if strings.TrimSpace(s) == "/fim" {
			break
		}
		lines = append(lines, strings.TrimRight(s, "\r\n"))
		if len(lines) >= 500 {
			ui.Warn("Limite de 500 linhas por colagem.")
			break
		}
	}
	message := strings.TrimSpace(strings.Join(lines, "\n"))
	if message != "" {
		a.send(message)
	}
}
func (a *App) showHistory() {
	n := len(a.history.Items)
	if n == 0 {
		ui.Info("Nenhuma mensagem salva.")
		return
	}
	start := n - 12
	if start < 0 {
		start = 0
	}
	for _, item := range a.history.Items[start:] {
		content := strings.ReplaceAll(item.Content, "\n", " ")
		if len([]rune(content)) > 175 {
			content = string([]rune(content)[:175]) + "..."
		}
		ui.HistoryItem(item.Time, item.Role, content)
	}
}
func (a *App) send(text string) {
	// Conversational questions use the normal AI Horde chat context, NOT the
	// long tool protocol. Real PC tasks (including follow-ups) use the agent.
	if a.agentMode && a.likelyAgentAction(text) {
		a.agent(text)
		return
	}
	if a.config.SelectedModel == "" {
		ui.Warn("Sem modelo selecionado. Execute /atualizar e /modelos.")
		return
	}
	ui.User(text)
	a.history.Append("user", a.config.SelectedModel, text)
	if err := storage.SaveHistory(a.history); err != nil {
		ui.Warnf("Historico: %v", err)
	}
	messages := horde.CompactMessages(a.history.Messages(), a.config.MaxTokens)
	stop := ui.Thinking(a.config.SelectedModel)
	ctx, cancel := context.WithTimeout(context.Background(), 135*time.Second)
	defer cancel()
	reply, err := a.api.Chat(ctx, a.config.SelectedModel, messages, a.config.MaxTokens)
	stop()
	if err != nil {
		ui.Errf("ERRO: %v", err)
		return
	}
	ui.Assistant(a.config.SelectedModel, reply)
	a.history.Append("assistant", a.config.SelectedModel, reply)
	if err := storage.SaveHistory(a.history); err != nil {
		ui.Warnf("Historico: %v", err)
	}
}

// confirmPC exige autorizacao real do usuario. Respostas da IA nunca equivalem a consentimento.
func (a *App) confirmPC(message string) bool {
	ui.Warn(message)
	fmt.Print("  Para autorizar, digite SIM e pressione Enter: ")
	response, err := a.readLine()
	return err == nil && strings.EqualFold(strings.TrimSpace(response), "sim")
}

func (a *App) saveLastCode(name string) {
	var last string
	for i := len(a.history.Items) - 1; i >= 0; i-- {
		if a.history.Items[i].Role == "assistant" {
			last = a.history.Items[i].Content
			break
		}
	}
	if strings.TrimSpace(last) == "" {
		ui.Warn("Nenhuma resposta da IA para salvar.")
		return
	}
	code, ext, found := pcactions.ExtractCode(last)
	if !found {
		// Permite exportar a resposta textual inteira, inclusive codigo sem markdown.
		code = last
		ext = "txt"
		ui.Hint("Resposta sem bloco de codigo: salvando o texto inteiro.")
	}
	if name == "" {
		name = "codigo." + ext
	}
	result, err := a.pc.SaveCode(name, code)
	if err != nil {
		ui.Errf("Falha ao salvar: %v", err)
		return
	}
	ui.OK(result)
	ui.Hint("O arquivo ja esta no PC, na pasta Downloads/ASDNA_Horde. Use /arquivos abrir.")
}
