package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
)

func TestAgentModePreservesNaturalConversation(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	received := make(chan []horde.Message, 1)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var payload struct {
			Messages []horde.Message `json:"messages"`
		}
		if e := json.NewDecoder(r.Body).Decode(&payload); e != nil {
			t.Error(e)
		}
		received <- payload.Messages
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"message": map[string]string{"content": "Bom dia! Como posso ajudar?"}}}})
	}))
	defer server.Close()
	api := horde.New(horde.AnonymousKey)
	api.Endpoint = server.URL
	a := &App{api: api, pc: &pcactions.Agent{Base: t.TempDir()}, config: storage.Config{SelectedModel: "teste", MaxTokens: 160}, agentMode: true, recentApp: "Minecraft"}
	a.send("bom dia, tudo bem?")
	var msgs []horde.Message
	msgs = <-received
	if len(msgs) == 0 {
		t.Fatal("no chat messages")
	}
	for _, m := range msgs {
		if strings.Contains(m.Content, "FERRAMENTAS (campos JSON)") {
			t.Fatal("tool-only system leaked into conversation")
		}
	}
	if len(a.history.Items) == 0 || a.history.Items[len(a.history.Items)-1].Content != "Bom dia! Como posso ajudar?" {
		t.Fatalf("lost reply: %+v", a.history.Items)
	}
}
