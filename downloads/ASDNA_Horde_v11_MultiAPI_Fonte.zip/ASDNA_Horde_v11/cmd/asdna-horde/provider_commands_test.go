package main

import (
	"asdna-horde-reconstructed/internal/storage"
	"testing"
)

func TestDefaultProviderHordeAndIsolatedProfile(t *testing.T) {
	cfg := storage.Config{}
	if configuredProvider(cfg) != "horde" {
		t.Fatal("first launch must use Horde")
	}
	cfg.Provider = "horde"
	cfg.SelectedModel = "horde-one"
	cfg.SetProfile("horde", storage.ProviderProfile{Model: "horde-one"})
	cfg.SetProfile("openai", storage.ProviderProfile{Model: "gpt-test"})
	if cfg.Profile("horde").Model != "horde-one" || cfg.Profile("openai").Model != "gpt-test" {
		t.Fatal("profiles mixed")
	}
}
