package main

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/horde"
	"asdna-horde-reconstructed/internal/providers"
	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/terminal"
	"asdna-horde-reconstructed/internal/ui"
)

func configuredProvider(cfg storage.Config) string {
	p := strings.ToLower(strings.TrimSpace(cfg.Provider))
	if p == "" {
		return "horde"
	}
	if spec, ok := providers.Lookup(p); ok {
		return spec.Name
	}
	return p
}

func clientForConfig(cfg storage.Config) (*horde.Client, error) {
	name := configuredProvider(cfg)
	prof := cfg.Profile(name)
	spec, err := providers.Resolve(name, prof.Endpoint)
	if err != nil {
		return nil, err
	}
	key := ""
	if prof.KeyProtected != "" {
		key, err = storage.DecryptKey(prof.KeyProtected)
		if err != nil {
			return nil, fmt.Errorf("nao foi possivel recuperar a chave de %s: %w", name, err)
		}
	}
	if name == "horde" {
		return horde.New(key), nil
	}
	return horde.NewCompatible(name, spec.Endpoint, key)
}

func (a *App) providersList() {
	for _, p := range providers.List() {
		mark := ""
		if a.api.Provider == p.Name {
			mark = " [ATIVO]"
		}
		ui.Infof("%s%s: %s", p.Name, mark, p.Description)
	}
	ui.Hint("/provedor blockrun | llmfaucet | kilo | openai | ollama | compativel | horde")
	ui.Hint("Para API personalizada: /provedor compativel, /api-url https://host/v1 e /api-chave")
}

func (a *App) providerCommand(parts []string) {
	if len(parts) < 2 {
		ui.Infof("Provedor atual: %s | Endpoint: %s", a.api.Provider, a.api.Endpoint)
		a.providersList()
		return
	}
	spec, ok := providers.Lookup(parts[1])
	if !ok {
		ui.Warn("Provedor desconhecido. Use /provedores ou /provedor compativel.")
		return
	}
	next := a.config
	oldName := configuredProvider(next)
	oldProfile := next.Profile(oldName)
	oldProfile.Model = next.SelectedModel
	next.SetProfile(oldName, oldProfile)
	next.Provider = spec.Name
	targetProfile := next.Profile(spec.Name)
	next.SelectedModel = targetProfile.Model
	client, err := clientForConfig(next)
	if err != nil {
		if spec.Name == "compativel" {
			ui.Warn("Defina a URL primeiro com /api-url https://seu-servidor/v1 e depois /provedor compativel")
		} else {
			ui.Warnf("Nao foi possivel ativar: %v", err)
		}
		return
	}
	if err = storage.SaveConfig(next); err != nil {
		ui.Errf("Falha ao salvar configuracao: %v", err)
		return
	}
	a.config, a.api, a.models = next, client, nil
	ui.OKf("Provedor ativo: %s (%s)", spec.Name, client.Endpoint)
	if !spec.Anonymous && strings.TrimSpace(client.Key) == "" {
		ui.Hint("Esse provedor geralmente precisa de uma chave. Use /api-chave.")
	}
	a.refresh()
}

func (a *App) endpointCommand(value string) {
	name := configuredProvider(a.config)
	if name == "horde" {
		// /api-url is also a shortcut for configuring a new custom provider.
		// It must never change Horde's fixed endpoint or send its key elsewhere.
		name = "compativel"
	}
	if value == "" {
		ui.Infof("Endpoint configurado (%s): %s; uso: /api-url https://host/v1", name, a.config.Profile(name).Endpoint)
		return
	}
	candidate, err := horde.NewCompatible(name, value, "")
	if err != nil {
		ui.Warnf("URL recusada: %v", err)
		return
	}
	prof := a.config.Profile(name)
	oldEndpoint := ""
	if existing, err := providers.Resolve(name, prof.Endpoint); err == nil {
		oldEndpoint = existing.Endpoint
	}
	prof.Endpoint = candidate.Endpoint
	if oldEndpoint != candidate.Endpoint {
		prof.Model = ""
	}
	if oldEndpoint != candidate.Endpoint && prof.KeyProtected != "" {
		// Never silently send a credential to an unrelated custom endpoint.
		prof.KeyProtected = ""
		ui.Warn("URL alterada: chave anterior deste provedor foi desconectada por seguranca. Use /api-chave novamente.")
	}
	a.config.SetProfile(name, prof)
	if configuredProvider(a.config) != name {
		current := configuredProvider(a.config)
		previous := a.config.Profile(current)
		previous.Model = a.config.SelectedModel
		a.config.SetProfile(current, previous)
		a.config.Provider = name
		a.config.SelectedModel = prof.Model
	}
	if err := storage.SaveConfig(a.config); err != nil {
		ui.Errf("Falha ao salvar: %v", err)
		return
	}
	newClient, err := clientForConfig(a.config)
	if err != nil {
		ui.Warnf("Cliente nao atualizado: %v", err)
		return
	}
	a.api = newClient
	if oldEndpoint != candidate.Endpoint {
		a.models = nil
	}
	ui.OKf("Endpoint %s configurado: %s", name, candidate.Endpoint)
	a.refresh()
}

func (a *App) providerKeyCommand(clear bool) {
	name := configuredProvider(a.config)
	if clear {
		p := a.config.Profile(name)
		p.KeyProtected = ""
		a.config.SetProfile(name, p)
		if name == "horde" {
			a.config.EncryptedKey = ""
			a.api.Key = horde.AnonymousKey
		} else {
			a.api.Key = ""
		}
		if err := storage.SaveConfig(a.config); err != nil {
			ui.Errf("Erro: %v", err)
			return
		}
		ui.OKf("Chave de %s desconectada.", name)
		return
	}
	ui.Infof("Chave de API para %s. A entrada nao sera exibida. ENTER cancela.", name)
	restore := terminal.HideInputEcho()
	key, err := a.readLine()
	restore()
	fmt.Println()
	if err != nil || strings.TrimSpace(key) == "" {
		ui.Info("Operacao cancelada.")
		return
	}
	encrypted, err := storage.EncryptKey(strings.TrimSpace(key))
	if err != nil {
		ui.Errf("Protecao da chave: %v", err)
		return
	}
	profile := a.config.Profile(name)
	profile.KeyProtected = encrypted
	a.config.SetProfile(name, profile)
	if name == "horde" {
		a.config.EncryptedKey = encrypted
	}
	if err = storage.SaveConfig(a.config); err != nil {
		ui.Errf("Chave nao salva: %v", err)
		return
	}
	a.api.Key = strings.TrimSpace(key)
	ui.OKf("Chave de %s salva com protecao local. /models consulta o catalogo deste provedor.", name)
	a.refresh()
}

func (a *App) testProvider() {
	if a.api.Provider == "llmfaucet" {
		ui.Warn("O endpoint /models do llmfaucet pode nao estar implementado; /models oferece apenas seletores documentados. Valide a conversa enviando uma pergunta de teste.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	if _, err := a.api.Models(ctx); err != nil {
		ui.Warnf("Falha ao consultar %s: %v", a.api.Provider, err)
		return
	}
	ui.OKf("Conexao de catalogo com %s funcionando; disponibilidade de chat depende do modelo/conta.", a.api.Provider)
}

// Switching back to the Horde never sends custom provider credentials.
func (a *App) anonymousHorde() error {
	if a.api.Provider != "horde" {
		return errors.New("use /provedor horde antes de /anonimo")
	}
	a.config.EncryptedKey = ""
	p := a.config.Profile("horde")
	p.KeyProtected = ""
	a.config.SetProfile("horde", p)
	if err := storage.SaveConfig(a.config); err != nil {
		return err
	}
	a.api.Key = horde.AnonymousKey
	return nil
}
