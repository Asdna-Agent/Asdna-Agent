package main

import (
	"asdna-horde-reconstructed/internal/pcactions"
	"testing"
)

func TestCompletesUserBrowserRequest(t *testing.T) {
	req := `porfavor agente, abra "ZelpyrnDeveloper (Eduardo) - Chrome", e pesquise por "Youtube" na barra de pesquisas`
	action, ok := completeBrowserAction(req, pcactions.Action{Tool: "open_app", App: "chrome.exe"})
	if !ok || action.Tool != "browser_search" || action.Profile != "ZelpyrnDeveloper (Eduardo) - Chrome" || action.Query != "Youtube" {
		t.Fatalf("wrong corrected action: %+v %v", action, ok)
	}
	if !needsMoreDesktopWork(req, "open_app") {
		t.Fatal("stops before searching")
	}
	_, ok = completeBrowserAction(`abra o Chrome`, pcactions.Action{Tool: "open_app", App: "chrome.exe"})
	if ok {
		t.Fatal("invented search for simple launch")
	}
	if !needsMoreDesktopWork("abra o bloco de notas e digite 'bom dia'", "open_app") {
		t.Fatal("stops before typing")
	}
}
