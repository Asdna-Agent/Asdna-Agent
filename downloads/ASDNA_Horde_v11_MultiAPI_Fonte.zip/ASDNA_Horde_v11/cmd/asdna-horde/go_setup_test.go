package main

import (
	"bufio"
	"reflect"
	"strings"
	"testing"
)

func TestGoInstallerUsesPinnedPackageAndOfficialWingetSource(t *testing.T) {
	want := []string{"install", "--id", "GoLang.Go", "--exact", "--source", "winget", "--silent", "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity"}
	if actual := goWingetArguments(); !reflect.DeepEqual(actual, want) {
		t.Errorf("unexpected installation command arguments: %v", actual)
	}
}

func TestPermissionAcceptsCaseInsensitiveSim(t *testing.T) {
	for _, answer := range []string{"sim\n", "SIM\r\n", " Sim \n", "nAO\n", "\n"} {
		app := App{reader: bufio.NewReader(strings.NewReader(answer))}
		got := app.confirmPC("Pedido de teste")
		want := strings.EqualFold(strings.TrimSpace(answer), "sim")
		if got != want {
			t.Errorf("answer %q: approval %v, want %v", answer, got, want)
		}
	}
}

func TestSetupTrim(t *testing.T) {
	if actual := setupTrim("  abc  ", 4); actual != "abc" {
		t.Errorf("got %q", actual)
	}
	if actual := setupTrim("abcdefghijklmnop", 4); actual != "...mnop" {
		t.Errorf("got %q", actual)
	}
}
