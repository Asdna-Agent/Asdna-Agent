package main

import (
	"strings"
	"testing"

	"asdna-horde-reconstructed/internal/pcactions"
)

func TestAgentContextCarriesPreviousAppIntoFollowup(t *testing.T) {
	a := &App{}
	a.updateAgentContext("abra minecraft", pcactions.Action{Tool: "open_app", App: "Minecraft"}, "Abertura solicitada")
	if !a.likelyAgentAction("ache a pasta de mods e abra") {
		t.Fatal("follow-up should be treated as an agent action")
	}
	ctx := a.sessionContext()
	if !strings.Contains(strings.ToLower(ctx), "minecraft") {
		t.Fatal(ctx)
	}
}

func TestAgentModeStillAllowsConversation(t *testing.T) {
	a := &App{}
	if a.likelyAgentAction("bom dia, tudo bem?") {
		t.Fatal("ordinary chat should not be forced into a tool action")
	}
}

func TestWeakModelReopenIsCorrectedToPathSearch(t *testing.T) {
	a := &App{recentApp: "Minecraft"}
	got, changed := a.correctPathIntent("ache a pasta de mods e abra", pcactions.Action{Tool: "open_app", App: "Minecraft"})
	if !changed || got.Tool != "find_path" || got.Context != "Minecraft" || got.Kind != "folder" {
		t.Fatalf("unexpected correction: %#v changed=%v", got, changed)
	}
}
