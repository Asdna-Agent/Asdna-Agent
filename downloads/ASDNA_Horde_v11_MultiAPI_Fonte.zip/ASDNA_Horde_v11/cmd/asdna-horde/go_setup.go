package main

import (
	"fmt"
	"strings"

	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/ui"
)

// This Go toolchain setup does not change the language model, agent protocol,
// permissions, filesystem tools, or the current terminal interface.
// Compiled Go applications run without a separately installed Go toolchain.
func (a *App) firstRunGoSetup() {
	if !goSetupSupported() || a.config.GoSetupPrompted {
		return
	}
	installed, version := goInstallationStatus()
	if installed {
		ui.OKf("Go ja instalado: %s. Nenhuma instalacao necessaria.", version)
	} else {
		ui.Hint("O EXE esta pronto para usar, sem instalar Go. Para compilar projetos Go, use /instalar-go quando precisar.")
	}
	// Store the one-time decision even if the person skipped or the install
	// failed; they can explicitly retry with /instalar-go at any time.
	a.config.GoSetupPrompted = true
	if err := storage.SaveConfig(a.config); err != nil {
		ui.Warnf("Nao foi possivel registrar a configuracao inicial: %v", err)
	}
}

func (a *App) showGoStatus() {
	if !goSetupSupported() {
		ui.Hint("Configuracao automatica do Go disponivel somente no Windows.")
		return
	}
	installed, version := goInstallationStatus()
	if installed {
		ui.OKf("Go instalado: %s", version)
	} else {
		ui.Warn("Go nao localizado. Use /instalar-go se quiser instalar o compilador.")
	}
}

func (a *App) requestGoInstallation() {
	if !goSetupSupported() {
		ui.Warn("Instalacao automatica de Go disponivel apenas no Windows.")
		return
	}
	if installed, version := goInstallationStatus(); installed {
		ui.OKf("Go ja esta instalado: %s", version)
		return
	}
	if !a.confirmPC("O ASDNA solicita instalar o compilador oficial Go pelo Gerenciador de Pacotes do Windows (WinGet, pacote GoLang.Go).\nO download exige internet e o Windows pode pedir permissao de administrador.\nNenhum programa sera instalado sem sua autorizacao. Deseja continuar?") {
		ui.Info("Instalacao do Go dispensada; o chat e as ferramentas do agente continuam disponiveis.")
		return
	}
	ui.Info("Iniciando instalacao do Go pelo WinGet...")
	output, err := installGoToolchain()
	if err != nil {
		ui.Warnf("Nao foi possivel instalar Go automaticamente: %v", err)
		if strings.TrimSpace(output) != "" {
			ui.Hint("Detalhes: " + setupTrim(output, 900))
		}
		ui.Hint("Opcao manual oficial: https://go.dev/dl — ou tente /instalar-go novamente.")
		return
	}
	if installed, version := goInstallationStatus(); installed {
		ui.OKf("Go instalado com sucesso: %s", version)
		ui.Hint("Se um terminal antigo nao reconhecer go, abra uma nova janela.")
	} else {
		ui.Warn("O instalador terminou, mas Go nao foi encontrado nesta sessao.")
		ui.Hint("Abra um novo terminal e execute 'go version' para confirmar. O agente permanece funcionando.")
	}
}

func setupTrim(s string, size int) string {
	s = strings.TrimSpace(s)
	if len(s) > size {
		return fmt.Sprintf("...%s", s[len(s)-size:])
	}
	return s
}

// Fixed package identification: model-generated commands are not used for the
// first-run installation. Avoid --ignore-security-hash or source overrides.
func goWingetArguments() []string {
	return []string{
		"install", "--id", "GoLang.Go", "--exact", "--source", "winget",
		"--silent", "--accept-package-agreements", "--accept-source-agreements",
		"--disable-interactivity",
	}
}
