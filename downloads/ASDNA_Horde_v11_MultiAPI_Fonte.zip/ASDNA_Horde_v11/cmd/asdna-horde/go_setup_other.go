//go:build !windows

package main

import "fmt"

func goSetupSupported() bool               { return false }
func goInstallationStatus() (bool, string) { return false, "" }
func installGoToolchain() (string, error) {
	return "", fmt.Errorf("instalacao automatica disponivel apenas no Windows")
}
