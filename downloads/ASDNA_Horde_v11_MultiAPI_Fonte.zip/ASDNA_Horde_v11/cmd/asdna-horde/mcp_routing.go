package main

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/mcp"
	"asdna-horde-reconstructed/internal/pcactions"
)

// MCP routing is based on the requested capability, not the brand of the app.
// A focused schema beats dumping 57 long descriptions into a small language model.
func preferredMCP(request string) string {
	n := pcactions.NormalizeIntent(request)
	if strings.Contains(n, "playwright") ||
		(hasAny(n, "http://", "https://", "site", "pagina web", "navegador", "formulario") &&
			hasAny(n, "adicione", "preencha", "clique", "digite", "confirme", "verifique", "interaja", "formulario", "envie", "login", "preencher")) {
		return "playwright"
	}
	if strings.Contains(n, "filesystem mcp") || strings.Contains(n, "mcp filesystem") {
		return "filesystem"
	}
	if strings.Contains(n, "windows mcp") || strings.Contains(n, "mcp windows") ||
		(hasAny(n, "bloco de notas", "notepad", "janela", "desktop", "programa aberto") &&
			hasAny(n, "digite", "escreva", "texto", "clique", "verifique", "preencha", "selecione", "aperte", "interface")) {
		return "windows"
	}
	return ""
}
func hasAny(s string, terms ...string) bool {
	for _, v := range terms {
		if strings.Contains(s, v) {
			return true
		}
	}
	return false
}

var firstURL = regexp.MustCompile(`https?://[^\s\"'<>]+`)

func relevantMCPTools(server string) []string {
	switch server {
	case "playwright":
		return []string{"browser_navigate", "browser_snapshot", "browser_type", "browser_press_key", "browser_click", "browser_wait_for"}
	case "filesystem":
		return []string{"create_directory", "write_file", "read_text_file", "list_directory", "get_file_info"}
	case "windows":
		return []string{"app", "ui_snapshot", "ui_find", "ui_type", "ui_read", "window_management"}
	}
	return nil
}

// Keep schema keys/types/required, but trim verbose descriptions. Losing the
// inputSchema altogether caused the earlier model to invent arguments.
func shortenSchema(v any) any {
	switch x := v.(type) {
	case map[string]any:
		y := make(map[string]any, len(x))
		for k, val := range x {
			if k == "description" {
				if s, ok := val.(string); ok {
					r := []rune(s)
					if len(r) > 130 {
						val = string(r[:130])
					}
				}
			}
			y[k] = shortenSchema(val)
		}
		return y
	case []any:
		for i := range x {
			x[i] = shortenSchema(x[i])
		}
		return x
	default:
		return v
	}
}
func chosenToolSchemas(name string, tools []mcp.Tool, maxChars int) string {
	if maxChars < 250 {
		return ""
	}
	byName := map[string]mcp.Tool{}
	for _, t := range tools {
		byName[t.Name] = t
	}
	out := strings.Builder{}
	for _, wanted := range relevantMCPTools(name) {
		t, ok := byName[wanted]
		if !ok {
			continue
		}
		var schema any
		if len(t.InputSchema) > 0 {
			_ = json.Unmarshal(t.InputSchema, &schema)
		}
		if schema == nil {
			schema = map[string]any{"type": "object"}
		}
		b, _ := json.Marshal(shortenSchema(schema))
		desc := t.Description
		rr := []rune(desc)
		if len(rr) > 95 {
			desc = string(rr[:95])
		}
		line := fmt.Sprintf("%s: %s; arguments=%s\n", t.Name, desc, string(b))
		if out.Len()+len(line) > maxChars {
			continue
		}
		out.WriteString(line)
	}
	return out.String()
}

func (a *App) mcpTaskGuidance(request string) string {
	server := preferredMCP(request)
	if server == "" || a.mcp == nil {
		return ""
	}
	// Explicit approval for external servers, remembered for this app session.
	if err := a.approveMCPStart(server); err != nil {
		return "\nMCP " + server + " indisponivel: " + err.Error() + ". Nao alegue que usou MCP.\n"
	}
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	tools, err := a.mcp.ListTools(ctx, server)
	if err != nil {
		return "\nMCP " + server + " indisponivel: " + err.Error() + ". Nao alegue que usou MCP.\n"
	}
	schema := chosenToolSchemas(server, tools, 6700)
	return "\nMCP PREFERENCIAL PARA ESTE PEDIDO: " + server + ". ESTE SERVIDOR ESTA REALMENTE CONECTADO. Para interagir use {\"tool\":\"mcp_call\",\"server\":\"" + server + "\",\"name\":\"NOME_EXATO\",\"arguments\":{...}}. Use os PARAMETROS EXATOS dos esquemas abaixo. Nao use desktop_control para paginas web: navegador DOM precisa do Playwright. Antes de clicar ou digitar em elementos use browser_snapshot/ui_find. Apos mudar interface, leia snapshot/ui_read e verifique. Se faltarem parametros solicite mcp_schema. Nao repita abrir a pagina ou programa como substituto das proximas etapas.\nESQUEMAS REAIS DE " + server + ":\n" + schema + "\n"
}

func correctMCPBrowserAction(request string, action pcactions.Action) (pcactions.Action, bool) {
	if preferredMCP(request) != "playwright" {
		return action, false
	}
	if action.Tool == "browser_navigate" || action.Tool == "open_url" {
		url := strings.TrimSpace(action.URL)
		if url == "" {
			url = firstURL.FindString(request)
		}
		if url != "" {
			raw, _ := json.Marshal(map[string]string{"url": url})
			return pcactions.Action{Tool: "mcp_call", Server: "playwright", Name: "browser_navigate", Arguments: raw}, true
		}
	}
	return action, false
}

func wrongMCPBrowserTool(request string, action pcactions.Action) bool {
	if preferredMCP(request) != "playwright" {
		return false
	}
	// Can't safely invent a DOM selector from the window title.
	return action.Tool == "desktop_control" || action.Tool == "open_app" || action.Tool == "run_process" || action.Tool == "browser_search"
}

func needsMCPVerification(request string, lastName string) bool {
	if preferredMCP(request) == "" {
		return false
	}
	if !hasAny(pcactions.NormalizeIntent(request), "confirme", "verifique", "verificar", "mostre", "leia novamente") {
		return false
	}
	if lastName == "" {
		return false
	}
	// Observing the UI isn't equivalent to launching/navigating/clicking.
	switch lastName {
	case "browser_snapshot", "browser_wait_for", "ui_snapshot", "ui_read", "read_text_file", "get_file_info", "list_directory":
		return false
	default:
		return true
	}
}
