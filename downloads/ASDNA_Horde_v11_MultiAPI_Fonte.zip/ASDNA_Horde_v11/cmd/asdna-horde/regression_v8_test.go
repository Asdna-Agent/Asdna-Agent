package main

import (
	"asdna-horde-reconstructed/internal/pcactions"
	"strings"
	"testing"
)

func TestReportedTaskManagerAndExplorerCommand(t *testing.T) {
	req := "abra o gerenciador de tarefas do meu computador e encerre o gerenciador de arquivos"
	got, ok := directActionPlan(req)
	if !ok || len(got) != 2 || got[0].Tool != "open_app" || got[0].App != "taskmgr.exe" || got[1].Tool != "terminate_process" || got[1].App != "explorer.exe" {
		t.Fatalf("%v %v", got, ok)
	}
	a := &App{recentApp: "Minecraft"}
	action, changed := a.correctPathIntent(req, pcactions.Action{Tool: "open_app", App: "taskmgr.exe"})
	if changed || action.Tool != "open_app" {
		t.Fatalf("erroneous path rewrite: %+v", action)
	}
	if _, ok := directActionPlan("abra o gerenciador de tarefas, mas nao encerre o gerenciador de arquivos"); ok {
		t.Fatal("should not terminate under negation")
	}
}
func TestReportedChromeSearchProfile(t *testing.T) {
	req := `abra o google chrome, no perfil zelp e pesquise por "Oque um gato come?"`
	got, ok := directActionPlan(req)
	if !ok || len(got) != 1 || got[0].Tool != "browser_search" || got[0].Profile != "zelp" || got[0].Query != "Oque um gato come?" {
		t.Fatalf("%+v %t", got, ok)
	}
}
func TestReportedMinecraftContextVersusOrdinaryChat(t *testing.T) {
	a := &App{recentApp: "Minecraft", recentRequest: "abra Minecraft"}
	found := a.likelyAgentAction("ache a pasta de mods e abra")
	if !found {
		t.Fatal("followup lost")
	}
	act, changed := a.correctPathIntent("ache a pasta de mods e abra", pcactions.Action{Tool: "open_app", App: "Minecraft"})
	if !changed || act.Tool != "find_path" || act.Query != "mods" || act.Context != "Minecraft" || act.Kind != "folder" {
		t.Fatalf("unexpected action %+v", act)
	}
	for _, q := range []string{"bom dia", "O que um gato come?", "ele é inteligente?", "como abrir a pasta de mods?"} {
		if a.likelyAgentAction(q) {
			t.Errorf("conversational request must use AI chat: %s", q)
		}
	}
	if _, ok := directActionPlan("bom dia"); ok {
		t.Fatal("ordinary conversation mistaken as plan")
	}
	if !strings.Contains(a.sessionContext(), "Minecraft") {
		t.Fatal("context missing")
	}
}
