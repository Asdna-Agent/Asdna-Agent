package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/storage"
	"asdna-horde-reconstructed/internal/ui"
)

var fileNamePattern = regexp.MustCompile(`(?i)([\pL\pN_./\\-]+\.(?:py|html|css|txt|md|js|ts|json|go|rs|yml|yaml|xml|csv|sql|ps1|bat))\b`)

// createSite usa as ferramentas locais, nao depende do modelo remoto saber escrever JSON.
func (a *App) createSite(request string) {
	ui.User(request)
	folder, result, err := a.pc.CreateBasicSite(request)
	if err != nil {
		ui.Errf("Falha ao criar site: %v", err)
		return
	}
	a.lastProject = folder
	ui.OK(result)
	a.recordLocal(request, result)
	prompt := pcactions.NormalizeIntent(request)
	wantZip := strings.Contains(prompt, ".zip") || strings.Contains(prompt, "compact") || strings.Contains(prompt, "zipar") || strings.Contains(prompt, "download") || strings.Contains(prompt, "baixar")
	if wantZip {
		dest := a.uniqueZipName(folder)
		out, err := a.pc.ZipFolder(folder, dest)
		if err != nil {
			ui.Warnf("Site salvo, mas ZIP nao foi criado: %v", err)
			return
		}
		ui.OK(out)
		ui.Hint("O arquivo ZIP ja esta no seu computador. Use /arquivos abrir para encontra-lo.")
		a.recordLocal("zip de "+folder, out)
	} else {
		ui.Hint("Use /zip para compactar a pasta ou /arquivos abrir para visualizar.")
	}
	ui.Hint("Site inicial em HTML e CSS criado localmente; os arquivos podem ser editados.")
}

func (a *App) recordLocal(request, result string) {
	a.history.Append("user", a.config.SelectedModel, request)
	a.history.Append("assistant", a.config.SelectedModel, result)
	_ = storage.SaveHistory(a.history)
}

func (a *App) uniqueZipName(folder string) string {
	name := folder + ".zip"
	for i := 2; i < 10000; i++ {
		if _, err := os.Lstat(filepath.Join(a.pc.Base, name)); os.IsNotExist(err) {
			return name
		}
		name = fmt.Sprintf("%s_%d.zip", folder, i)
	}
	return name
}

func (a *App) findRecentProject() string {
	if a.lastProject != "" {
		if info, err := os.Stat(filepath.Join(a.pc.Base, a.lastProject)); err == nil && info.IsDir() {
			return a.lastProject
		}
	}
	entries, err := os.ReadDir(a.pc.Base)
	if err != nil {
		return ""
	}
	recent := time.Time{}
	selected := ""
	for _, e := range entries {
		if !e.IsDir() || e.Type()&os.ModeSymlink != 0 {
			continue
		}
		htmlFile := filepath.Join(a.pc.Base, e.Name(), "index.html")
		if stat, err := os.Lstat(htmlFile); err == nil && stat.Mode().IsRegular() {
			if stat.ModTime().After(recent) {
				recent = stat.ModTime()
				selected = e.Name()
			}
		}
	}
	return selected
}

func (a *App) zipRequest(folder string) {
	folder = strings.TrimSpace(folder)
	if folder == "" {
		folder = a.findRecentProject()
	}
	if folder == "" {
		ui.Warn("Ainda nao ha projeto salvo para compactar. Crie um site ou use /zip NOME_DA_PASTA.")
		return
	}
	name := filepath.Base(filepath.Clean(folder))
	if name == "." || name == string(filepath.Separator) {
		name = "Arquivos"
	}
	dest := a.uniqueZipName(name)
	result, err := a.pc.ZipFolder(folder, dest)
	if err != nil {
		ui.Errf("Nao foi possivel criar ZIP: %v", err)
		return
	}
	ui.OK(result)
	ui.Hint("ZIP pronto em Downloads/ASDNA_Horde. Use /arquivos abrir.")
	a.recordLocal("compactar pasta "+folder, result)
}

// trySavePlainCode cobre modelos pequenos que retornam codigo comum em vez de uma tag de ferramenta.
func (a *App) trySavePlainCode(request, reply string) bool {
	code, ext, found := pcactions.ExtractCode(reply)
	if !found {
		raw := strings.TrimSpace(reply)
		if strings.HasPrefix(strings.ToLower(raw), "<!doctype html") && strings.Contains(strings.ToLower(raw), "</html>") {
			code = raw + "\n"
			ext = "html"
			found = true
		}
	}
	if !found {
		return false
	}
	matches := fileNamePattern.FindStringSubmatch(request)
	name := "codigo." + ext
	if len(matches) > 1 {
		name = matches[1]
	}
	// Para impedir salvar uma resposta truncada como site funcional.
	if strings.HasSuffix(strings.ToLower(name), ".html") && !strings.Contains(strings.ToLower(code), "</html>") {
		ui.Warn("A IA gerou HTML incompleto. Nada foi salvo como site pronto.")
		return false
	}
	out, err := a.pc.SaveCode(name, code)
	if err != nil {
		ui.Warnf("Codigo gerado, mas nao foi possivel salvar: %v", err)
		return false
	}
	ui.OK(out)
	ui.Hint("Arquivo salvo automaticamente em Downloads/ASDNA_Horde.")
	return true
}
