package main

import (
	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/ui"
	"regexp"
	"strings"
)

var simpleOpenRE = regexp.MustCompile(`(?i)^(?:(?:por favor|pfv|pf|pode|poderia|consegue)\s+)*(?:abra|abre|abrir|abri|inicie|inicia|iniciar)\s+(?:(?:o|a|um|uma)\s+)?(.+?)\s*[?!.]*$`)
var profileOpenRE = regexp.MustCompile(`(?i)^(?:google\s+)?(?:chrome|chr)(?:\.exe)?\s+(?:(?:no|com\s+o|com|o)\s+)?(?:perfil\s+)?(.+)$`)

// Only handle a single unambiguous opening intent. Compound requests stay with AI.
func simpleOpenAction(request string) (pcactions.Action, bool) {
	m := simpleOpenRE.FindStringSubmatch(strings.TrimSpace(request))
	if len(m) < 2 {
		return pcactions.Action{}, false
	}
	target := strings.TrimSpace(m[1])
	norm := pcactions.NormalizeIntent(target)
	for _, v := range []string{" e ", "depois", "pesquis", "busqu", "procur", "digite", "escreva", "clique", "instal", "administrador", "como admin", "http:", "https:", "--", ";", "\n", ". ", " mcp", " utilize", " localize", " verificar", " verifique", " digitar", " digite"} {
		if strings.Contains(norm, v) {
			return pcactions.Action{}, false
		}
	}
	for _, suffix := range []string{" por favor", " pra mim", " para mim", " pfv", " pf"} {
		if strings.HasSuffix(norm, suffix) {
			target = target[:len(target)-len(suffix)]
			norm = pcactions.NormalizeIntent(target)
		}
	}
	target = strings.TrimSpace(strings.Trim(target, `"“”'`))
	if target == "" {
		return pcactions.Action{}, false
	}
	if m := profileOpenRE.FindStringSubmatch(target); len(m) > 1 {
		return pcactions.Action{Tool: "open_app", App: "chrome.exe", Profile: strings.TrimSpace(strings.Trim(m[1], `"“”'`))}, true
	}
	// Folders/files should use file tools, not the app resolver.
	for _, s := range []string{"pasta ", "arquivo ", "site ", "pagina "} {
		if strings.HasPrefix(norm, s) {
			return pcactions.Action{}, false
		}
	}
	return pcactions.Action{Tool: "open_app", App: target}, true
}
func (a *App) executeLocalAction(request string, action pcactions.Action) {
	ui.Hint("Localizando no computador...")
	result, err := a.pc.Execute(action)
	if err != nil {
		ui.Warnf("%v", err)
		a.recordLocal(request, "Nao executado: "+err.Error())
		return
	}
	ui.OK(result)
	a.updateAgentContext(request, action, result)
	a.recordLocal(request, result)
}

// tryFastOpen handles obvious launch requests without spending a Horde round
// trip. Ambiguity is not turned into a numbered menu: it falls through to the
// full planner, which can inspect candidates and context itself.
func (a *App) tryFastOpen(request string, action pcactions.Action) bool {
	ui.Hint("Localizando no computador...")
	result, err := a.pc.Execute(action)
	a.recordTask(action, result, err)
	if err == nil {
		ui.OK(result)
		a.updateAgentContext(request, action, result)
		a.recordLocal(request, result)
		return true
	}
	lower := strings.ToLower(err.Error())
	if strings.Contains(lower, "recusad") || strings.Contains(lower, "cancelad") || strings.Contains(lower, "nao autorizad") {
		ui.Warnf("%v", err)
		a.recordLocal(request, "Nao executado: "+err.Error())
		return true
	}
	ui.Hint("A resolucao local nao foi suficiente; passando o pedido ao agente de IA.")
	return false
}
