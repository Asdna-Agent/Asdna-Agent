package main

import (
	"fmt"
	"regexp"
	"strings"

	"asdna-horde-reconstructed/internal/pcactions"
	"asdna-horde-reconstructed/internal/ui"
)

var directSearchQuote = regexp.MustCompile(`(?i)\b(?:pesquis\w*|busqu\w*)\s+(?:por\s+)?["“]([^"”]+)["”]`)
var directSearchPlain = regexp.MustCompile(`(?i)\b(?:pesquis\w*|busqu\w*)\s+(?:por\s+)?(.+?)\s*[?!]*$`)
var directProfile = regexp.MustCompile(`(?i)\b(?:no|com\s+o|com)\s+perfil\s+(.+?)(?:\s+e\s+(?:pesquis\w*|busqu\w*)|\s*,\s*(?:pesquis\w*|busqu\w*)|$)`)

// Plans do not infer unknown applications or profiles: local tools must resolve
// actual targets before acting. A small exact plan is more reliable than asking a
// 3B language model to assemble a predictable compound instruction.
func directActionPlan(request string) ([]pcactions.Action, bool) {
	norm := pcactions.NormalizeIntent(request)
	hasTaskManager := strings.Contains(norm, "gerenciador de tarefas") || strings.Contains(norm, "taskmgr")
	hasExplorer := strings.Contains(norm, "gerenciador de arquivos") || strings.Contains(norm, "explorador de arquivos") || strings.Contains(norm, "explorer.exe")
	stop := false
	for _, verb := range []string{"encerre", "encerrar", "finalize", "finalizar", "termine", "terminar", "mate", "matar", "feche", "fechar"} {
		if strings.Contains(norm, verb) {
			stop = true
			break
		}
	}
	if hasTaskManager && hasExplorer && stop && !strings.Contains(norm, "nao encerre") && !strings.Contains(norm, "sem encerrar") && (strings.Contains(norm, "abra") || strings.Contains(norm, "abre") || strings.Contains(norm, "inicie")) {
		return []pcactions.Action{{Tool: "open_app", App: "taskmgr.exe"}, {Tool: "terminate_process", App: "explorer.exe"}}, true
	}
	if (strings.Contains(norm, "chrome") || strings.Contains(norm, "google chrome")) &&
		(strings.Contains(norm, "pesquis") || strings.Contains(norm, "busqu")) {
		m := directSearchQuote.FindStringSubmatch(request)
		if len(m) < 2 {
			m = directSearchPlain.FindStringSubmatch(request)
		}
		if len(m) < 2 || strings.TrimSpace(m[1]) == "" {
			return nil, false
		}
		act := pcactions.Action{Tool: "browser_search", Query: strings.TrimSpace(m[1])}
		if prof := directProfile.FindStringSubmatch(request); len(prof) > 1 {
			act.Profile = strings.TrimSpace(strings.Trim(prof[1], ` "“”'`))
		}
		return []pcactions.Action{act}, true
	}
	return nil, false
}

func (a *App) executeDirectPlan(request string, plan []pcactions.Action) {
	ui.User(request)
	completed := []string{}
	for _, action := range plan {
		result, err := a.pc.Execute(action)
		a.recordTask(action, result, err)
		if err != nil {
			ui.Warnf("Falha em %s: %v", action.Tool, err)
			summary := fmt.Sprintf("Conclui %d de %d etapas. Etapa %s nao executada: %v", len(completed), len(plan), action.Tool, err)
			ui.Assistant(a.config.SelectedModel, summary)
			a.recordLocal(request, summary)
			return
		}
		completed = append(completed, result)
		a.updateAgentContext(request, action, result)
		ui.OK(trimString(result, 450))
	}
	summary := "Tarefa executada: " + strings.Join(completed, " | ")
	ui.Assistant(a.config.SelectedModel, trimString(summary, 800))
	a.recordLocal(request, summary)
}

// When a previous app is known, searching an explicitly named folder is a
// deterministic operation. Only open a unique, high-confidence real result.
func (a *App) tryContextFolderOpen(request string) bool {
	if a.recentApp == "" || !requestWantsOpenPath(request) {
		return false
	}
	target := extractPathQuery(request)
	if target == "" || strings.Contains(pcactions.NormalizeIntent(request), "gerenciador de arquivos") {
		return false
	}
	lookup := pcactions.Action{Tool: "find_path", Query: target, Context: a.recentApp, Kind: "folder"}
	result, err := a.pc.Execute(lookup)
	a.recordTask(lookup, result, err)
	if err != nil {
		return false
	}
	path := bestPathFromResult(result)
	if path == "" {
		return false
	}
	openAction := pcactions.Action{Tool: "open_path", Path: path}
	opened, err := a.pc.Execute(openAction)
	a.recordTask(openAction, opened, err)
	if err != nil {
		return false
	}
	ui.User(request)
	ui.OK(opened)
	a.updateAgentContext(request, pcactions.Action{Tool: "open_path", Path: path}, opened)
	summary := "Localizei e solicitei a abertura da pasta: " + path
	ui.Assistant(a.config.SelectedModel, summary)
	a.recordLocal(request, summary)
	return true
}
