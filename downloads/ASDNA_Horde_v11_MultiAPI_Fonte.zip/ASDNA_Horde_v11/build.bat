@echo off
cd /d "%~dp0"
echo Testando...
go test ./...
if errorlevel 1 exit /b 1
echo Compilando ASDNA_Horde_Agentes.exe...
go build -buildvcs=false -trimpath -o ASDNA_Horde_Agentes.exe ./cmd/asdna-horde
if errorlevel 1 exit /b 1
echo Pronto.
pause
