Set-Location $PSScriptRoot
$ErrorActionPreference = 'Stop'
go test ./...
if ($LASTEXITCODE -ne 0) { throw 'Os testes falharam' }
go build -buildvcs=false -trimpath -o ASDNA_Horde_Agentes.exe ./cmd/asdna-horde
if ($LASTEXITCODE -ne 0) { throw 'A compilacao falhou' }
Write-Host 'Executavel gerado: ASDNA_Horde_Agentes.exe'
